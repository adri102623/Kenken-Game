package edu.upc.prop.clusterxx.Domini;
import edu.upc.prop.clusterxx.Domini.Operation.Operation;
import edu.upc.prop.clusterxx.Domini.Operation.OperationSubtraction;
import edu.upc.prop.clusterxx.Domini.Operation.OperationAddition;
import edu.upc.prop.clusterxx.Domini.Board.Pos;
import edu.upc.prop.clusterxx.Domini.Board.Region;
import edu.upc.prop.clusterxx.Domini.Board.Board;
import edu.upc.prop.clusterxx.Domini.Board.Tile;

import org.junit.Before;
import org.junit.Test;

import java.util.Vector;

import static org.junit.Assert.assertTrue;

public class TestBoard {
    private Board board;

    @Before
    public void setUp() {
        //Tablero:
        //1234
        //2341
        //3412
        //4123

        //++-0
        //++-0
        //0000
        //0000

        //Copiado de TestComprobar.setUp
        board = new Board(4); // Tamaño del tablero de ejemplo
        // Definir los valores de las casillas del tablero
        board.getTile(new Pos(0, 0)).setValue(1);
        board.getTile(new Pos(0, 1)).setValue(2);
        board.getTile(new Pos(0, 2)).setValue(3);
        board.getTile(new Pos(0, 3)).setValue(4);
        board.getTile(new Pos(1, 0)).setValue(2);
        board.getTile(new Pos(1, 1)).setValue(3);
        board.getTile(new Pos(1, 2)).setValue(4);
        board.getTile(new Pos(1, 3)).setValue(1);
        board.getTile(new Pos(2, 0)).setValue(3);
        board.getTile(new Pos(2, 1)).setValue(4);
        board.getTile(new Pos(2, 2)).setValue(1);
        board.getTile(new Pos(2, 3)).setValue(2);
        board.getTile(new Pos(3, 0)).setValue(4);
        board.getTile(new Pos(3, 1)).setValue(1);
        board.getTile(new Pos(3, 2)).setValue(2);
        board.getTile(new Pos(3, 3)).setValue(3);

        //Copiado de TestComprobar.testComprobarTablero
        Region region1 = board.newRegion();
        region1.addPosition(new Pos(0, 0));
        region1.addPosition(new Pos(0, 1));
        region1.addPosition(new Pos(1, 0));
        region1.addPosition(new Pos(1, 1));
        Operation operation1 = new OperationAddition();
        region1.setResult(9);
        region1.setOperation(operation1);

        Region region2 = board.newRegion();
        region2.addPosition(new Pos(0,2));
        region2.addPosition(new Pos(1,2));
        Operation operation2 = new OperationSubtraction();
        region2.setResult(1);
        region2.setOperation(operation2);
    }

    @Test
    public void printTauler() {
        Board t = new Board(5);

        Region r = t.newRegion();
        Operation op = Operation.GetOperation(2);
        r.setResult(3);
        r.setOperation(op);
        r.addPosition(new Pos(0, 4));
        r.addPosition(new Pos(1, 4));
        r.addPosition(new Pos(2, 4));

        r = t.newRegion();
        op = Operation.GetOperation(1);
        r.setResult(5);
        r.setOperation(op);
        r.addPosition(new Pos(0, 3));
        r.addPosition(new Pos(1, 2));
        r.addPosition(new Pos(2, 1));

        t.getTile(new Pos(0, 4)).setValue(5);
        t.getTile(new Pos(1, 2)).setValue(1);
        t.getTile(new Pos(0, 3)).setValue(9);

        String[] lines = t.codify();

        for (String line : lines) {
            System.out.println(line);
        }
    }

    @Test
    public void loadTauler() {
        String coded = "6 15 " +
                "1 11 2 1 1 2 1 " +
                "4 2 2 1 2 1 3 " +
                "3 20 2 1 4 2 4 " +
                "3 6 4 1 5 1 6 2 6 3 6 " +
                "2 3 2 2 2 2 3 " +
                "4 3 2 2 5 3 5 " +
                "3 240 4 3 1 3 2 4 1 4 2 " +
                "3 6 2 3 3 3 4 " +
                "3 6 2 4 3 5 3 " +
                "1 7 3 4 4 5 4 5 5 " +
                "3 30 2 4 5 4 6 " +
                "3 6 2 5 1 5 2 " +
                "1 9 2 5 6 6 6 " +
                "1 8 3 6 1 6 2 6 3 " +
                "4 2 2 6 4 6 5";

        Board t = new Board(coded);
        for (String line : t.codify()) {
            System.out.println(line);
        }

    }

    @Test
    public void cloneTauler() {
        String[] t1 = board.codify();
        String[] t2 = board.cloneBoard().codify();
    }

    @Test
    public void constructor() {
        boolean exception = false;
        try {
            Board t = new Board(-1);
        } catch (IllegalArgumentException e) {
            exception = true;
        }
        assert (exception);
    }

    @Test
    public void constructor_2() {
        Board t = new Board(0);
        t = new Board(1);
        t = new Board(100);
    }

    @Test
    public void getCasella() {
        boolean exception = false;
        try {
            Tile c = board.getTile(new Pos(4, 4));
        } catch (IllegalArgumentException e) {
            exception = true;
        }
        assert (exception);
    }

    @Test
    public void getCasella_2() {
        Tile c = board.getTile(new Pos(0, 0));
        assert (c.getValue() == 1);
    }


    @Test
    public void getRegio() {
        boolean exception = false;
        try {
            Region r = board.getRegion(new Pos(4, 4));
        } catch (IllegalArgumentException e) {
            exception = true;
        }
        assert (exception);
    }

    @Test
    public void getRegio_2() {
        Region r = board.getRegion(new Pos(0, 0));
        assert (r.getOperacio().getCode() == new OperationAddition().getCode());
    }

    @Test
    public void getRegions() {
        Vector<Region> v = board.getRegions();
        assert (v.size() == 2);
        //Las regiones son de suma o resta en este caso
        assert (v.get(0).getOperacio().getCode() == new OperationAddition().getCode() || v.get(0).getOperacio().getCode() == new OperationSubtraction().getCode());
        assert (v.get(1).getOperacio().getCode() == new OperationAddition().getCode() || v.get(1).getOperacio().getCode() == new OperationSubtraction().getCode());
    }

    @Test
    public void getTamany() {
        for (int i = 0; i < 10; i++) {
            assert (i == new Board(i).getSize());
        }
        assert (4 == board.getSize());
    }

    @Test
    public void newRegion() {
        Region r = board.newRegion();
        assert (r.getBoard() == board);
    }

    @Test
    public void deleteRegion() {
        Region r = board.getRegion(new Pos(0, 0));
        board.deleteRegion(r);
        assert (null == board.getRegion(new Pos(1, 1)));
        Vector<Region> v = board.getRegions();
        assert (v.size() == 1);
        assert (v.get(0).getOperacio().getCode() == new OperationSubtraction().getCode());
    }

    @Test
    public void deleteRegion_2() {
        board.deleteRegion(new Pos(0, 0));
        assert (null == board.getRegion(new Pos(1, 1)));
        Vector<Region> v = board.getRegions();
        assert (v.size() == 1);
        assert (v.get(0).getOperacio().getCode() == new OperationSubtraction().getCode());
    }
}
