package edu.upc.prop.clusterxx.Domini;

import edu.upc.prop.clusterxx.Domini.Board.Board;
import org.junit.Before;
import org.junit.Test;

public class TestGameMode {
    GameMode gameMode;
    Board board;

    @Before
    public void setUp() {
        board = new Board(4);
        gameMode = new Kenken(board);
    }

    @Test
    public void getTauler() {
        assert (board == gameMode.getBoard());
    }

    @Test
    public void interactuable() {
        gameMode.setInteractive(true);
        assert (gameMode.isInteractive());
    }
}
