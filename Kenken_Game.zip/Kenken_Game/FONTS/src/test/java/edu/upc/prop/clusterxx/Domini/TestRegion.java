package edu.upc.prop.clusterxx;

import edu.upc.prop.clusterxx.Domini.Operation.Operation;
import edu.upc.prop.clusterxx.Domini.Operation.OperationMult;
import edu.upc.prop.clusterxx.Domini.Operation.OperationAddition;
import edu.upc.prop.clusterxx.Domini.Board.Tile;
import edu.upc.prop.clusterxx.Domini.Board.Pos;
import edu.upc.prop.clusterxx.Domini.Board.Region;
import edu.upc.prop.clusterxx.Domini.Board.Board;
import org.junit.Before;
import org.junit.Test;

import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import static org.junit.Assert.*;
import static org.junit.Assert.assertNotNull;

public class TestRegion {

    private Board board;
    private Region region;

    @Before
    public void setUp() {
        board = new Board(3); // Por ejemplo, crea un tablero de tamaño 3x3
        region = board.newRegion();
    }

    @Test
    public void getTauler() {
        assert(region.getBoard() == board);
    }

    public void getTamanoPos() {
        for (int i = 0; i < 2; i++) {
            assert (region.getSize() == i);
            assert (region.getTiles().size() == i);
            region.addPosition(new Pos(0, i));
        }
    }

    public void getTamanoOffset() {
        for (int i = 0; i < 2; i++) {
            assert (region.getSize() == i);
            assert (region.getTiles().size() == i);
            region.addOffset(new Pos(0, i));
        }
    }

    @Test
    public void getInitialPos() {
        assertNull(region.getInitialPos());
        region.setInitialPos(new Pos(1, 1));
        //No debe añadir la posición a la región.
        assert (region.getTiles().isEmpty());
        assertNotNull(region.getInitialPos());
    }

    @Test
    public void getCasellesNull() {
        assert(region.getTiles().isEmpty()); // La función debería devolver null si initialPos es null
    }

    @Test
    public void getCaselles() {
        assert(region.getTiles().isEmpty());
        region.addPosition(new Pos(0, 0));
        Vector<Tile> v = region.getTiles();
        assert (v.get(0) == board.getTile(new Pos(0, 0)));
    }

    @Test
    public void getCaselles_2() {
        assert(region.getTiles().isEmpty());
        region.addOffset(new Pos(0, 0));
        region.addOffset(new Pos(1, 0));
        region.addOffset(new Pos(1, 1));
        Vector<Tile> v = region.getTiles();
        //No hay posición de referencia asignada.
        assert (v.isEmpty());
    }

    @Test
    public void getOffsets() {
        Vector<Pos> s = region.getOffsets();
        assert(s.isEmpty());
        s.add(new Pos(0, 0));
        //Get offsets debe devolver una copia, no la referencia al set interno.
        //Cambios al valor que devuelve esta función no deben afectar a la región.
        assert (region.getOffsets().isEmpty());
    }

    @Test
    public void getOffsets_2() {
        assert(region.getOffsets().isEmpty());
        region.addOffset(new Pos(0, 0));
        Vector<Pos> s = region.getOffsets();
        assert(s.size() == 1);
        //El set debe contener la posición.
        assert(!s.contains(new Pos(0,0)));
    }

    @Test
    //Comprueba también setOperació
    public void getOperacio() {
        assertNull(region.getOperacio());
        region.setOperation(new OperationAddition());
        assert(region.getOperacio().getCode() == new OperationAddition().getCode());
    }

    @Test
    public void setInitialPos() {
        region.addOffset(new Pos(0,0));
        region.addOffset(new Pos(1,0));
        assert (!region.setInitialPos(new Pos(-1, 0)));
        assert (!region.setInitialPos(new Pos(2, 0)));
        assert (region.setInitialPos(new Pos(0,0)));
        assert (board.getRegion(new Pos(0,0)) == region);
        assert (board.getRegion(new Pos(1,0)) == region);
        assert (board.getRegion(new Pos(2,0)) != region);
    }

    @Test
    public void setOffsets() {
        Set<Pos> offsets = new TreeSet<>();
        offsets.add(new Pos(0,0));
        offsets.add(new Pos(1,0));
        region.setInitialPos(new Pos(2,2));
        assert (!region.setOffsets(offsets));
        region.setInitialPos(new Pos(0,0));
        assert (region.setOffsets(offsets));
        offsets.add(new Pos(2,2));
        assert (offsets.size() != region.getOffsets().size());
    }

    @Test
    public void setOffsets_2() {
        Set<Pos> offsets = new TreeSet<>();
        offsets.add(new Pos(0,0));
        offsets.add(new Pos(100,0));
        //Si no hay posición de referencia asignada debe dejar asignar cualquier offset.
        assert (region.setOffsets(offsets));
    }

    @Test
    public void addOffset() {
        Pos p = new Pos(0,0);
        assert(region.addOffset(p));
        p.j = 10;
        Vector<Pos> offsets = region.getOffsets();
        assert(offsets.size() == 1);
        //Debe hacer una copia del elemento, no usar el parámetro dado.
        assert(!offsets.contains(p));
        region.setInitialPos(new Pos(0,0));
        assert (!region.addOffset(new Pos(3, 0)));
    }

    @Test
    public void addPosition() {
        Pos p = new Pos(0,0);
        assert (region.getInitialPos() == null);
        assert(region.addPosition(p));
        assert (region.getInitialPos() != p);
        assert (region.getInitialPos().equals(p));
        //Asegurarse que hace una copia
        p.j = 1;
        assert(board.getRegion(new Pos(0,0)) == region);
        assert(board.getRegion(new Pos(0, 1)) != region);
        assert (!region.addOffset(new Pos(3, 0)));
    }

    @Test
    public void testGetCasellesWithInitialPosNotNull() {
        // Configura una initialPos válida para la región
        region.setInitialPos(new Pos(0, 0));

        // Configura las offsets de la región
        //Es irrelevante que sea HasSet, setOffsets tiene como clase del parámetro Collection<Pos>
        Set<Pos> offsets = new TreeSet<>();
        offsets.add(new Pos(1, 0));
        offsets.add(new Pos(0, 1));
        offsets.add(new Pos(0, 2));
        region.setOffsets(offsets);

        // Configura las casillas del tablero
        board.getTile(new Pos(0, 0)).setValue(1);
        board.getTile(new Pos(0, 1)).setValue(2);
        board.getTile(new Pos(0, 2)).setValue(3);
        // Llama a la función que estamos probando
        Vector<Tile> result = region.getTiles();

        // Verifica que el resultado no sea nulo
        assertNotNull(result);

        // Verifica que el tamaño del vector sea correcto
        assertEquals(3, result.size());

        // Verifica que todas las casillas devueltas por la función no sean nulas
        for (Tile tile : result) {
            assertNotNull(tile);
        }
    }

    @Test
    public void testsetinitialpos(){
        Board board = new Board(5);
        Region region = board.newRegion();
        assertTrue(region.setInitialPos(new Pos(0, 0)));
        assertNotNull(region.getInitialPos());
    }

    @Test
    public void testAddOffset() {
        Board board = new Board(5);
        Region region = board.newRegion();
        assertTrue(region.addOffset(new Pos(1, 0)));
        assertEquals(1, region.getOffsets().size());
    }

    @Test
    public void testAddPos() {
        Board board = new Board(5);
        Region region = board.newRegion();
        assertTrue(region.addPosition(new Pos(1, 0)));
        assertEquals(1, region.getSize());
    }

    @Test
    public void testremoveoffset() {
        Board board = new Board(5);
        Region region = board.newRegion();
        region.setInitialPos(new Pos(1,0));
        region.addOffset(new Pos(1,0));
        assert(region.removeOffset(new Pos(1, 0)));
        assertEquals(0, region.getOffsets().size());
        assert(board.getRegion(new Pos(2, 0)) == null);
        //Bounds se actualiza correctamente:
        assert (region.setInitialPos(new Pos(4, 0)));
    }
    @Test
    public void testIsCompleted() {
        Board board = new Board(5);
        Region region = board.newRegion();
        region.addOffset(new Pos(0, 0));
        board.getTile(new Pos(0, 0)).setValue(1);
        assertFalse(region.isCompleted());
        region.setInitialPos(new Pos(0, 0));
        assert (region.isCompleted());
    }

    @Test
    public void operacioChecks() {
        assertThrows(RuntimeException.class, () -> region.operationChecks());
        Operation op = new OperationAddition();
        region.setResult(1);
        region.setOperation(op);
        region.addPosition(new Pos(0,0));
        assertThrows(RuntimeException.class, () -> region.operationChecks());
        board.getTile(new Pos(0,0)).setValue(1);
        assert (region.operationChecks());
    }

    @Test
    public void test() {
        // Crear un tablero de ejemplo con un tamaño específico
        Board board = new Board(4); // Tamaño del tablero de ejemplo

        // Crear una región con casillas y una operación definida
        Region region = board.newRegion();
        region.addPosition(new Pos(0, 0));
        region.addPosition(new Pos(0, 1));
        region.addPosition(new Pos(1, 1));
        region.addPosition(new Pos(1, 0));
        Operation operation = new OperationMult(); // Por ejemplo, una operación de multiplicación
        region.setResult(54); // Resultado esperado de la operación
        region.setOperation(operation);

        // Asignar valores a las casillas de la región
        board.getTile(new Pos(0, 0)).setValue(2);
        board.getTile(new Pos(0, 1)).setValue(4);
        board.getTile(new Pos(1, 1)).setValue(3);
        board.getTile(new Pos(1, 0)).setValue(3);

        assertFalse(region.operationChecks());
    }

    @Test
    public void test_2() {
        // Crear un tablero de ejemplo con un tamaño específico
        Board board = new Board(4); // Tamaño del tablero de ejemplo

        // Crear una región con casillas y una operación definida
        Region region = board.newRegion();
        region.addPosition(new Pos(0, 0));
        region.addPosition(new Pos(0, 1));
        region.addPosition(new Pos(1, 1));
        region.addPosition(new Pos(1, 0));
        Operation operation = new OperationMult(); // Por ejemplo, una operación de suma
        region.setResult(54); // Resultado esperado de la operación
        region.setOperation(operation);

        // Asignar valores a las casillas de la región
        board.getTile(new Pos(0, 0)).setValue(2);
        board.getTile(new Pos(0, 1)).setValue(3);
        board.getTile(new Pos(1, 1)).setValue(3);
        board.getTile(new Pos(1, 0)).setValue(3);

        assertTrue(region.operationChecks());
    }
}


