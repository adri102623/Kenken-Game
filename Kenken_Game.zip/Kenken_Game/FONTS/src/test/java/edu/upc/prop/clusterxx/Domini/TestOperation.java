package edu.upc.prop.clusterxx.Domini;
import edu.upc.prop.clusterxx.Domini.Operation.*;
import edu.upc.prop.clusterxx.Domini.Board.*;
import org.junit.Test;

import static edu.upc.prop.clusterxx.Domini.Operation.Operation.GetOperation;
import static org.junit.Assert.*;

public class TestOperation {

    private Board board;
    private Region region;

    /**
     * Test que s’encarrega de comprovar que la funció de sumar,
     * sumi de manera correcte els valors de la regió.
     * Per això, les caselles han de tindre un valor asignat.
     */
    @Test
    public void operaciotestsuma() {
        Board tau = new Board(3);
        Region reg = tau.newRegion();

        reg.setInitialPos(new Pos(0, 0));
        reg.addOffset(new Pos(0, 0));
        reg.addOffset(new Pos(0, 1));
        reg.addOffset(new Pos(1, 0));

        tau.getTile(new Pos(0, 0)).setValue(1);
        tau.getTile(new Pos(0, 1)).setValue(2);
        tau.getTile(new Pos(1, 0)).setValue(3);

        Operation op = new OperationAddition();

        int res = op.applyOperation(reg);

        assertEquals(6, res);
    }

    /**
     * Test que s’encarrega de comprobar que la funció de restar, resti de manera correcte els valors de la regió.
     * Aquesta regió només podrà tindre dos caselles amb valors. El resultat serà sempre positiu.
     */
    @Test
    public void operaciotestresta() {
        Board tau = new Board(2);
        Region reg = tau.newRegion();

        reg.setInitialPos(new Pos(0, 0));
        reg.addOffset(new Pos(0, 0));
        reg.addOffset(new Pos(1, 0));

        tau.getTile(new Pos(0, 0)).setValue(1);
        tau.getTile(new Pos(1, 0)).setValue(3);

        Operation op = new OperationSubtraction();

        int res = op.applyOperation(reg);

        assertEquals(2, res);
    }

    /**
     * Test que s’encarrega de comprovar que la funció de multiplicar,
     * multipliqui de manera correcte els valors de la regió. Per això, les caselles han de tindre un valor asignat.
     */
    @Test
    public void operaciotestmulti() {
        Board tau = new Board(5);
        Region reg = tau.newRegion();

        reg.setInitialPos(new Pos(0, 0));
        reg.addOffset(new Pos(0, 0));
        reg.addOffset(new Pos(1, 0));
        reg.addOffset(new Pos(2, 0));
        reg.addOffset(new Pos(2, 1));
        reg.addOffset(new Pos(3, 1));


        tau.getTile(new Pos(0, 0)).setValue(1);
        tau.getTile(new Pos(1, 0)).setValue(3);
        tau.getTile(new Pos(2, 0)).setValue(7);
        tau.getTile(new Pos(2, 1)).setValue(6);
        tau.getTile(new Pos(3, 1)).setValue(2);

        Operation op = new OperationMult();

        int res = op.applyOperation(reg);

        assertEquals(252, res);
    }

    /**
     * Test que s’encarrega de comprovar que la funció d’elevar, elevi de manera correcte els valors de la regió.
     * Aquesta regió és només de dos caselles i pot elevar a^b o b^a.
     */
    @Test
    public void operaciotestelevar() {
        Board tau = new Board(2);
        Region reg = tau.newRegion();


        reg.setInitialPos(new Pos(0, 0));
        reg.addOffset(new Pos(0, 0));
        reg.addOffset(new Pos(1, 0));


        tau.getTile(new Pos(0, 0)).setValue(4);
        tau.getTile(new Pos(1, 0)).setValue(5);

        Operation op = new OperationRaise();
        reg.setResult(625);

        reg.setOperation(op);
        int res = op.applyOperation(reg);

        assertEquals(625, res);
    }

    /**
     * Test que s’encarrega de comprovar que la funció de dividir, divideixi de manera correcte els valors de la regió.
     * Per això, les caselles han de tindre un valor asignat i també han de ser dos caselles.
     */
    @Test
    public void operaciotestdivision() {
        Board tau = new Board(2);
        Region reg = tau.newRegion();


        reg.setInitialPos(new Pos(0, 0));
        reg.addOffset(new Pos(0, 0));
        reg.addOffset(new Pos(1, 0));


        tau.getTile(new Pos(0, 0)).setValue(4);
        tau.getTile(new Pos(1, 0)).setValue(20);

        Operation op = new OperationDiv();
        reg.setResult(5);

        reg.setOperation(op);
        int res = op.applyOperation(reg);

        assertEquals(5, res);
    }

    /**
     * Test que s’encarrega de comprovar que la funció de fer l’arrel quadrada, ho calculi de manera correcte els valors de la regió.
     * Aquesta regió només pot tindre una casella assignada.
     */
    @Test
    public void operaciotestraizcuadrada() {
        Board tau = new Board(2);
        Region reg = tau.newRegion();


        reg.setInitialPos(new Pos(0, 0));
        reg.addOffset(new Pos(0, 0));
        reg.addOffset(new Pos(1, 0));


        tau.getTile(new Pos(0, 0)).setValue(4);
        tau.getTile(new Pos(1, 0)).setValue(16);

        Operation op = new OperationDiv();
        reg.setOperation(op);

        int res = op.applyOperation(reg);

        assertEquals(4, res);
    }

    /**
     * En aquesta funció comprovem que per cada operació es crei bé el tipus d'instancia, segons si es una suma, resta, multiplicació, divisió, elevar o arrel.
     * Ja que aquestes son subclasses de Operació.
     */
    @Test
    public void testOperacioCodi() {
        // Prueba para cada código válido
        for (int i = 1; i <= 6; i++) {
            Operation operacion = GetOperation(i);
            assertNotNull(operacion); // Verifica que se devuelve una operación
            // Verifica que la clase de la operación sea la esperada para cada código
            switch (i) {
                case 1:
                    assertTrue(operacion instanceof OperationAddition);
                    break;
                case 2:
                    assertTrue(operacion instanceof OperationSubtraction);
                    break;
                case 3:
                    assertTrue(operacion instanceof OperationMult);
                    break;
                case 4:
                    assertTrue(operacion instanceof OperationDiv);
                    break;
                case 5:
                    assertTrue(operacion instanceof OperationRaise);
                    break;
                case 6:
                    assertTrue(operacion instanceof OperationSquareRoot);
                    break;
                default:
                    throw new IllegalArgumentException("numero invalido");
            }
        }
    }

    /**
     * Test que s’encarrega de comprovar que la funció de sumar, sumi de manera correcte els valors de la regió.
     * Per això, les caselles han de tindre un valor asignat.
     */
    @Test
    public void codi(){
        OperationAddition op = new OperationAddition();
        assertEquals(1, op.getCode());

        OperationSubtraction op2 = new OperationSubtraction();
        assertEquals(2, op2.getCode());

        OperationMult op3 = new OperationMult();
        assertEquals(3, op3.getCode());

        OperationDiv op4 = new OperationDiv();
        assertEquals(4, op4.getCode());

        OperationRaise op5 = new OperationRaise();
        assertEquals(5, op5.getCode());

        OperationSquareRoot op6 = new OperationSquareRoot();
        assertEquals(6, op6.getCode());
    }

    /**
     * Test per comprovar que retorni bé el nom de cada instancia, si es suma, resta…
     */
    @Test
    public void getnom(){
        Operation op = new OperationDiv();
        assertEquals("Divisio", op.getName());
    }


}
