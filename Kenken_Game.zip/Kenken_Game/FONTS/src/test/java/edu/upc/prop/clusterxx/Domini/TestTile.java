package edu.upc.prop.clusterxx.Domini;

import edu.upc.prop.clusterxx.Domini.Board.Tile;
import org.junit.Test;

import static org.junit.Assert.*;
public class TestTile {
    /**
     * Test per comprovar que la casella es crei bé, es crea una casella nova sense valor,, si no pot es llença una excepció.
     */
    @Test
    public void constructor() {
        boolean exception = false;
        try {
            Tile c = new Tile(0);
        } catch (IllegalArgumentException e) {
            exception = true;
        }
        assert (exception);

        exception = false;
        try {
            Tile c = new Tile(-1);
        } catch (IllegalArgumentException e) {
            exception = true;
        }
        assert (exception);
    }

    /**
     * Test per comprovar que la casella té un valor, on li assignem un valor i retorna que sí que hi ha un valor per aquella casella.
     */
    @Test
    public void hasValue() {
        Tile c = new Tile();
        c.setValue(5);
        assert (c.hasValue());
    }

    /**
     * És el mateix test que abans per`ara volem comprovar que la casella no té valor, llavors creem una casella sense valor i ens retorna que no té valor.
     */
    @Test
    public void hasValue2() {
        Tile c = new Tile();
        assertFalse (c.hasValue());
    }

    /**
     * En aquest test comprovem que ens retorna el valor correcte de la casella, si hi ha cap problema llença una excepció.
     */
    @Test
    public void getValor() {
        boolean exception = false;
        try {
            Tile c = new Tile();
            c.getValue();
        } catch (RuntimeException e) {
            exception = true;
        }
        assert (exception);
    }

    /**
     * Test per comprovar que s’assgina de manera correcte un valor a una casella.
     */
    @Test
    public void setValor() {
        Tile c = new Tile();
        c.setValue(5);
        assert (c.getValue() == 5);
    }

    /**
     * Test per comprovar que s’esborra el valor de manera correcte de la casella que volem esborrar el valor, per això primer fem un set_value i després fem removevalue.
     */
    @Test
    public void RemoveValue() {
        boolean exception = false;
        Tile c = new Tile();
        c.setValue(2);
        c.removeValue();
        try {
            c.getValue();
        } catch (RuntimeException e) {
            exception = true;
        }
        assert (exception);
    }
}
