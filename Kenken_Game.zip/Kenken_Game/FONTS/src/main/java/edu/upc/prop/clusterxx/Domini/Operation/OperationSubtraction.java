package edu.upc.prop.clusterxx.Domini.Operation;

import edu.upc.prop.clusterxx.Domini.Board.Region;
import edu.upc.prop.clusterxx.Domini.Board.Tile;
import java.util.Vector;

/**
 * Subclase de Operacio, la cual es la resta de los numeros de la región, siempre siendo dos casillas y restando el grande menos el pequeño.
 */
public class OperationSubtraction extends Operation {

    /**
     *Asigna el nombre de Resta
     */
    public OperationSubtraction() {
        //Le asigna el nombre "Resta"
        super("Resta");
    }

    /**
     * Devuelve el codigo correspondiente a la operacion
     *
     * @return  2
     */
    @Override
    public int getCode() {
        return 2;
    }

    //Metodos



    /**
     *
     *Aplica el calculo restar los valores de la region, recibe una region como parametro que es donde se aplica la operacion
     * @param reg Reg es una region
     * @return a-b siendo a mayor que b
     */
   @Override public int applyOperation(Region reg){
       int res = 0;
       Vector<Tile> vcas = reg.getTiles();
       int p = 0, s = 0;
       if (vcas.size() != 2) throw new IllegalArgumentException("La region deben ser solo dos casillas");
       if (vcas.get(0).hasValue()) p = vcas.get(0).getValue();
       if (vcas.get(1).hasValue()) s = vcas.get(1).getValue();
       if (p > s) res = p-s;
       else res = s-p;
       return res;
    }

    @Override
    public char getChar() {
        return '-';
    }

    @Override
    public int getTileRequired() {return 2;}

}
