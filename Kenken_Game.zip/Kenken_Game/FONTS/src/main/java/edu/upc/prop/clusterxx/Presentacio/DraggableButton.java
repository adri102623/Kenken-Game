package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class DraggableButton extends JPanel {
    public final int i;
    public final int j;
    public DraggableButton(int i, int j) { super(); this.i = i; this.j = j; }
}
