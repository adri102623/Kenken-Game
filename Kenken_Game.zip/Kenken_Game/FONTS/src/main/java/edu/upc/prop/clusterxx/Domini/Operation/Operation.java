package edu.upc.prop.clusterxx.Domini.Operation;

import edu.upc.prop.clusterxx.Domini.Board.Region;

import java.util.Map;
import java.util.TreeMap;
//Clase abstracta porque nunca tendremos una instancia de Operacio, solo de sus subclases (una región es de suma, resta, mult, etc. Nunca de operació)
/**
 * Clase que asigna que tipo de operacion y resultado es cada region. Contiene resultado y el nombre de la operacion
 */
public abstract class Operation {
    /**
     * nomrbe de la operacion, suma, resta...
     */
    private final String name;

    static private Map<Integer, Operation> dictionary;

    /**
     * creadora de operacio, que recibe un nombre como atributo del tipo de operacion
     * @param name nombre de la operacion
     */
    Operation(String name) { this.name = name;}

    /**
     * Inicializa el mapa que se almacena la operación correspondiente a cada código.
     */
    public static void init() {
        dictionary = new TreeMap<>();
        dictionary.put(1, new OperationAddition());
        dictionary.put(2, new OperationSubtraction());
        dictionary.put(3, new OperationMult());
        dictionary.put(4, new OperationDiv());
        dictionary.put(5, new OperationRaise());
        dictionary.put(6, new OperationSquareRoot());
    }

    /**
     * Devuelve la operación asociada con el código.
     * @param code Número en funcion de la operación. Entre 1 y 6 incluídos.
     * @return Operación que corresponde al código.
     */
    public static Operation GetOperation(int code) {
        if (code < 1 || code > 6) throw new IllegalArgumentException("1 <= code <= 6");
        //Aquí para no tener que llamar a init en todos los tests.
        //Se puede poner una llamada al inicio del programa para ahorrarse esta.
        if (dictionary == null) init();
        return dictionary.get(code);
    }

    /**
     *Devuelve el codigo necesario de cada tipo de operacion
     * @return x, siendo x en [1,6];
     */
    public abstract int getCode();

    /**
     * Aplica la operacion a la region, recibe como parametro una region.
     * @param reg region no vacia
     * @return resultado de la operacion
     */
    public abstract int applyOperation(Region reg);

    /**
     *Devuelve el nombre de la operacion
     * @return nom
     */
    public String getName(){
        return name;
    }

    /**
     * Devuelve el carácter que se mostrara en el tablero.
     *
     * @return El carácter que define la operación.
     */
    public abstract char getChar();

    /**
     * Devuelve la cantidad de casillas necesarias para la operación o -1 si no hay límite.
     *
     * @return La cantidad de casillas necesarias para la operación o -1 si no hay límite.
     */
    public int getTileRequired() { return -1; }
}
