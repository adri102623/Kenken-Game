package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Esta clase contiene el tablero del KenKen y los métodos con los que el usuario modificará su estado (lectura de teclado y botones numerados).
 */
public class KenKenPresentacio extends JPanel implements ActionListener, KeyListener {

    BoardPresentation boardPresentation;
    CtrlPresentacio ctrlPresentacio;

    public KenKenPresentacio(CtrlPresentacio ctrlPresentacio) {
        super(new GridBagLayout());
        TilePresentacio.setTileSize(ctrlPresentacio.getBoardSize() >= 7 ? 50 : 75);
        this.ctrlPresentacio = ctrlPresentacio;
        GridBagConstraints c = new GridBagConstraints();

        boardPresentation = new BoardPresentation(ctrlPresentacio, this, null);
        c.gridx = 1;
        c.insets = new Insets(30, 10, 30, 10);
        add(boardPresentation, c);

        c = new GridBagConstraints();
        int size = ctrlPresentacio.getBoardSize();
        NumberSelector selector = new NumberSelector(size, this);
        c.insets = new Insets(10, 10, 10, 10);
        c.gridx = 0;
        add(selector, c);
    }

    public IRefreshable getRefreshable() {
        return boardPresentation;
    }

    private void setValue(int value) {
        int[] pos = boardPresentation.getSelectedIndex();
        if (pos == null) return;
        ctrlPresentacio.setValue(pos[0], pos[1], value);
        boardPresentation.updateSelectedValue();
    }

    //Debería mirar el código o la string para que no haya errores si se involucran más acciones.
    public void actionPerformed(ActionEvent e) {
        setValue(Integer.parseInt(e.getActionCommand()));
    }

    public void keyTyped(KeyEvent e) {
    }

    public void keyPressed(KeyEvent e) {
        char c = e.getKeyChar();
        if (c >= '0' && c <= '9') {
            setValue(Integer.parseInt("" + (c - '0')));
        }
    }

    public void keyReleased(KeyEvent e) {
    }
}
