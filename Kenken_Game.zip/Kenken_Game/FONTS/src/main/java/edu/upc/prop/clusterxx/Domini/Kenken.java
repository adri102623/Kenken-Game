package edu.upc.prop.clusterxx.Domini;

import edu.upc.prop.clusterxx.Domini.Board.Tile;
import edu.upc.prop.clusterxx.Domini.Board.Board;
import edu.upc.prop.clusterxx.Domini.Board.Pos;
import edu.upc.prop.clusterxx.Domini.Board.Region;
import edu.upc.prop.clusterxx.Domini.Operation.Operation;
import edu.upc.prop.clusterxx.Domini.Operation.OperationSquareRoot;

import java.util.*;

public class Kenken extends GameMode {

    //Metodos
    /**
      * Creadora de Kenken
     * @param board  tauler es el tablero que forma el kenken
     */
    public Kenken(Board board){
        super("KenKen", board);
        interactive = true;
    }



    /**
     * Funcion que llama a la funcion privada de pista
     * @return true si hau pista, false en caso contrario
     */
    public boolean clue() {
        return clue(board);
    }

    /**
     * Funcion que se comunica con la funcion privada de resolerkenken
     * @return true si esta bien, false en caso contrario
     */
    public boolean verify() {
        return solve(board.cloneBoard());
    }

    /**
     * Funcion que llama a la funcio privada de solucionar
     * @return true si tiene solucion, false en caso contrario
     */
    public boolean solve() {
        return solve(board);
    }

    /**
     * Funcion que llama a la funcion privada de comprobar
     * @return true si esta bien la solucion, false en caso contrario
     */
    public boolean check() {
        return check(board);
    }

    /**
     * Funcion privada que devuelve una pista
     * @param board tauler es el tablero del kenken
     * @return true si hay pista, false en caso contrario
     */
    private boolean clue(Board board) {
        Board copia = board.cloneBoard();

        if (!solve(copia)){
                System.out.println("No hay solucion");
                return false;
        }

        Vector<Pos> posicionesdisponibles = new Vector<Pos>();

        for(int i = 0; i < copia.getSize(); ++i){
            for (int j = 0; j < copia.getSize(); ++j){
                Pos posicion = new Pos(i,j);
                if (!board.getTile(posicion).hasValue()) {
                    posicionesdisponibles.add(posicion);
                }
            }
        }

        if (!posicionesdisponibles.isEmpty()){
            Random random = new Random();
            int random_index = random.nextInt(posicionesdisponibles.size());
            Pos posicion_aleatoria = posicionesdisponibles.get(random_index);

            int valor = copia.getTile(posicion_aleatoria).getValue();
            if (valor != -1){
                board.getTile(posicion_aleatoria).setValue(valor);
            } else {
                System.out.println("No se puede proporcionar valor");
                return false;
            }
        }
        else {
            System.out.println("No hay mas casillas sin escribir");
            return false;
        }
        //Este return seguramente está mal y es solo para que no de error llamar a Pista(tauler).
        return true;
    }

    /**
     * funcion que comprueba que el valor generado sea valido para esa casilla
     * @param board tablero del kenken
     * @param posicion posicion de la casilla
     * @param valor valor que queremos comprobar que sea valido
     * @return true si es valido, false en caso contrario
     */
    private static boolean validTileValue(Board board, Pos posicion, int valor){
        if (valor < 1 || valor > board.getSize()){
            return false;
        }

        Pos npos = new Pos(posicion.i, 0);
        for (int colum = 0; colum < board.getSize(); ++colum){
            if (colum == posicion.j) continue;
            npos.j = colum;
            Tile tile = board.getTile(npos);
            if (tile.hasValue() && tile.getValue() == valor)
                return false;
        }

        npos.j = posicion.j;
        for (int fila = 0; fila < board.getSize(); ++fila){
            if (fila == posicion.i) continue;
            npos.i = fila;
            Tile tile = board.getTile(npos);
            if (tile.hasValue() && tile.getValue() == valor)
                return false;
        }
        return true;
    }

    /**
     * Funcion privada que soluciona el tablero
     * @param board tablero a solucionar
     * @return true si tiene solucion, false si no tiene solucion
     */
    public static boolean solve(Board board) {
        //return solveKenKen(board,0,0);
        Vector<Region> regions = board.getRegions();
        regions.sort(new Comparator<Region>() {
            @Override
            public int compare(Region region, Region t1) {
                int r1Size = region.getSize();
                int r2Size = t1.getSize();
                if ((r1Size == 1 && region.getOperacio().getClass() != OperationSquareRoot.class)
                        || (r2Size == 1 && t1.getOperacio().getClass() != OperationSquareRoot.class))
                    return Integer.compare(r1Size, r2Size);
                int r1Top = region.getTopLeftPos().i;
                int r2Top = t1.getTopLeftPos().i;
                if (r1Top == r2Top) {
                    int r1Left = region.getTopLeftPos().j;
                    int r2Left = t1.getTopLeftPos().j;
                    if (r1Left == r2Left) return Integer.compare(r1Size, r2Size);
                    return Integer.compare(r1Left, r2Left);
                }
                return Integer.compare(r1Top, r2Top);
            }
        });

        Vector<Pos> positions = new Vector<>();
        for (Region region : regions) {
            positions.addAll(region.getPositions());
        }

        return solve(board, positions.toArray(new Pos[0]), 0);
    }

    private static boolean solve(Board board, Pos[] positions, int index) {
        if (index == positions.length) return true;

        Pos pos = positions[index];
        Tile tile = board.getTile(pos);
        Region region = board.getRegion(pos);
        if (tile.hasValue()) return (!region.isCompleted() || region.operationChecks()) && solve(board, positions, index + 1);

        for (int i = 1; i <= board.getSize(); i++) {
            if (validTileValue(board, pos, i)) {
                tile.setValue(i);
                if ((!region.isCompleted() || region.operationChecks()) && solve(board, positions, index + 1))
                    return true;
                tile.removeValue();
            }
        }

        return false;
    }


    /**
     * Funcion que comprueba que las regiones del tablero esten correctamente resueltas
     * @param board talero para comprobar las regiones
     * @return true si esta todo bien, false si alguna region es incorrecta
     */
    private static boolean check(Board board) {

        for (int i = 0; i < board.getSize(); i++) {
            for (int j = 0; j < board.getSize(); j++) {
                Tile tile = board.getTile(new Pos(i, j));
                if (!tile.hasValue()) return false;
                //Esta forma de mirarlo es muy ineficiente.
                //En caso de tener problemas por tiempo de procesado, es una optimización simple.
                if (!validTileValue(board, new Pos(i, j), tile.getValue()))
                    return false;
            }
        }

        for (Region region : board.getRegions()){
            if (!region.operationChecks()) return false;
        }
        return true;
    }
}
