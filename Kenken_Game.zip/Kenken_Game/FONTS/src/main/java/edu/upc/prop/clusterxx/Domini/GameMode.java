package edu.upc.prop.clusterxx.Domini;

import edu.upc.prop.clusterxx.Domini.Board.Board;


/**
 * La clase Joc contiene un tablero y los métodos para solucionarlo.
 * Además, también define si se puede interactuar con este.
 */
public abstract class GameMode {
    /**
     * El nombre del modo de juego. Por ejemplo "KenKen" o "KenKen Inverso".
     * Se asigna en el constructor y una vez asignado no se puede modificar.
     */
    private final String modeName;

    /**
     * Si se puede interactuar con el tablero.
     */
    protected boolean interactive;

    /**
     * Tablero en el que está jugando.
     */
    protected Board board;

    //Metodos

    /**
     * Constructor.
     *
     * @param nom Nombre del modo de juego.
     * @param board Tablero que se asignará al juego.
     */
    protected GameMode(String nom, Board board) {
        modeName = nom;
        this.board = board;
    }

    /**
     * @return El tablero donde se está jugando el juego.
     */
    public Board getBoard() {
        return board;
    }

    /**
     * @return Nombre del modo de juego.
     */
    public String getModeName() {
        return modeName;
    }

    /**
     * @return Si el juego es interactuable.
     */
    public boolean isInteractive() {
        return this.interactive;
    }

    /**
     * Asigna el valor de interactuable.
     *
     * @param value Si el juego es interactuable.
     */
    public void setInteractive(boolean value) { interactive = value; }

    //Añade una pista al tablero

    /**
     * Intenta añadir una pista al tablero.
     * En caso de que el tablero no tenga solución devuelve falso.
     *
     * @return Si se ha podido dar una pista.
     *
     */
    public abstract boolean clue();

    /**
     * Comprueba que el tablero tiene solución pero no lo soluciona.
     *
     * @return Si el tablero tiene solución
     */
    public abstract boolean verify();

    /**
     * Intenta resolver el tablero.
     * Devuelve falso si el tablero no tiene solución.
     *
     * @return Si el tablero tiene solución.
     */
    public abstract boolean solve();


    /**
     * Devuelve si el tablero está solucionado.
     *
     * @return Si el tablero está solucionado.
     */
    public abstract boolean check();
}
