package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


/**
 * Clase que genera la vista de Sign in, para registrarse como nuevo usuario. En ella nos pedirá, un username y una contraseña que tendremos que poner dos veces para asegurarnos que es correcta.
 */
public class Signin extends JFrame {
    private static CtrlPresentacio CP;
    private JPanel loginPanel;
    private JLabel userlabel;
    private JLabel passwordlabel;
    private JTextField userfield;
    private JPasswordField passwordfield;
    private JPasswordField repeatpasswordfield;
    private JButton cretebutton;
    private JLabel repeatpassword;


    public Signin (JFrame frame, CtrlPresentacio CP){
        super("Registration");
        Signin.CP = CP;
        signin_ini();
        this.pack();
        this.setResizable(false);
        this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        this.setMinimumSize(new Dimension(500,300));
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = this.getSize();
        this.setLocation(new Point((screenSize.width - frameSize.width) / 3, (screenSize.height - frameSize.height) / 3));
    }


    private void signin_ini(){
        this.loginPanel = new JPanel();
        this.userfield = new JTextField();
        this.userlabel = new JLabel();
        this.passwordlabel = new JLabel();
        this.passwordfield = new JPasswordField();
        this.repeatpasswordfield = new JPasswordField();
        this.cretebutton =  new JButton();
        this.repeatpassword =  new JLabel();


        this.loginPanel.setBackground(new Color(245, 239, 211));
        this.loginPanel.setBorder(BorderFactory.createEtchedBorder());
        this.loginPanel.setBounds(20,80,20,80);

        this.userlabel.setText("Username:");
        userlabel.setFont(new Font("Montserrat", Font.BOLD, 16));
        this.userlabel.setAlignmentX(1);
        this.userfield.setAlignmentX(1);
        userfield.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        this.passwordlabel.setText("Password:");
        passwordlabel.setFont(new Font("Montserrat", Font.BOLD, 16));
        this.passwordlabel.setAlignmentX(1);
        this.repeatpassword.setText("Repeat password");
        repeatpassword.setFont(new Font("Montserrat", Font.BOLD, 16));
        this.passwordfield.setAlignmentX(1);
        passwordfield.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        repeatpasswordfield.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        this.cretebutton.setForeground(new Color(0,0,255));
        this.cretebutton.setText("Create");
        this.cretebutton.setAlignmentX(1);

        this.cretebutton.addMouseListener(new MouseAdapter() {

        });
        this.cretebutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                Signin.this.signinbuttonclicked(actionEvent);
            }
        });


        loginPanel.setLayout(new GridLayout(0,1));

        loginPanel.add(userlabel);
        loginPanel.add(userfield);
        loginPanel.add(passwordlabel);
        loginPanel.add(passwordfield);
        loginPanel.add(repeatpassword);
        loginPanel.add(repeatpasswordfield);
        JPanel panel = new JPanel(new FlowLayout());
        panel.add(cretebutton);


        this.add(panel,BorderLayout.SOUTH);
        this.add(loginPanel);
    }



    private void signinbuttonclicked(ActionEvent actionEvent) {
        String nom = userfield.getText();
        String contra = String.valueOf(passwordfield.getPassword());
        String contra2 = String.valueOf(repeatpasswordfield.getPassword());
        if (nom.isEmpty() || contra.isEmpty()){
            JOptionPane.showMessageDialog(this,"Must have any character" );
            return;
        }
        if (!contra2.equals(contra)) {
            JOptionPane.showMessageDialog(this,"Passwords have to be same" );
            return;
        }
        if (CP.register(nom, contra)) {
            JOptionPane.showMessageDialog(this,"Username has been created successfully" );
            Window[] windows = Window.getWindows();
            for (Window w: windows) {
                w.dispose();
            }
            MainWindow.init(CP);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this,"Username has already exists" );
            System.out.println("Username already exists");
        }

    }


}
