package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.text.NumberFormat;

/**
 * RegionInspector es un JPanel que muestra un editor para la región que se le asigna.
 */
public class RegionInspector extends JPanel implements ActionListener, PropertyChangeListener {
    private int id = 0;
    private JComboBox operationField;
    private JFormattedTextField resultField;
    private CtrlPresentacio ctrl;
    private BoardPresentation boardPresentation;
    public RegionInspector(CtrlPresentacio ctrl, BoardPresentation boardPresentation) {
        super(new GridBagLayout());
        this.boardPresentation = boardPresentation;
        this.ctrl = ctrl;
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10,10,10,10);
        c.gridx = 0;

        c.gridy = 0;
        JLabel title = new JLabel("Region inspector");
        add(title, c);

        c.gridy = 1;
        operationField = new JComboBox(ctrl.getOperationNames());
        operationField.setSelectedIndex(0);
        operationField.setEnabled(false);
        operationField.addActionListener(this);
        add(operationField, c);

        c.gridy = 2;
        resultField = new JFormattedTextField();
        resultField.setValue(0);
        resultField.setColumns(10);
        resultField.addPropertyChangeListener("value", this);
        add(resultField, c);

        operationField.setEnabled(false);
        resultField.setEnabled(false);
    }

    public void actionPerformed(ActionEvent e) {
        boardPresentation.eraseRegionText(id);
        ctrl.setOperation(id, operationField.getSelectedIndex());
        boardPresentation.writeRegionText(id);
        resultField.setEnabled(operationField.getSelectedIndex() != 0);
    }

    public void propertyChange(PropertyChangeEvent propertyChangeEvent) {
        boardPresentation.eraseRegionText(id);
        ctrl.setResult(id, ((Number)resultField.getValue()).intValue());
        boardPresentation.writeRegionText(id);
    }

    public void setRegion(int id) {
        this.id = id;
        operationField.setEnabled(id != 0);
        operationField.setSelectedIndex(ctrl.getOperation(id));
        resultField.setEnabled(id != 0 && operationField.getSelectedIndex() != 0);
        resultField.setValue(ctrl.getResult(id));
    }

    public void clearRegion() {
        this.id = 0;
        operationField.setEnabled(false);
        operationField.setSelectedIndex(0);
        resultField.setEnabled(false);
        resultField.setValue(0);
    }
}
