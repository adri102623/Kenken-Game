package edu.upc.prop.clusterxx.Domini.User;

import edu.upc.prop.clusterxx.Domini.Statistics;

/**
 * La clase Usuario contiene el nombre, la contrasenya  y las estadisiticas que lo forman.
 * Se basa en registrar al jugador.
 */
public class User {
    //Variables
    /**
     * Nombre del usuario con el cual se identificara.
     */
    private String name;

    /**
     * Contraseña usada para proteger la identidad del usuario.
     */
    private String password;

    /**
     *Estadisticas asginadas al usuario, necesarias para determinar su posicion en los rankings.
     */
    private Statistics stats;



    //Constructores

    /**
     * Crea un usuario con nombre y contraseña vacios y con estadisticas inicializadas a 0.
     */
    public User() {
        this.name = " ";
        this.password = " ";
        this.stats = new Statistics();
    }

    /**
     * Crea un usuario con nombre,contraseña y estadisticas inicializadas a 0.
     * @param name nombre del usuario.
     * @param password contraseña del usuario.
     */
    public User(String name, String password) {
        this.name = name;
        this.password = password;
        this.stats = new Statistics();
    }

    //Métodos

    /**
     * @return Nombre del usuario.
     */
    public String getName() {
        return name;
    }

    /**
     * @return Contraseña del usuario.
     */
    public String getPassword() {
        return password;
    }

    /**
     * Asgina el parametro como nombre del usuario.
     * @param name Nuevo nombre del usuario.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Asgina el parametro como contraseña del usuario.
     * @param password Nueva contraseña del usuario.
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return Estadisticas del usuario.
     */
    public Statistics getStats() {
        return stats;
    }

    /**
     * Incrementa en 1 la estadistica de kenkens creador por el usuario.
     */
    public void modKKCreated() {
        this.stats.setKKCreated(this.stats.getKKCreated()+1);
    }

    /**
     * Actualiza la estadsitica de puntuacion total del usuario sumandole el parametro.
     * @param p Puntuacion a sumar a la total.
     */
    public void modScore(int p) {
        this.stats.setScore(this.stats.getScore()+p);
    }

    /**
     * Incrementa en 1 la estadistica de partidas empezadas por el usuario.
     */
    public void modGameStarted() {
        this.stats.setGamesStarted(this.stats.getGamesStarted()+1);
    }

    /**
     * Incrementa en 1 la estadistica de partidas ganadas por el usuario.
     */
    public void modGameWon() {
        this.stats.setGamesWon(this.stats.getGamesWon() + 1);
    }

    /**
     * Actualiza la estadsitica de tiempo total del usuario sumandole el parametro.
     * @param temps Tiempo a sumar al total.
     */
    public void modTime(Float temps) {
        this.stats.setTotalTime(this.stats.getTotalTime() + temps);
    }

    /**
     * Modifica las estadisticas del usuario asignandole el parametro como nuevas estadisiticas.
     * @param stats Nuevas estadisticas del usuario.
     */
    public void setStats(Statistics stats) {
        this.stats = stats;
    }
}
