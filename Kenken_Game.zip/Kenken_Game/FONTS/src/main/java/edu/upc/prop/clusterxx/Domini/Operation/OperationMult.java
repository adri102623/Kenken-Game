package edu.upc.prop.clusterxx.Domini.Operation;

import edu.upc.prop.clusterxx.Domini.Board.Region;
import edu.upc.prop.clusterxx.Domini.Board.Tile;
import java.util.Vector;

/**
 * Subclase de Operacio, la cual es la multiplicacion de todos los valores de las casillas que forman la region
 */
public class OperationMult extends Operation {

    /**
     *Asigna el nombre de Multiplicacion
     */
    //Metodos
    public OperationMult() {
        //Le asigna el nombre "Multiplicacio"
        super("Multiplicacio");
    }

    /**
     * Devuelve el codigo correspondiente a la operacion
     *
     * @return  3
     */
    @Override
    public int getCode() {
        return 3;
    }



    /**
     *
     *Aplica el calculo de multiplicar los valores de la region, recibe una region como parametro que es donde se aplica la operacion
     * @param reg Reg es una region
     * @return A*B*C*D*...X, SIENDO X VALORES DE LA REGION
     */
    @Override
    public int applyOperation(Region reg){
        int res = 1;
        Vector<Tile> vcas = reg.getTiles();
        for (Tile c : vcas)
            if (c.hasValue())
            res *= c.getValue();
        return res;
    }

    @Override
    public char getChar() {
        return '*';
    }

}
