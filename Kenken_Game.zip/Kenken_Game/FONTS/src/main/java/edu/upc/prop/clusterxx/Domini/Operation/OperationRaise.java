package edu.upc.prop.clusterxx.Domini.Operation;

import edu.upc.prop.clusterxx.Domini.Board.Tile;
import edu.upc.prop.clusterxx.Domini.Board.Region;

import java.util.Vector;

/**
 * Subclase de Operacio, la cual es elevar un número por el otro, siempre seran dos casillas.
 */
public class OperationRaise extends Operation {

    //Metodos
    /**
     *Asigna el nombre de Elevar
     */

    //Constructor de la clase OperacioSuma
    public OperationRaise() {
        //Le asigna el nombre "Elevar"
        super("Elevar");
    }

    /**
     * Devuelve el codigo correspondiente a la operacion
     *
     * @return  5
     */
    @Override
    public int getCode() {
        return 5;
    }


    /**
     *
     *Aplica el calculo de elevar un valor por el otro de la region formada pr dos casillas, recibe una region como parametro que es donde se aplica la operacion
     * @param reg Reg es una region
     * @return a^b o b^a
     */
    public int applyOperation(Region reg){
            Vector<Tile> vcas = reg.getTiles();

            if (vcas.size() != 2) throw new IllegalArgumentException("La region deben ser solo dos casillas");
            int p = 0, s = 0;
            if (vcas.get(0).hasValue()) p = vcas.get(0).getValue();
            if (vcas.get(0).hasValue()) s = vcas.get(1).getValue();

            int res;
            if (s < p) res = (int) Math.pow(p,s);
            res = (int) Math.pow(s,p);

            return res;
    }

    @Override
    public char getChar() {
        return '^';
    }

    @Override
    public int getTileRequired() {return 2;}
}
