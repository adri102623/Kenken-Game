package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import java.awt.*;

public class MainWindow {
    private static JFrame window;
    private static JPanel currentPanel;

    public static void init(CtrlPresentacio ctrlPresentacio) {
        window = new JFrame("Kenken");
        window.setVisible(true);
        window.setJMenuBar(new MainMenuBar(ctrlPresentacio));
        window.pack();
        window.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        window.setMinimumSize(new Dimension(1000,800));
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = window.getSize();
        window.setLocation(new Point((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2));
        currentPanel = new MainMenu(ctrlPresentacio);
        window.add(currentPanel);
    }

    public static void setCurrentPanel(JPanel panel) {
        window.remove(currentPanel);
        currentPanel = panel;
        window.add(currentPanel);
        window.setVisible(true);
        window.pack();
    }

    public static JFrame getWindow() {return window;}

    public static void dispose() {
        window.dispose();
    }
}
