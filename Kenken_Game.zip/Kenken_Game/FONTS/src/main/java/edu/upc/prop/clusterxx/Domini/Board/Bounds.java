package edu.upc.prop.clusterxx.Domini.Board;

/**
 * La clase Bounds se utiliza para almacenar 4 enteros que representan las dimensiones de una región.
 * Está pensada para funcionar de la misma forma que un struct.
 */
class Bounds {
    public int iMin;
    public int iMax;
    public int jMin;
    public int jMax;

    /**
     * Constructor de Bounds.
     *
     * @param iMin Margen superior de la región.
     * @param iMax Margen inferior de la región.
     * @param jMin Margen izquierdo de la región.
     * @param jMax Margen derecho de la región.
     */
    Bounds(int iMin, int iMax, int jMin, int jMax) {
        this.iMin = iMin;
        this.iMax = iMax;
        this.jMin = jMin;
        this.jMax = jMax;
    }
}
