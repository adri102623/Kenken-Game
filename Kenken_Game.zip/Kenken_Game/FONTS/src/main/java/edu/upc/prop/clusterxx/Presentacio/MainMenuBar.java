package edu.upc.prop.clusterxx.Presentacio;

import edu.upc.prop.clusterxx.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class MainMenuBar extends JMenuBar {
    private CtrlPresentacio CP;
    private JMenu file;
    private JMenuItem exit;
    private JMenuItem logOut;
    private JMenuItem userguiaitem;
    private JMenu Options;
    private JLabel userlabel;
    private JLabel userlabelname;

    private JMenuItem opt_user;
    private JMenuItem opt_create;
    private JMenuItem opt_design;
    private JMenuItem opt_mainMenu;
    private JMenuItem opt_play;
    private JMenu opt_ranking;
    private JMenuItem opt_ranking_1;
    private JMenuItem opt_ranking_2;
    private JMenuItem opt_ranking_3;
    private JMenuItem opt_ranking_4;
    private JMenuItem eliminarperfil;

    /**
     * @param CP Control Presentacion
     * Clase creadora de PantallaPrincipal, se encarga de hacer que se visualize la pantalla de una forma determinada
     */
    public MainMenuBar(CtrlPresentacio CP){
        this.CP = CP;
        pp();
    }

    /**
     * Funcion encargada de inicializar los objetos y posicionarlos correctamente. Ademas de añadir logica a botones
     */
    private void pp() {
        this.file = new JMenu("File");
        this.Options = new JMenu("Menu");
        this.exit = new JMenuItem("Exit");
        this.logOut = new JMenuItem("Log out");
        this.userguiaitem = new JMenuItem("User guide");
        this.opt_mainMenu = new JMenuItem("Main menu");
        this.opt_design = new JMenuItem("Design Kenken");
        this.opt_create = new JMenuItem("Create Kenken");
        this.opt_play = new JMenuItem("Play Kenken");
        this.opt_user = new JMenuItem("User settings");
        this.opt_ranking = new JMenu("Show Ranking");
        this.userlabel = new JLabel("Username: ");
        this.userlabelname = new JLabel(CP.getUser());
        this.opt_ranking_1 = new JMenuItem("Wins");
        this.opt_ranking_2 = new JMenuItem("Ratio");
        this.opt_ranking_3 = new JMenuItem("Created Kenkens");
        this.opt_ranking_4 = new JMenuItem("Score");
        this.eliminarperfil = new JMenuItem("Delete Account");


        //Barra superior
        add(file);
        add(Options);
        add(userlabel);
        add(userlabelname);


        file.add(userguiaitem);
        file.addSeparator();
        file.add(eliminarperfil);
        file.addSeparator();
        file.add(logOut);
        file.add(exit);

        userguiaitem.addActionListener(e -> userguia());

        exit.addActionListener(e -> System.exit(0));

        logOut.addActionListener(e -> logoutclicked());

        Options.add(opt_mainMenu);
        opt_mainMenu.addActionListener(e -> MainWindow.setCurrentPanel(new MainMenu(CP)));
        Options.add(opt_user);
        opt_user.addActionListener(e -> userbuttonsclicked());
        Options.add(opt_create);
        opt_create.addActionListener(e -> createkenkenbuttonclicked());
        Options.add(opt_design);
        opt_design.addActionListener(e -> designKenKenButtonClicked());
        Options.add(opt_play);
        opt_play.addActionListener(e -> playkenkenbuttonclicked());
        Options.add(opt_ranking);
        opt_ranking_1.addActionListener(e -> rankingbuttonclicked(1));
        opt_ranking_2.addActionListener(e -> rankingbuttonclicked(2));
        opt_ranking_3.addActionListener(e -> rankingbuttonclicked(3));
        opt_ranking_4.addActionListener(e -> rankingbuttonclicked(4));

        opt_ranking.add(opt_ranking_1);
        opt_ranking.add(opt_ranking_2);
        opt_ranking.add(opt_ranking_3);
        opt_ranking.add(opt_ranking_4);

        eliminarperfil.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                int option = JOptionPane.showOptionDialog(MainWindow.getWindow(), "Are you sure you want to delete the account?", "Delete Account", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null,new String[]{"Yes", "Cancel"}, "Accept");
                if (option == JOptionPane.YES_OPTION) {
                    eliminar();
                }
            }
        });
    }

    private void userguia() {
        Desktop d = Desktop.getDesktop();
        try {
            d.open(new File("Manual_de_Uso.pdf"));
        } catch (IOException var4) {
            JOptionPane.showMessageDialog(this, "No user guide found");
        }
    }

    /**
     * Funcion encargadad de tras clicar el boton de elimianrperfil, elimine el perfil que esta actualmente
     */
    private void eliminar() {
        CP.deleteuser();
        PantallaIni pi = new PantallaIni(CP);
        pi.setVisible(true);
        MainWindow.dispose();
    }


    /**
     * Funcion que sirve para abrir una nueva ventana que es Usersettings, para modificar algun parametro del usuario
     */
    private void userbuttonsclicked() {
        System.out.println("User settings button clicked");
        MainWindow.setCurrentPanel(new Usersettings(CP));
    }

    private void designKenKenButtonClicked() {
        System.out.println("Create kenken button clicked");

        Object[] possibilities = {"1x1", "2x2", "3x3", "4x4", "5x5", "6x6", "7x7", "8x8", "9x9"};
        String s = (String)JOptionPane.showInputDialog(
                this,
                "Please select a size:\n",
                "Select size",
                JOptionPane.PLAIN_MESSAGE,
                null,
                possibilities,
                "3x3");


        //If a string was returned, say so.
        if ((s == null) || (s.length() == 0)) {
            return;
        }

        //Maximum 9x9 kenkens
        int size = s.charAt(0) - '0';

        CP.createBoard(size, false);
        MainWindow.setCurrentPanel(new DesignerPresentacio(this.CP));
    }

    /**
     * Funcion que sirve para abrir una nueva ventana que llama a la clase createkenken, en la cual podra generar un kenekn o crearlo como desee
     */
    private void createkenkenbuttonclicked() {
        MainWindow.setCurrentPanel(new GenerateKenken(CP));
    }

    /**
     *  Funcion que sirve para abrir una nueva ventana, llamando a la clase playkenken y crea una nueva ventana
     */
    private void playkenkenbuttonclicked() {
        System.out.println("Play kenken button clicked");
        //Playkenken pk = new Playkenken(this.user, this.CP);
        MainWindow.setCurrentPanel(new KenKenLoader(CP));
    }

    /**
     * @param n, indica que ranking desea ver
     * Función que sirve para saber que tipo de ranking queremos visualizar, se encarga de llamar a ranking para visualizarlo
     */
    private void rankingbuttonclicked(int n) {
        System.out.println("Ranking button clicked");

        switch (n){
            case 1:
                ranking("Wins");
                break;
            case 2:
                ranking("Ratio");
                break;
            case 3:
                ranking("Created kenkens");
                break;
            case 4:
                ranking("Score");
                break;
            default:
                ranking("Select a type of ranking");
                break;
        }

    }

    /**
     * @param s Tipo de ranking que queremos ver
     *  Se encarga de llamar a la funcion rankingview, para visualizar el ranking que le indicamos
     */
    private void ranking(String s){
        MainWindow.setCurrentPanel(new RankingView(CP.getUser(),this.CP, s));
    }

    private void logoutclicked() {
        CP.setUser("");
        PantallaIni pi = new PantallaIni(CP);
        pi.setVisible(true);
        MainWindow.dispose();
    }
}

