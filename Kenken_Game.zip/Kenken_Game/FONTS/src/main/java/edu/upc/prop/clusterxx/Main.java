package edu.upc.prop.clusterxx;

import edu.upc.prop.clusterxx.Presentacio.CtrlPresentacio;

import javax.swing.*;
import java.util.Scanner;
import java.util.Vector;


public class Main extends JFrame {


    private static CtrlPresentacio CP;
    public static void main(String[] args) throws Exception  {
        CP = new CtrlPresentacio();
    }

}

