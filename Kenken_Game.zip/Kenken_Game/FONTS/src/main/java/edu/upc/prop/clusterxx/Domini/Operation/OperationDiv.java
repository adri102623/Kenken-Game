package edu.upc.prop.clusterxx.Domini.Operation;

import java.util.Vector;

import edu.upc.prop.clusterxx.Domini.Board.Tile;
import edu.upc.prop.clusterxx.Domini.Board.Region;

/**
 * Subclase de Operacio, la cual es la división de dos valores, grande entre pequeño, siempre seran dos casillas.
 */
public class OperationDiv extends Operation {
    //Variables

    /**
     *Asigna el nombre de Divisio
     */
    public OperationDiv() {
        //Le asigna el nombre "Divisio"
        super("Divisio");
    }

    /**
     * Devuelve el codigo correspondiente a la operacion
     *
     * @return  4
     */
    @Override
    public int getCode() {
        return 4;
    }

    //Metodos


    /**
     *
     *Aplica el calculo de dividir dos valores, recibe una region como parametro que es donde se aplica la operacion
     * @param reg Reg es una region
     * @return a/b siendo a mayor que b
     */
    @Override public int applyOperation(Region reg){
        int res = 0;
        Vector<Tile> vcas = reg.getTiles();
        if (vcas.size() != 2) throw new IllegalArgumentException("La region deben ser solo dos casillas");
        int p = vcas.get(0).getValue();
        int s = vcas.get(1).getValue();
        if (p > s) res = p/s;
        else res = s/p;
        return res;
    }

    @Override
    public char getChar() {
        return '/';
    }

    @Override
    public int getTileRequired() {return 2;}
}
