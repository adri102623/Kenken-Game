package edu.upc.prop.clusterxx.Presentacio;

import edu.upc.prop.clusterxx.Domini.CtrlDomini;
import edu.upc.prop.clusterxx.Domini.CtrlDomini.BoardErrorCodes;

import java.util.ArrayList;

/**
 * Clase encargada de la comunicación entre la capa de presentación y la capa de dominio.
 */
public class CtrlPresentacio {

    private CtrlDomini CD;
    private String user;

    public CtrlPresentacio(){
        CD = new CtrlDomini();
        PantallaIni pantallaIni = new PantallaIni(this);
    }


    public String getUser() {
        return user;
    }
    public void setUser(String user) {
        this.user = user;
    }

    public int logInUser(String nom, String password){
        int ret = CD.logInUser(nom,password);
        if (ret == 0) user = nom;
        return ret;
    }
    public boolean register(String nom, String password){
        if (CD.registerUser(nom,password)) {
            user = nom;
            return true;
        }
        return false;
    }
    public boolean newusername(String username, String username2){
        if (CD.changeUsername(username,username2)) {
            user = username2;
            return true;
        }
        return false;
    }
    public void newpassword(String username, String newpassword){
        CD.changepassword(username,newpassword);
    }
    public void deleteuser() {
        CD.deleteUser(user);
    }

    public Object[][] createrankingtable(String s) {
       return CD.getRanking(s);
    }

    //Definitive
    public void createBoard(int size, boolean isInverse) { CD.createEmptyBoard(size, isInverse); }
    public int getRegionCount() {
        return CD.getRegionCount();
    }
    public int[] getRegionIds() { return CD.getRegionIds(); }
    public int[][] getRegionOffsets(int id) { return CD.getRegionOffsets(id); }
    public int[] getRegionBounds(int id) {return CD.getRegionBounds(id); }
    public void setValue(int i, int j, int value) {
        CD.setValue(i, j, value);
    }
    public void setOperation(int id, int code) {CD.setOperation(id, code);}
    public void setResult(int id, int result) {CD.setResult(id, result);}
    public int getTileValue(int i, int j) { return CD.getTileValue(i, j); }
    public int getTileId(int i, int j) { return CD.getTileId(i, j); };
    public String getRegionText(int id) { return CD.getRegionText(id); };
    public int getBoardSize() { return CD.getBoardSize(); }
    public int getOperation(int id) { return CD.getOperation(id); }
    public int getResult(int id) { return CD.getResult(id); }
    public boolean paintTile(int i, int j, int id) { return CD.paintTile(i, j, id); }
    public int paintTile(int i, int j) { return CD.paintTile(i, j); }
    public void clearTileRegion(int i, int j) { CD.clearTileRegion(i,j); }
    public boolean setRegionInitialPos(int id, int i, int j) {return CD.setRegionInitialPos(id, i, j);}
    public boolean clearRegionInitialPos(int id) {
        return CD.clearRegionInitialPos(id);
    }
    public int[] getRegionTopLeftPos(int id) {return CD.getRegionTopLeftPos(id);}
    public int[] getRegionTopLeftOffset(int id) {return CD.getRegionTopLeftOffset(id);}
    public int[] getRegionInitialPos(int id) { return CD.getRegionInitialPos(id); }
    public String[] getOperationNames() { return CD.getOptionNames(); }

    public boolean isRankingValid() {return CD.getGameRankingValid(); }
    public int getGameScore() {return CD.getGameScore();}
    public boolean clue() { return CD.gameClue(); }
    public boolean giveUp() { return CD.gameGiveUp(); }
    public boolean check() { return CD.gameCheck(); }

    public String[] readNamesOficial() {
        return CD.readNamesOficial();
    }
    public String[] readNamesCustom() {
        return CD.readNamesCustom();
    }
    public void loadKenKenCustom(String name, boolean isInverse) {
        CD.createGameCustom(name, isInverse);
    }
    public void loadKenKenOficial(String name, boolean isInverse) {
        CD.createGameOficial(name, isInverse);
    }
    public BoardErrorCodes importKenKen(String[] board, boolean isInverse) { return CD.createGameImported(board, isInverse);}
    public boolean loadGame() {return CD.loadGame();}
    public void saveGame() {
        CD.saveGame();
    }
    public boolean isGameInverse() { return CD.isGameInverse(); }
    public BoardErrorCodes saveBoard(String name) { return CD.saveBoard(name); }

    public void randomkk(int tam, ArrayList<Integer> operacion, int regions, boolean isInverse){
        CD.randomkk(tam, operacion,regions, isInverse);
    }

    public boolean nameKenKenExistCustom(String name){
        String[] namesfitx = CD.readNamesCustom();
        for (int i = 0; i < namesfitx.length; ++i){
            if (namesfitx[i].equals(name)) return false;
        }
        return true;
    }
}
