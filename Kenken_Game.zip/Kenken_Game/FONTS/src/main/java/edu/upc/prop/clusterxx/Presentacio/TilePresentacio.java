package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import javax.swing.plaf.metal.MetalToggleButtonUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * Elemento que representa una casilla en el tablero.
 * Contiene los métodos para actualizarla con llamadas a CtrlPresentacio.
 */
public class TilePresentacio extends JLayeredPane implements ActionListener, MouseListener {
    public final int i;
    public final int j;
    //Se debería hacer privado
    private final CtrlPresentacio ctrl;
    private static int tileSize = 75;
    private JLabel text;
    private JToggleButton button;
    private final BoardPresentation boardPresentation;
    private MouseListener listener;

    //Se construye sin valores asignados (color, bordes, texto, valor)
    public TilePresentacio(int i, int j, CtrlPresentacio ctrlPresentacio, BoardPresentation boardPresentation) {
        this.i = i;
        this.j = j;
        this.ctrl = ctrlPresentacio;
        this.boardPresentation = boardPresentation;

        setLayout(null);
        setPreferredSize(new Dimension(getTileSize(), getTileSize()));
        setMinimumSize(new Dimension(getTileSize(), getTileSize()));

        button = new JToggleButton("");
        button.setBorderPainted(true);
        button.setUI(new MetalToggleButtonUI() {
            protected Color getSelectColor() {
                return button.getBackground().brighter();
            }
        });
        //Pintar el fondo de un color de la tabla mezclado con blanco.
        button.setBackground(Color.WHITE);
        button.setPreferredSize(new Dimension(getTileSize(), getTileSize()));
        button.setMinimumSize(new Dimension(getTileSize(), getTileSize()));
        button.addActionListener(this);
        button.addMouseListener(this);

        //Inicializado con un FlowLayout porque crea espacios si no. Aunque se ponga el borde a 0.
        JPanel layerOne = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        layerOne.add(button);
        layerOne.setBounds(0,0, getTileSize(), getTileSize());
        add(layerOne, Integer.valueOf(0));

        JPanel layerTwo = new JPanel();
        layerTwo.setOpaque(false);
        text = new JLabel("");
        layerTwo.add(text);
        layerTwo.setBounds(0, 0, getTileSize(), 50);
        add(layerTwo, new Integer(1), 0);
    }

    public static int getTileSize() {
        return tileSize;
    }

    public static void setTileSize(int tileSize) {
        TilePresentacio.tileSize = tileSize;
    }

    //Pintar bordes.
    //Si tiene una casilla adyacente de la misma región no pinta ese borde.
    //Si es un borde exterior lo pinta el doble de grueso.
    public void updateBorders() {
        int tileId = ctrl.getTileId(i, j);
        int size = ctrl.getBoardSize();
        button.setBorder(BorderFactory.createMatteBorder(
                (i > 0 && ctrl.getTileId(i - 1, j) == tileId) ? 0 : (i == 0 ? 2 : 1),
                (j > 0 && ctrl.getTileId(i, j - 1) == tileId) ? 0 : (j == 0 ? 2 : 1),
                (i < size-1 && ctrl.getTileId(i + 1, j) == tileId) ? 0 : (i == size-1 ? 2 : 1),
                (j < size-1 && ctrl.getTileId(i, j + 1) == tileId) ? 0 : (j == size-1 ? 2 : 1),
                Color.BLACK
        ));
    }

    public void updateValue() {
        int value = ctrl.getTileValue(i, j);
        button.setText(value != 0 ? ("" + value) : "");
    }

    public void updateColor() {
        button.setBackground(Palette.getColor(getId()));
    }

    public void actionPerformed(ActionEvent e) {
        boardPresentation.tileSelected(this);
    }

    public void setSelected(boolean b) {
        button.setSelected(b);
    }

    public boolean isSelected() {
        return button.isSelected();
    }

    public void setMouseListener(MouseListener listener) {
        this.listener = listener;
    }

    public void setText(String s) {text.setText(s);}

    public void mouseClicked(MouseEvent mouseEvent) {
        if (listener != null) listener.mouseClicked(new MouseEvent(this,
                mouseEvent.getID(),
                mouseEvent.getWhen(),
                mouseEvent.getModifiersEx(),
                mouseEvent.getX(),
                mouseEvent.getY(),
                mouseEvent.getXOnScreen(),
                mouseEvent.getYOnScreen(),
                mouseEvent.getClickCount(),
                mouseEvent.isPopupTrigger(),
                mouseEvent.getButton()));
    }

    public void mousePressed(MouseEvent mouseEvent) {
        if (listener != null) listener.mousePressed(new MouseEvent(this,
                mouseEvent.getID(),
                mouseEvent.getWhen(),
                mouseEvent.getModifiersEx(),
                mouseEvent.getX(),
                mouseEvent.getY(),
                mouseEvent.getXOnScreen(),
                mouseEvent.getYOnScreen(),
                mouseEvent.getClickCount(),
                mouseEvent.isPopupTrigger(),
                mouseEvent.getButton()));
    }

    public void mouseReleased(MouseEvent mouseEvent) {
        if (listener != null) listener.mouseReleased(new MouseEvent(this,
                mouseEvent.getID(),
                mouseEvent.getWhen(),
                mouseEvent.getModifiersEx(),
                mouseEvent.getX(),
                mouseEvent.getY(),
                mouseEvent.getXOnScreen(),
                mouseEvent.getYOnScreen(),
                mouseEvent.getClickCount(),
                mouseEvent.isPopupTrigger(),
                mouseEvent.getButton()));
    }

    public void mouseEntered(MouseEvent mouseEvent) {
        if (listener != null) listener.mouseEntered(new MouseEvent(this,
                mouseEvent.getID(),
                mouseEvent.getWhen(),
                mouseEvent.getModifiersEx(),
                mouseEvent.getX(),
                mouseEvent.getY(),
                mouseEvent.getXOnScreen(),
                mouseEvent.getYOnScreen(),
                mouseEvent.getClickCount(),
                mouseEvent.isPopupTrigger(),
                mouseEvent.getButton()));
    }

    public void mouseExited(MouseEvent mouseEvent) {
        if (listener != null) listener.mouseExited(new MouseEvent(this,
                mouseEvent.getID(),
                mouseEvent.getWhen(),
                mouseEvent.getModifiersEx(),
                mouseEvent.getX(),
                mouseEvent.getY(),
                mouseEvent.getXOnScreen(),
                mouseEvent.getYOnScreen(),
                mouseEvent.getClickCount(),
                mouseEvent.isPopupTrigger(),
                mouseEvent.getButton()));
    }

    public int getId() {
        return ctrl.getTileId(i, j);
    }
}
