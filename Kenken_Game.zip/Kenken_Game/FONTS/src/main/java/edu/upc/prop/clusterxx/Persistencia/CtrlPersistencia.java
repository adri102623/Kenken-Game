package edu.upc.prop.clusterxx.Persistencia;

import edu.upc.prop.clusterxx.Domini.Board.Board;
import edu.upc.prop.clusterxx.Domini.Statistics;
import edu.upc.prop.clusterxx.Domini.User.User;

import java.io.File;
import java.util.ArrayList;

/**
 * Clase que controla la gestion de leer y escribir archivos dentro de la base de datos.
 */
public class CtrlPersistencia {

    /**
     * Funcion que guarda a los usuarios en la base de datos.
     * @param content Representa los usuarios que se van a escribir en la base de datos, cada elemento del array es un usuario y una linea en el archivo.
     * @param fileName Nombre del archivo donde se va a guardar.
     */
    public static boolean writeUsers(String[] content, String fileName) {
        return FileManager.writeFile(content, fileName,"users");
    }

    /**
     * Funcion que guarda un Kenken creado por un usuario.
     * @param content Representa un kenken codificado.
     * @param fileName Nombre del archivo donde se guarda el kenken.
     */
    public static boolean writeKenkenCustom(String[] content, String fileName) {
        return FileManager.writeFile(content, fileName,"kenkencustom");
    }

    /**
     * Funcion que guarda un kenken oficial.
     * @param content  Representa un kenken codificado.
     * @param fileName Nombre del archivo donde se guarda el kenken.
     */
    public static boolean writeKenkenOficials(String[] content, String fileName) {
        return FileManager.writeFile(content, fileName,"kenkenoficials");
    }

    /**
     * Funcion que guarda una partida que esta en curso.
     * @param content Representa una partida codificada, contiene el numero de pistas usadas y el tablero.
     * @param fileName Nombre del archivo donde se guarda la paritda.
     */
    public static boolean writeGames(String[] content, String fileName) {
        return FileManager.writeFile(content, fileName,"games");
    }

    public static boolean deleteGame(String fileName) {
        return FileManager.deleteFile(fileName, "games");
    }

    /**
     * Funcion que lee un kenken custom de la base de datos.
     * @param fileName Nombre del fichero que se lee
     * @return Devuelve el contenido del fichero que se lee en forma de Board.
     */
    public static Board readKenkenCustom(String fileName) {
        String[] aux = FileManager.readFile("kenkencustom", fileName);
        if (aux.length == 0) return null;
        return new Board(String.join(" ", aux));
    }

    /**
     * Funcion que lee un kenken custom de la base de datos.
     * @param fileName Nombre del fichero que se lee.
     * @return Devuelve el contenido del fichero que se lee en forma de Board.
     */
    public static Board readKenkenOficials(String fileName) {
        String[] aux = FileManager.readFile("kenkenoficials", fileName);
        if (aux.length == 0) return null;
        return new Board(String.join(" ", aux));
    }

    /**
     * Funcion que devuelve el nombre de todos los kenkens custom que hay guardados.
     * @return Devuelve los nombres de los kenkens.
     */
    public static String[] readNamesCustom() {
        ArrayList<String> names = new ArrayList<>();

        // Leer nombres de archivos de la carpeta kenkencustom
        File customDir = new File("src/main/data" + File.separator + "kenkencustom");
        if (customDir.exists() && customDir.isDirectory()) {
            File[] customFiles = customDir.listFiles();
            if (customFiles != null) {
                for (File file : customFiles) {
                    if (file.isFile()) {
                        names.add(file.getName());
                    }
                }
            }
        }

        return names.toArray(new String[0]);
    }


    /**
     * Funcion que devuelve el nombre de todos los kenkens oficiales que hay guardados.
     * @return  Devuelve los nombres de los kenkens.
     */
    public static String[] readNamesOficial() {
        ArrayList<String> names = new ArrayList<>();

        // Leer nombres de archivos de la carpeta kenkenoficials
        File officialDir = new File("src/main/data" + File.separator + "kenkenoficials");
        if (officialDir.exists() && officialDir.isDirectory()) {
            File[] officialFiles = officialDir.listFiles();
            if (officialFiles != null) {
                for (File file : officialFiles) {
                    if (file.isFile()) {
                        names.add(file.getName());
                    }
                }
            }
        }

        return names.toArray(new String[0]);
    }

    /**
     * Funcion que lee una partida de la base de datos
     * @param fileName Nombre del fichero que se quiere leer.
     * @return Devuelve la partida codificada en un String[].
     */
    public static String[] readGame(String fileName) {
       return FileManager.readFile("games", fileName);
    }

    /**
     * Funcion que lee los usuarios almacenados en la base de datos.
     * @param fileName Nombre del fichero que se quiere leer.
     * @return Devuelve un array list de Usuarios.
     */
    public static ArrayList<User> readUsers(String fileName) {
        String[] aux = FileManager.readFile("users", fileName);
        ArrayList<User> users = new ArrayList<>();
        for(String linea : aux) {
            String [] aux2 = linea.split(";");
            User u = getUser(aux2);
            users.add(u);
        }
        return users;
    }

    /**
     * Funcion que crea a un Usuario a partir de un String[].
     * @param attributes String[] que representa los atributos del usuario.
     * @return Devuelve un Usuario.
     */
    private static User getUser(String[] attributes) {
        String nom = attributes[0];
        String contra = attributes[1];
        int kkc = Integer.parseInt(attributes[2]);
        int pu = Integer.parseInt(attributes[3]);
        int pe = Integer.parseInt(attributes[4]);
        int pg = Integer.parseInt(attributes[5]);
        Float tt = Float.parseFloat(attributes[6]);

        Statistics e = new Statistics(kkc,pu,pe,pg,tt);
        User u = new User(nom,contra);
        u.setStats(e);
        return u;
    }



}
