package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeListener;

/**
 * Contiene un conjunto de botones numerados que llaman al ActionListener del constructor cuando son clicados.
 */
public class NumberSelector extends JPanel {

    public NumberSelector(int size, ActionListener listener) {
        super(new GridBagLayout());
        int roundedSize = ((size + 2)/2)*2;
        for (int i = 0; i < size + 1; i++) {
            GridBagConstraints c = new GridBagConstraints();
            c.gridx = (2*i)/roundedSize;
            c.gridy = i%(roundedSize/2);
            //c.fill = GridBagConstraints.BOTH;
            //c.anchor = GridBagConstraints.CENTER;
            //c.insets = new Insets(5, 5, 5, 5);
            c.gridwidth = 1;
            c.gridheight = 1;
            c.weightx = 0;
            c.weighty = 0;
            c.insets = new Insets(5,5,5,5);
            JButton b = new JButton("");
            b.addActionListener(listener);
            b.setAction(new AbstractAction("" + (i)) {
                @Override
                public void actionPerformed(ActionEvent actionEvent) {

                }
            });
            b.setPreferredSize(new Dimension(50, 50));
            b.setMinimumSize(new Dimension(50, 50));
            add(b, c);
        }
    }
}
