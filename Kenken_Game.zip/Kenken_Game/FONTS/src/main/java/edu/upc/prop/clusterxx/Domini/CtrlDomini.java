package edu.upc.prop.clusterxx.Domini;

import edu.upc.prop.clusterxx.Domini.Board.Board;
import edu.upc.prop.clusterxx.Domini.Board.Pos;
import edu.upc.prop.clusterxx.Domini.Board.Region;
import edu.upc.prop.clusterxx.Domini.Board.Tile;
import edu.upc.prop.clusterxx.Domini.Operation.Operation;
import edu.upc.prop.clusterxx.Domini.User.User;
import edu.upc.prop.clusterxx.Domini.User.UserManager;

import java.util.*;

import edu.upc.prop.clusterxx.Persistencia.CtrlPersistencia;


/**
 * Solo hay un KenKen y un Usuario cargado a la vez.
 */
public class CtrlDomini {


    //Para hacer más entendibles las funciones.
    public enum BoardErrorCodes {
        VALID,
        NO_OPERATION_ASSIGNED,
        OPERATION_TILE_NUMBER,
        NO_REGION_OR_VALUE_TILE,
        NO_SOLUTION,
        INVALID_ENCODING,
        RWEXEPTION
    }

    /**
     * Usuario Actual.
     */
    private User user = new User();

    /**
     * Game actual, puede ser null si no hay ninguno cargado.
     * Producirá excepción si se accede cuando no está asignado.
     */
    private Game game;

    public CtrlDomini(){
        loadUsers();
    }

    //Para hacer más cortas las funciones
    private GameMode getGameMode() {
        return game.getGameMode();
    }

    /**
     * Crea un kenken con los parámetros asignados y la partida correspondiente.
     *
     * @param tam Tamaño del kenken que se va a crear.
     * @param operacion Operaciones disponibles para el kenken.
     * @param regions número de regiones.
     */
    public void randomkk(int tam, ArrayList<Integer> operacion, int regions, boolean isInverse) {
        KenkenRandom kkR = new KenkenRandom(tam);
        Board board = kkR.kk_random(operacion, regions);
        GameMode kk = isInverse? new InverseKenken(board) : new Kenken(board);
        if (isInverse) ((InverseKenken)kk).initialize();
        game = new Game(user, "Generated", kk, false);
        /*String[] code = kk.board.codify();
        CtrlPersistencia.writeKenkenCustom(code,nomFile);*/
    }

    /**
     * @pre Hay un KenKen cargado.
     * @return Devuelve el KenKen codificado.
     */
    public String[] getCodified() {
        return getGameMode().getBoard().codify();
    }

    /**
     * Devuelve una array con las filas de la tabla de rankings.
     *
     * @param s Orden del ranking. "Wins", "Created KenKens", "Score" o "Ratio".
     * @return Una array con las filas de la tabla.
     */
    public Object[][] getRanking(String s) {
        Map<Integer, List<User>> rank;

        switch(s) {
            case "Wins":
                rank = Ranking.getRWon(UserManager.getUsers());
                return formatRanking(rank);

            case "Created Kenkens":
                rank = Ranking.getRKKCreated(UserManager.getUsers());
                return formatRanking(rank);

            case "Points":
                rank = Ranking.getRScore(UserManager.getUsers());
                return formatRanking(rank);

            case "Ratio":
                rank = Ranking.getRRatio(UserManager.getUsers());
                return formatRanking(rank);

            default:
                return new Object[0][0]; // Devuelve una matriz vacía si no se encuentra el tipo de ranking
        }
    }

    private Object[][] formatRanking(Map<Integer, List<User>> rank) {
        Vector<Object[]> data = new Vector<Object[]>();
        int i = 0;

        for (Map.Entry<Integer, List<User>> entry : rank.entrySet()) {
            int key = entry.getKey();
            List<User> userList = entry.getValue();

           for (User user: userList){
               Object[] line = new Object[3];
               line[0] = 0;
               line[1] = user.getName();
               line[2] = key;
               data.add(line);
               ++i;
           }
        }

        Object[] arr = data.toArray();
        return Arrays.copyOf(arr,arr.length, Object[][].class);
        //esto es ineficiente debido a que hace copia del ranking entero
    }

    /**
     * Devuelve la cantidad de regiones en el tablero.
     * En caso de no haber un tablero para poder devolverlo produce una excepcion.
     *
     * @return La cantidad de regiones en el tablero.
     */
    public int getRegionCount() {
        Board board = getGameMode().getBoard();
        return board.getRegionCount();
    }

    /**
     * Devuelve una array con los ids de todas las regiones, estén o no colocadas en el tablero.
     *
     * @return Una array con los ids de todas las regiones.
     */
    public int[] getRegionIds() {
        Board board = getGameMode().getBoard();
        Vector<Region> regions = board.getRegions();
        int[] ret = new int[regions.size()];
        for (int i = 0; i < regions.size(); i++) {
            ret[i] = regions.get(i).getId();
        }
        return ret;
    }

    /**
     * Devuelve una array de posiciones (array con dos elementos) que corresponde a los offsets de la región.
     *
     * @param id Identificador de la región.
     * @return Una array de posiciones (array con dos elementos) que corresponde a los offsets de la región.
     */
    public int[][] getRegionOffsets(int id) {
        Region region = getGameMode().getBoard().getRegionById(id);
        Vector<Pos> offsets = region.getOffsets();
        int[][] ret = new int[offsets.size()][2];
        for (int i = 0; i < offsets.size(); i++) {
            Pos pos = offsets.get(i);
            ret[i][0] = pos.i;
            ret[i][1] = pos.j;
        }
        return ret;
    }

    /**
     * Devuelve el tamaño de la caja contenedora de la región.
     *
     * @param id Identificador de la región.
     * @return Un array con cuatro elementos que corresponden al tamaño de la caja contenedora de la región: (iMin, iMax, jMin, jMax).
     */
    public int[] getRegionBounds(int id) {
        Region region = getGameMode().getBoard().getRegionById(id);
        return region.getBounds();
    }

    /**
     * Asigna el valor a la posición (i, j).
     *
     * @pre La posición es correcta.
     * @param i Primer índice de la posición.
     * @param j Segundo índice de la posición.
     * @param value Valor que se asignará.
     */
    public void setValue(int i, int j, int value) {
        Board board = getGameMode().getBoard();
        Tile tile = board.getTile(new Pos(i, j));
        if (value == 0) tile.removeValue();
        else tile.setValue(value);
        System.out.println(getGameMode().check());
    }

    /**
     * Devuelve el código de la operación de la región id o 0 si no existe la región o no tiene operación.
     *
     * @param id Identificador de la región.
     * @return El código de la operación de la región id o 0 si no existe la región o no tiene operación.
     */
    public int getOperation(int id) {
        Board board = getGameMode().getBoard();
        Region region = board.getRegionById(id);
        if (region == null) return 0;
        Operation operation = region.getOperacio();
        return operation != null ? operation.getCode() : 0;
    }

    /**
     * Devuelve el resultado de la región id o 0 si la región no existe.
     *
     * @param id Identificador de la región.
     * @return Devuelve el resultado de la región id o 0 si la región no existe.
     */
    public int getResult(int id) {
        Board board = getGameMode().getBoard();
        Region region = board.getRegionById(id);
        if (region == null) return 0;
        return region.getResult();
    }

    /**
     * Asigna la operación code a la región id.
     *
     * @param id Identificador de la región.
     * @param code Código de la operación.
     */
    public void setOperation(int id, int code) {
        Board board = getGameMode().getBoard();
        Region region = board.getRegionById(id);
        if (region == null) return;
        if (code == 0) {
            region.setOperation(null);
            return;
        }
        Operation newOperation = Operation.GetOperation(code);
        region.setOperation(newOperation);
    }

    /**
     * Intenta asignar el resultado result a la región id.
     *
     * @param id Identificador de la región.
     * @param result Resultado de la región.
     */
    public void setResult(int id, int result) {
        Board board = getGameMode().getBoard();
        Region region = board.getRegionById(id);
        if (region == null) return;
        region.setResult(result);
    }

    /**
     * Devuelve el valor de la casilla (i, j) o 0 si no tiene.
     *
     * @param i Índice horizontal.
     * @param j Índice vertical.
     * @return El valor de la casilla (i, j) o 0 si no tiene.
     */
    public int getTileValue(int i, int j) {
        Board board = getGameMode().getBoard();
        Tile tile = board.getTile(new Pos(i, j));
        return tile.hasValue() ? tile.getValue() : 0;
    }

    /**
     * Devuelve el identificador de la región que cubre la casilla o 0 si no hay.
     *
     * @param i Índice horizontal.
     * @param j Índice vertical.
     * @return El identificador de la región que cubre la casilla o 0 si no hay.
     */
    public int getTileId(int i, int j) {
        Board board = getGameMode().getBoard();
        Region region = board.getRegion(new Pos(i, j));
        return region != null ? region.getId() : 0;
    }

    /**
     * Devuelve el texto que describe la operación y el resultado de la región. Por ejemplo: "+3".
     *
     * @param id Identificador de la región.
     * @return Un texto que describe la operación y el resultado o una string vacía.
     */
    public String getRegionText(int id) {
        Board board = getGameMode().getBoard();
        Region region = board.getRegionById(id);
        if (region != null) {
            Operation op = region.getOperacio();
            if (op != null) return region.getResult() + "" + op.getChar();
        }
        return "";
    }

    /**
     * Devuelve el tamaño del tablero del KenKen actual.
     * Puede producir una excepción si no hay un KenKen actualmente.
     *
     * @return El tamaño del tablero del KenKen actual.
     */
    public int getBoardSize() {
        Board board = getGameMode().getBoard();
        return board.getSize();
    }

    /**
     * Intenta extender la región id desde cualquier casilla adyacente a la casilla (i, j).
     *
     * @param i Índice horizontal.
     * @param j Índice vertical.
     * @param id Identificador de la región.
     * @return Si ha sido posible extender la región.
     */
    public boolean paintTile(int i, int j, int id) {
        Board board = getGameMode().getBoard();
        if (board.hasAdjacentRegion(new Pos(i, j), id)) {
            Region region = board.getRegionById(id);
            Region oldRegion = board.getRegion(new Pos(i, j));
            if (oldRegion != null) {
                if (id == oldRegion.getId()) return false;
                oldRegion.removePosition(new Pos(i, j));
                if (oldRegion.getOffsets().isEmpty() || !oldRegion.isConnected()) board.deleteRegion(oldRegion);
            }
            region.addPosition(new Pos(i, j));
            return true;
        }
        return false;
    }

    /**
     * Crea una nueva región que contiene la casilla (i, j).
     *
     * @param i Índice horizontal.
     * @param j Índice vertical.
     * @return El identificador de la nueva región.
     */
    public int paintTile(int i, int j) {
        Board board = getGameMode().getBoard();
        Region region = board.newRegion();
        region.addPosition(new Pos(i, j));
        return region.getId();
    }

    /**
     * Elimina la región de la casilla (i, j).
     * No comprueba que la región continúe siendo válida.
     *
     * @param i Índice horizontal.
     * @param j Índice vertical.
     */
    public void clearTileRegion(int i, int j) {
        Board board = getGameMode().getBoard();
        Region region = board.getRegion(new Pos(i, j));
        if (region != null) {
            region.removePosition(new Pos(i, j));
            if (region.getOffsets().isEmpty() || !region.isConnected()) board.deleteRegion(region);
        }
    }

    /**
     * Devuelve la posición más arriba y a la izquierda, en ese orden, de la región id.
     *
     * @param id Identificador de la región.
     * @return Una array de dos elementos que corresponden a las dos coordenadas de la posición.
     */
    public int[] getRegionTopLeftPos(int id) {
        Board board = getGameMode().getBoard();
        Region region = board.getRegionById(id);
        if (region == null) return null;
        Pos pos = region.getTopLeftPos();
        if (pos == null) return null;
        return new int[]{pos.i, pos.j};
    }

    /**
     * Devuelve el offset más arriba y a la izquierda, en ese orden, de la región id.
     *
     * @param id Identificador de la región.
     * @return Una array de dos elementos que corresponden a las dos coordenadas del offset.
     */
    public int[] getRegionTopLeftOffset(int id) {
        Board board = getGameMode().getBoard();
        Region region = board.getRegionById(id);
        if (region == null) return null;
        Pos pos = region.getTopLeftOffset();
        if (pos == null) return null;
        return new int[]{pos.i, pos.j};
    }

    /**
     * Devuelve la posición de referencia de la región.
     *
     * @param id identificador de la región.
     * @return La posición de referencia de la región.
     */
    public int[] getRegionInitialPos(int id) {
        Board board = getGameMode().getBoard();
        Region region = board.getRegionById(id);
        Pos initialPos = region.getInitialPos();
        if (initialPos == null) return new int[]{-1, -1};
        else return new int[] {initialPos.i, initialPos.j};
    }

    /**
     * Intenta colocar la región id en la posición (i, j).
     *
     * @param id Identificador de la región.
     * @param i Componente vertical.
     * @param j Componente horizontal.
     * @return Si se ha colocado la región.
     */
    public boolean setRegionInitialPos(int id, int i, int j) {
        Region region = getGameMode().getBoard().getRegionById(id);
        if (!region.canPlaceInitialPos(new Pos(i, j))) return false;
        region.setInitialPos(new Pos(i, j));
        System.out.println(getGameMode().check());
        return true;
    }

    /**
     * Intenta desasignar la región del tablero.
     *
     * @param id Identificador de la región.
     * @return Si se ha podido desasignar la región.
     */
    public boolean clearRegionInitialPos(int id) {
        Region region = getGameMode().getBoard().getRegionById(id);
        return region.setInitialPos(null);
    }

    //Incluye sin operación
    public String[] getOptionNames() {
        String[] ret = new String[7];
        ret[0] = "";
        for (int i = 1; i <= 6; i++) {
            ret[i] = Operation.GetOperation(i).getName();
        }
        return ret;
    }

    /**
     * Crea una partida con un tablero vacío de dimensiones sizexsize.
     *
     * @param size Tamaño del tablero
     */
    public void createEmptyBoard(int size, boolean isInverse) {
        Board board = new Board(size);
        GameMode kenken = isInverse ? new InverseKenken(board) : new Kenken(board);
        game = new Game(user, "Empty", kenken, false);
    }

    /**
     * Crea una partida con un kenken custom.
     * @param name Nombre de la partida.
     */
    public boolean createGameCustom(String name, boolean isInverse) {
        Board board = CtrlPersistencia.readKenkenCustom(name);
        if (board == null) return false;
        GameMode gm = isInverse ? new InverseKenken(board) : new Kenken(board);
        if (isInverse) ((InverseKenken)gm).initialize();
        game = new Game(user, name, gm, false);
        return true;
    }

    /**
     * Crea una partida con un kenken oficial
     * @param name Nombre de la partida
     */
    public boolean createGameOficial(String name, boolean isInverse) {
        Board board = CtrlPersistencia.readKenkenOficials(name);
        if (board == null) return false;
        GameMode gm = isInverse ? new InverseKenken(board) : new Kenken(board);
        if (isInverse) ((InverseKenken)gm).initialize();
        game = new Game(user,name,gm, !isInverse);
        return true;
    }

    /**
     * Crea la partida con el tablero del parámetro.
     * No comprueba si es un tablero válido.
     * Si falla creándolo devuelve falso.
     *
     * @param encoded Kenken codificado.
     * @return Si ha sido posible crear el tablero.
     */
    public BoardErrorCodes createGameImported(String[] encoded, boolean isInverse) {
        Board board;

        try {
            board = new Board(String.join(" ", encoded));
        } catch (Exception e) {
            return BoardErrorCodes.INVALID_ENCODING;
        }

        BoardErrorCodes ret = board.isValid();
        if (ret != BoardErrorCodes.VALID) return ret;

        GameMode gm = isInverse ? new InverseKenken(board) : new Kenken(board);
        if (isInverse) ((InverseKenken)gm).initialize();
        game = new Game(user,"Imported",gm, true);
        return BoardErrorCodes.VALID;
    }

    public int getGameScore() { return game.getScore(); }

    public boolean getGameRankingValid() { return game.isRankingValid(); }

    /**
     * Genera una pista en el kenken
     * @return
     */
    public boolean gameClue() {return this.game.clue();}

    /**
     * Funcion que se usa para que el usuario finalize una partida sin acabar de completar el kenken
     * @return
     */
    public boolean gameGiveUp() {
        boolean ret = this.game.giveUp();
        endGame();
        return ret;
    }

    /**
     * @return Devuelve si el kenken esta resuelto de manera correcta
     */
    public boolean gameCheck() {
        boolean ret = this.game.check();
        if (ret) endGame();
        return ret;
    }

    private void endGame() {
        CtrlPersistencia.deleteGame(user.getName());
        updateUserDB();
    }

    /**
     * Continuar una partida que esta en pausa
     */
    public void continueGame() {this.game.continueGame();}

    /**
     * Poner en pausa la partida
     */
    public void pauseGame() {this.game.pauseGame();}

    /**
     * Carga una partida en Game que esta en la base de datos.
     *
     */
    public boolean loadGame() {
        String[] coded = CtrlPersistencia.readGame(user.getName());
        if (coded.length == 0) return false;

        game = new Game(coded);
        return true;
    }

    /**
     * Devuelve si la partida actual es un kenken inverso.
     *
     * @return Si la partida actual es un kenken inverso.
     */
    public boolean isGameInverse() {
        return game.getGameMode().getClass().getName().equals(InverseKenken.class.getName());
    }

    /**
     * Guarda una partida en la basa de datos
     */
    public void saveGame() {
        String fileName = user.getName();
        CtrlPersistencia.writeGames(game.codify(),fileName);
    }

    /**
     * Intenta guardar el tablero con el nombre name.
     *
     * @param name Nombre del archivo
     * @return Si ha sido posible guardar el tablero.
     */
    public BoardErrorCodes saveBoard(String name) {
        Board board = getGameMode().getBoard();

        BoardErrorCodes ret = board.isValid();
        if (ret != BoardErrorCodes.VALID) return ret;

        if (!CtrlPersistencia.writeKenkenCustom(getGameMode().getBoard().codify(), name)) {
            return BoardErrorCodes.RWEXEPTION;
        }

        user.modKKCreated();
        return BoardErrorCodes.VALID;
    }

    /**
     * Lee los nombres de los kenkens oficiales guardados en la base de datos.
     * @return Devuelve el nombre del los kenkens oficiales guardados.
     */
    public String[] readNamesOficial() {
        return CtrlPersistencia.readNamesOficial();
    }

    /**
     * Lee los nombres de los kenkens customs guardados en la base de datos
     * @return Devuelve el nombre del los kenkens custom guardados
     */
    public String[] readNamesCustom() {
        return CtrlPersistencia.readNamesCustom();
    }

    /**
     * Carga al UserManager los usuarios que están guardados en la base de datos
     */
    public void loadUsers() {
        ArrayList<User> users = CtrlPersistencia.readUsers("users");
        UserManager.setUsers(users != null ? users : new ArrayList<>());
    }

    /**
     * Guarda los usuarios del userManager en la base de datos.
     */
    public void updateUserDB() {
        CtrlPersistencia.writeUsers(UserManager.codifyList(),"users");
    }

    /**
     * Intenta iniciar sesión del usuario user con la contraseña pwd.
     *
     * @param user Usuario
     * @param pwd Contraseña
     * @return 0 si se ha podido iniciar sesión o el código de error si no. -1 (Usuario ya existe). -2 (Contraseña incorrecta).
     */
    public int logInUser(String user, String pwd){
        if (UserManager.exist(user) == -1) return 1;
        else if (!UserManager.pwdCorrect(user,pwd)) return 2;
        this.user = UserManager.getUser(user);
        updateUserDB();
        return 0;
    }

    /**
     * Intenta registrar el usuario user con contraseña pwd.
     *
     * @param user Usuario
     * @param pwd Contraseña
     * @return Si se ha podido registrar el usuario.
     */
    public boolean registerUser(String user,String pwd){
        boolean ret = UserManager.add(user,pwd);
        if (ret) {
            this.user = UserManager.getUser(user);
            updateUserDB();
        }
        return ret;
    }

    /**
     * Elimina el usuario user.
     *
     * @param user Usuario
     */
    public void deleteUser(String user){
        if (UserManager.erase(user)) updateUserDB();
    }

    /**
     * @param u Usuario
     * @return Si existe el USuario
     */
    public boolean existsUser(String u) {
        return UserManager.exist(u) != -1;
    }

    /**
     * Comprueba si la contraseña coincide con la del Usuario
     *
     * @param nom Nombre del Usuario
     * @param pwd Contraseña del Usuario
     * @return Si la contraseña es correcta
     */
    public boolean checkUserPwd(String nom, String pwd){
        return UserManager.pwdCorrect(nom,pwd);
    }

    /**
     * Cambia el nombre de un Usuario
     * @param username Usuario al que se le cambia el nombre
     * @param newUsername Nuevo nombre del usuario
     * @return
     */
    public boolean changeUsername(String username, String newUsername){
        return UserManager.modifyName(username,newUsername);
    }

    /**
     * Cambia la constraseña de un Usuario
     * @param user Usuario al que se le cambia la contraseña
     * @param password Contraseña nueva del usuario
     */
    public void changepassword(String user, String password){
        UserManager.modifyPwd(user,password);
    }

}



