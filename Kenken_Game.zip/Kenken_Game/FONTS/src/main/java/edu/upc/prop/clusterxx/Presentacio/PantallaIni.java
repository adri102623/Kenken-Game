package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Esta clase es la encargada de visualizar la pantalla inicial, para iniciar sesion o registrarte si eres un usuario nuevo
 */
public class PantallaIni extends JFrame {
    private CtrlPresentacio CP;

    private JPanel loginPanel;
    private JLabel userlabel;
    private JLabel passwordlabel;
    private JTextField userfield;
    private JPasswordField passwordfield;
    private JButton login;
    private JLabel signin;
    private JLabel text;

    /**
     * @param CP es el Control Presentacion del main
     * Aqui nos encargamos de que se visualize esta primera pantalla del juego.
     */
    public PantallaIni(CtrlPresentacio CP) {
        this.CP = CP;
        ini();
        this.pack();
        this.setVisible(true);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setMinimumSize(new Dimension(500, 300));
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = this.getSize();
        this.setLocation(new Point((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2));
    }

    /**
     * Funcion que sirve para inicializar todos los objetos que vemos y posicionarlos correctamente.
     */
    private void ini() {
        this.loginPanel = new JPanel();
        this.userfield = new JTextField();
        this.userlabel = new JLabel();
        this.passwordlabel = new JLabel();
        this.passwordfield = new JPasswordField();
        this.signin = new JLabel();
        this.login = new JButton();

        this.setTitle("Kenken");

        ImageIcon imageIcon = new ImageIcon(this.getClass().getClassLoader().getResource("Images/prese.png"));
        Image im = imageIcon.getImage();
        Image newImage = im.getScaledInstance(500, 200, Image.SCALE_SMOOTH);
        imageIcon = new ImageIcon(newImage);
        JLabel imagen = new JLabel(imageIcon);

        this.loginPanel.setBackground(new Color(245, 239, 211));
        this.loginPanel.setBorder(BorderFactory.createEtchedBorder());

        this.userlabel.setText("Username:");
        this.userlabel.setFont(new Font("Montserrat", Font.PLAIN, 18));
        this.userlabel.setAlignmentX(1);
        this.userfield.setAlignmentX(1);
        userfield.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        this.passwordlabel.setText("Password:");
        this.passwordlabel.setFont(new Font("Montserrat", Font.PLAIN, 18));
        this.passwordlabel.setAlignmentX(1);
        this.passwordfield.setAlignmentX(1);
        passwordfield.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        this.signin.setForeground(new Color(0, 0, 255));
        this.signin.setText("<html><u>Not registered?</u></html>");
        this.signin.setFont(new Font("Montserrat", Font.PLAIN, 12));
        this.signin.setCursor(new Cursor(Cursor.HAND_CURSOR));
        this.signin.setAlignmentX(1);
        this.signin.setAlignmentX(1);

        this.signin.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                PantallaIni.this.signinlabelclicked(e);
            }
        });

        this.login.setText("Log in");
        this.login.setFont(new Font("Montserrat", Font.PLAIN, 16));
        this.login.setAlignmentX(1);

        this.login.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                PantallaIni.this.loginbuttonactionevent(actionEvent);
            }
        });

        JPanel centerpanel = new JPanel();
        centerpanel.setLayout(new BoxLayout(centerpanel, BoxLayout.Y_AXIS));
        centerpanel.setBackground(new Color(245, 239, 211));


        GroupLayout layoutpantallainicial = new GroupLayout(loginPanel);
        this.loginPanel.setLayout(layoutpantallainicial);


        layoutpantallainicial.setHorizontalGroup(layoutpantallainicial.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layoutpantallainicial.createSequentialGroup().addContainerGap().addGroup(layoutpantallainicial.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.userlabel).addComponent(this.userfield).addComponent(this.passwordlabel).addComponent(this.passwordfield).addComponent(this.signin, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE).addGroup(layoutpantallainicial.createSequentialGroup().addGap(200, 200, 200).addComponent(this.login, -2, 90, -2)))));
        layoutpantallainicial.setVerticalGroup(layoutpantallainicial.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layoutpantallainicial.createSequentialGroup().addGap(29, 29, 29).addComponent(this.userlabel).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.userfield, -2, -1, -2).addGap(18, 18, 18).addComponent(this.passwordlabel).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.passwordfield, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.signin, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.login).addContainerGap()));
        centerpanel.add(imagen);
        this.add(loginPanel);
        this.add(centerpanel, BorderLayout.NORTH);

    }

    /**
     * @param evt Indica que se ha clicado el boton
     * Funcion que sirve para abrir una nueva ventana para registrarse, llamando a la clase signin.
     */
    private void signinlabelclicked(MouseEvent evt) {
        System.out.println("Signin label clicked");
        Signin signin = new Signin(this, this.CP);
        signin.setVisible(true);
    }

    /**
     * @param actionEvent Indica que ha pasado algo con el boton de login
     * Funcion que sirve para iniciar sesion, tras comprobar que existe el usuario y la contraseña es correcta, inicia sesion
     * y llama a la clase PantallaPrincipal
     */
    private void loginbuttonactionevent(ActionEvent actionEvent) {
        String nom = userfield.getText();
        String contra = String.valueOf(passwordfield.getPassword());
        if (nom.equals("") || contra.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Not username");
            return;
        }
        int ret = CP.logInUser(nom,contra);
        if (ret == 1) {
            JOptionPane.showMessageDialog(this, "Username not exists");
        } else if (ret == 2) {
            JOptionPane.showMessageDialog(this, "Password incorrect");
        } else {
            System.out.println("Correct user");
            MainWindow.init(CP);
            this.dispose();
        }
    }

}
