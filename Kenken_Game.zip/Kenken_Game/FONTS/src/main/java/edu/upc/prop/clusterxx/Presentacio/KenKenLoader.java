package edu.upc.prop.clusterxx.Presentacio;

import edu.upc.prop.clusterxx.Domini.CtrlDomini;
import edu.upc.prop.clusterxx.Domini.KenkenRandom;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

/**
 * Contiene un selector de KenKen que permite elegir entre los presentes en la base de datos.
 */
public class KenKenLoader extends JPanel {
    private JList<String> officialList;
    private JScrollPane officialScroll;
    private JList<String> customList;
    private JScrollPane customScroll;
    private JCheckBox isInverseCheck;
    private boolean usingOfficialList = true;
    private CtrlPresentacio ctrlPresentacio;
    JButton returnboton;

    public KenKenLoader(CtrlPresentacio ctrlPresentacio) {
        this.returnboton = new JButton("Return");

        setBackground(new Color(245, 239, 211));

        setLayout(new GridBagLayout());
        this.ctrlPresentacio = ctrlPresentacio;
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);

        JPanel buttons = new JPanel();
        buttons.setBackground(new Color(245, 239, 211));
        buttons.setLayout(new GridBagLayout());
        GridBagConstraints c1 = new GridBagConstraints();
        c1.fill = GridBagConstraints.BOTH;
        c1.insets = new Insets(10,10,10,10);

        JButton continueGameButton = new JButton("Continue last game");
        continueGameButton.addActionListener(e -> loadGame());
        buttons.add(continueGameButton, c1);

        c1.gridy = 1;
        JButton officialButton = new JButton("Official kenkens");
        officialButton.addActionListener(e -> enableOfficialList());
        buttons.add(officialButton, c1);

        c1.gridy = 2;
        JButton customButton = new JButton("Custom kenkens");
        customButton.addActionListener(e -> enableCustomList());
        buttons.add(customButton, c1);

        c1.gridy = 3;
        JButton loadFileButton = new JButton("Load file");
        loadFileButton.addActionListener(e -> loadFile());
        buttons.add(loadFileButton, c1);

        c.gridy = 1;
        add(buttons, c);

        JPanel loadPanel = new JPanel();
        loadPanel.setBackground(new Color(245, 239, 211));
        loadPanel.setLayout(new GridBagLayout());

        c1.gridx = 0;
        c1.gridy = 0;
        JButton loadButton = new JButton("Load");
        loadButton.addActionListener(e -> loadKenKen());
        loadPanel.add(loadButton, c1);

        c1.gridx = 0;
        c1.gridy = 1;
        isInverseCheck = new JCheckBox("Play as inverse kenken");
        loadPanel.add(isInverseCheck, c1);

        c.gridx = 0;
        c.gridy = 0;
        add(loadPanel, c);

        JPanel listHolder = new JPanel();
        listHolder.setBackground(new Color(245, 239, 211));
        listHolder.setLayout(new GridBagLayout());
        c.gridy = 1;
        c.gridx = 1;

        c1.gridx = 0;
        c1.gridy = 0;
        JLabel listTitle = new JLabel("Select KenKen");
        listHolder.add(listTitle, c1);

        c1.gridx = 0;
        c1.gridy = 1;
        officialList = new JList<>(ctrlPresentacio.readNamesOficial());
        officialScroll = new JScrollPane(officialList);
        listHolder.add(officialScroll, c1);
        customList = new JList<>(ctrlPresentacio.readNamesCustom());
        customScroll = new JScrollPane(customList);
        listHolder.add(customScroll, c1);

        add(listHolder, c);

        c.gridy = 3;
        c.gridx = 0;
        add(returnboton,c);

        returnboton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                KenKenLoader.this.volverbuttonclicked(actionEvent);
            }
        });

        setMinimumSize(getMinimumSize());
    }

    /**
     * Esta clase carga el archivo sin pasar por la capa de persistencia porque no está relacionado con la base de datos.
     * Es un archivo que aporta el usuario, no la bd.
     */
    public void loadFile() {
        JFileChooser fc = new JFileChooser();
        int option = fc.showOpenDialog(this);

        if (option != JFileChooser.APPROVE_OPTION) return;

        File file = fc.getSelectedFile();
        ArrayList<String> kenken = new ArrayList<>();
        BufferedReader bf;

        try {
            bf = new BufferedReader(new FileReader(file));

            String line = bf.readLine();
            while (line != null) {
                kenken.add(line);
                line = bf.readLine();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Could not load file.");
            return;
        }

        String[] array = kenken.toArray(new String[0]);

        CtrlDomini.BoardErrorCodes ret = ctrlPresentacio.importKenKen(array, isInverseCheck.isSelected());
        switch (ret) {
            case VALID:
                MainWindow.setCurrentPanel(new GamePresentation(ctrlPresentacio, isInverseCheck.isSelected()));
                break;
            case NO_OPERATION_ASSIGNED:
                JOptionPane.showMessageDialog(this, "There is a region without an operation assigned.", "Error saving", JOptionPane.ERROR_MESSAGE);
                break;
            case OPERATION_TILE_NUMBER:
                JOptionPane.showMessageDialog(this, "There is a region with an invalid number of tiles (-, /, ^ and sqrt require 2; = requires 1).", "Error saving", JOptionPane.ERROR_MESSAGE);
                break;
            case NO_REGION_OR_VALUE_TILE:
                JOptionPane.showMessageDialog(this, "There is a tile without a region or value assigned to it.", "Error saving", JOptionPane.ERROR_MESSAGE);
                break;
            case NO_SOLUTION:
                JOptionPane.showMessageDialog(this, "Current board has no solution.", "Error saving", JOptionPane.ERROR_MESSAGE);
                break;
            case INVALID_ENCODING:
                JOptionPane.showMessageDialog(this, "File format is invalid.", "Error saving", JOptionPane.ERROR_MESSAGE);
                break;
            case RWEXEPTION:
                JOptionPane.showMessageDialog(this, "Error saving to file.", "Error saving", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    public void enableCustomList() {
        usingOfficialList = false;
        customScroll.setVisible(!usingOfficialList);
        officialScroll.setVisible(usingOfficialList);
    }

    public void enableOfficialList() {
        usingOfficialList = true;
        customScroll.setVisible(!usingOfficialList);
        officialScroll.setVisible(usingOfficialList);
    }

    public void loadKenKen() {
        JList<String> list = usingOfficialList ? officialList : customList;
        if (list.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(this,"Please select an element");
            return;
        }
        if (usingOfficialList) ctrlPresentacio.loadKenKenOficial(list.getSelectedValue(), isInverseCheck.isSelected());
        else ctrlPresentacio.loadKenKenCustom(list.getSelectedValue(), isInverseCheck.isSelected());
        MainWindow.setCurrentPanel(new GamePresentation(ctrlPresentacio, isInverseCheck.isSelected()));
    }

    public void loadGame() {
        if (!ctrlPresentacio.loadGame()) {
            JOptionPane.showMessageDialog(this,"Could not load the last game.");
            return;
        }

        MainWindow.setCurrentPanel(new GamePresentation(ctrlPresentacio, ctrlPresentacio.isGameInverse()));
    }

    private void volverbuttonclicked(ActionEvent actionEvent) {
        MainWindow.setCurrentPanel(new MainMenu(ctrlPresentacio));
    }

}
