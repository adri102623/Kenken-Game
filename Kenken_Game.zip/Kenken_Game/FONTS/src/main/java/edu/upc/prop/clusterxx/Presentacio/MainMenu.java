package edu.upc.prop.clusterxx.Presentacio;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

/**
 * Clase que sirve para mostrar las diferentes opciones que tiene el juego, jugar un juego, ver el ranking, crear Kenkens... podemos encontrar las principales funcionalidades
 */
public class MainMenu extends JPanel {
    private CtrlPresentacio CP;
    private JButton userbutton;
    private JButton createbutton;
    private JButton designButton;
    private JButton playbutton;
    private JButton rankingbutton;
    private JPanel buttons;
    private Image imagebackground;


    /**
     * @param CP Control Presentacion
     * Clase creadora de PantallaPrincipal, se encarga de hacer que se visualize la pantalla de una forma determinada
     */
    public MainMenu(CtrlPresentacio CP){
        this.CP = CP;
        pp();
        setMinimumSize(getMinimumSize());
    }

    /**
     * Funcion encargada de inicializar los objetos y posicionarlos correctamente. Ademas de añadir logica a botones
     */
    private void pp() {
        this.userbutton = new JButton("User Settings");
        this.createbutton = new JButton("Create Kenken");
        this.designButton = new JButton("Design Kenken");
        this.playbutton = new JButton("Play Kenken");
        this.rankingbutton = new JButton("Ranking");
        this.buttons = new JPanel();


        //Centro de la pantalla
        buttons.setLayout(new GridBagLayout());
        buttons.setBackground(new Color(245, 239, 211));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;

        gbc.gridx = 0;
        gbc.gridy = 0;
        buttons.add(userbutton,gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        buttons.add(createbutton,gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        buttons.add(playbutton,gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        buttons.add(rankingbutton,gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        buttons.add(designButton, gbc);

        setLayout(new BorderLayout());
        add(buttons, BorderLayout.CENTER);

        userbutton.setPreferredSize(new Dimension(200,200));
        userbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                MainMenu.this.userbuttonsclicked(actionEvent);
            }
        });

        createbutton.setPreferredSize(new Dimension(200,200));
        createbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                MainMenu.this.createkenkenbuttonclicked(actionEvent);
            }
        });

        designButton.setPreferredSize(new Dimension(200,200));
        designButton.addActionListener(e -> designKenKenButtonClicked());

        playbutton.setPreferredSize(new Dimension(200,200));
        playbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                MainMenu.this.playkenkenbuttonclicked(actionEvent);
            }
        });

        rankingbutton.setPreferredSize(new Dimension(200,200));
        rankingbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                MainMenu.this.rankingbuttonclicked(actionEvent,0);
            }
        });
    }

    /**
     * @param actionEvent  evento que ha pasado, en este caso cliclar el boton de user
     * Funcion que sirve para abrir una nueva ventana que es Usersettings, para modificar algun parametro del usuario
     */
    private void userbuttonsclicked(ActionEvent actionEvent) {
        System.out.println("User settings button clicked");
        MainWindow.setCurrentPanel(new Usersettings(CP));
    }

    private void designKenKenButtonClicked() {
        System.out.println("Create kenken button clicked");

        Object[] possibilities = {"3x3", "4x4", "5x5", "6x6", "7x7", "8x8", "9x9"};
        String s = (String)JOptionPane.showInputDialog(
                this,
                "Please select a size:\n",
                "Select size",
                JOptionPane.PLAIN_MESSAGE,
                null,
                possibilities,
                "3x3");


        //If a string was returned, say so.
        if ((s == null) || (s.length() == 0)) {
            return;
        }

        //Maximum 9x9 kenkens
        int size = s.charAt(0) - '0';

        CP.createBoard(size, false);
        MainWindow.setCurrentPanel(new DesignerPresentacio(CP));
    }

    /**
     * @param actionEvent evento que ha pasado, en este caso cliclar el boton de create kenken
     * Funcion que sirve para abrir una nueva ventana que llama a la clase createkenken, en la cual podra generar un kenekn o crearlo como desee
     */
    private void createkenkenbuttonclicked(ActionEvent actionEvent) {
        MainWindow.setCurrentPanel(new GenerateKenken(CP));
    }

    /**
     * @param actionEvent evento que ha pasado, en este caso cliclar el boton de play kenken
     *  Funcion que sirve para abrir una nueva ventana, llamando a la clase playkenken y crea una nueva ventana
     */
    private void playkenkenbuttonclicked(ActionEvent actionEvent) {
        System.out.println("Play kenken button clicked");
        MainWindow.setCurrentPanel(new KenKenLoader(CP));
    }

    /**
     * @param actionEvent evento que ha pasado, en este caso cliclar el boton de ranking
     * @param n, indica que ranking desea ver
     * Función que sirve para saber que tipo de ranking queremos visualizar, se encarga de llamar a ranking para visualizarlo
     */
    private void rankingbuttonclicked(ActionEvent actionEvent, int n) {
        System.out.println("Ranking button clicked");

        switch (n){
            case 1:
                ranking("Wins");
                break;
            case 2:
                ranking("Ratio");
                break;
            case 3:
                ranking("Created kenkens");
                break;
            case 4:
                ranking("Score");
                break;
            default:
                ranking("Select a type of ranking");
                break;
        }

    }

    /**
     * @param s Tipo de ranking que queremos ver
     *  Se encarga de llamar a la funcion rankingview, para visualizar el ranking que le indicamos
     */
    private void ranking(String s){
        MainWindow.setCurrentPanel(new RankingView(CP.getUser(), CP, s));
    }

    private void logoutclicked() {
        CP.setUser("");
        PantallaIni pi = new PantallaIni(CP);
        pi.setVisible(true);
        MainWindow.dispose();
    }
}
