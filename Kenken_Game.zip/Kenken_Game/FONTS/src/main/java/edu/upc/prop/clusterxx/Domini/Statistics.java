package edu.upc.prop.clusterxx.Domini;

/**
 * La clase Estadistica contiene los atributos de cada usuario y los métodos para obtenerlos o modificarlos.
 */
public class Statistics {
    //Variables

    /**
     * Puntuacion total ganada por el usuario al jugar kenkens
     */
    private int score;

    /**
     * Número de partidas terminadas con exito por el usuario.
     */
    private int gamesWon;

    /**
     * Número de Kenkens creados por el usuario.
     */
    private int kkCreated;

    /**
     * Número de Kenkes empezados por el usuario  (no hace falta que se haya completado).
     */
    private int gamesStarted;

    /**
     * Tiempo total del usuario jugando partidas.
     */
    private Float totalTime;

    //Constructores

    /**
     * Construye Estadisticas para un usuario inicalizando los atributos a 0
     */
    public Statistics() {
        this.kkCreated = 0;
        this.score = 0;
        this.gamesStarted = 0;
        this.gamesWon = 0;
        this.totalTime = 0.0F;
    }

    /**
     * Construye Estadisticas asginando los parametros.
     * @param kkc Kenkens Creados
     * @param p Puntuacion
     * @param pe Partidas empezadas
     * @param pg Partidas ganadas
     * @param rv Ratio de victoria
     * @param tt Tiempo total
     */
    public Statistics(int kkc, int p, int pe, int pg, Float tt) {
        this.kkCreated = kkc;
        this.score = p;
        this.gamesStarted = pe;
        this.gamesWon = pg;
        this.totalTime = tt;
    }

    //Mètodos

    /**
     * @return Puntuacion total ganada por el usuario al jugar kenkens
     */
    public int getScore() {
        return score;
    }

    /**
     * @return Número de Kenkens terminados con exito por el usuario.
     */
    public int getGamesWon() {
        return gamesWon;
    }

    /**
     * @return Número de Kenkens creados por el usuario.
     */
    public int getKKCreated() {
        return kkCreated;
    }

    /**
     * @return Número de Kenkes empezados por el usuario  (no hace falta que se haya completado).
     */
    public int getGamesStarted() {
        return gamesStarted;
    }

    /**
     * @return Ratio de victorias del usuario (Partidas emepezadas / Partidas ganadas).
     */
    public int getVictoryRatio() {
        if (gamesStarted == 0) return 0;
        return (100*this.gamesWon)/this.gamesStarted;
    }

    /**
     * @return Tiempo total del usuario jugando partidas.
     */
    public Float getTotalTime() {
        return totalTime;
    }

    /**
     * Asigna el parametro a Kenkens creados por el usuario
     * @param kkCreated Número que se asginará
     */
    public void setKKCreated(int kkCreated) {
        this.kkCreated = kkCreated;
    }

    /**
     * Asigna el parametro a partidas empezadas por el usuario
     * @param gamesStarted Número que se asginará
     */
    public void setGamesStarted(int gamesStarted) {
        this.gamesStarted = gamesStarted;
    }

    /**
     * Asigna el parametro a partidas ganadas por el usuario
     * @param gamesWon Número que se asginará
     */
    public void setGamesWon(int gamesWon) {
        this.gamesWon = gamesWon;
    }

    /**
     * Asigna el parametro a la puntuacion total del usuario
     * @param score Número que se asginará
     */
    public void setScore(int score) {
        this.score = score;
    }

    /**
     * Asigna el parametro al tiempo total jugado de el usuario
     * @param totalTime Número que se asginará
     */
    public void setTotalTime(Float totalTime) {
        this.totalTime = totalTime;
    }
}
