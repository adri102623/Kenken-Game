package edu.upc.prop.clusterxx.Domini;

import edu.upc.prop.clusterxx.Domini.Board.Board;
import edu.upc.prop.clusterxx.Domini.User.User;
import edu.upc.prop.clusterxx.Domini.User.UserManager;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *La clase partida representa una partida de un kenken, que pertenece a un usuario y tiene algunos parametros como un nombre de partida, la puntuacion, tiempo
 */
public class Game {
    //Variables de la clase
    /**
     *name es el nombre de la partida
     */
    private String name;
    /**
     *user es el usuario de la partida
     */
    private User user;
    /**
     *score es la puntuacion de la partida
     */
    private int score;
    /**
     *cluesUsed es el numero de pista usadas durante la partida
     */
    private int cluesUsed;
    /**
     *time es el tiempo total en acabar la partida
     */
    private Float time;
    /**
     *rankingValid es un booleano que sirve para saber si la partida cuenta como valida para puntuar
     */
    private boolean rankingValid;

    private GameMode kenken;

    //Metodos
    //Creadoras



    /**
     * creadora de partida asignando todas las variables
     *
     * @param game Partida codificada
     */
    public Game(String[] game){
        int i = 0;
        this.name = game[i++];
        boolean isInverseValue = game[i++].equals(InverseKenken.class.getName());
        //Esta información es redundante porque el nombre del archivo de la partida ya contiene el usuario.
        //Además, solo el propio usuario puede jugar sus partidas.
        this.user = UserManager.getUser(game[i++]);
        this.score = Integer.parseInt(game[i++]);
        this.cluesUsed = Integer.parseInt(game[i++]);
        this.time = Float.parseFloat(game[i++]);
        this.rankingValid = Boolean.parseBoolean(game[i++]);
        Board board = new Board(String.join(" ", Arrays.copyOfRange(game, i, game.length)));
        //Habrá que añadir un valor en el save para saber la clase (Kenken o kenken inverso).
        kenken = isInverseValue ? new InverseKenken(board) : new Kenken(board);
    }

    /**
     * Convierte la partida en una array de strings que se puede guardar y cargar.
     *
     * @return la partida serializada.
     */
    public String[] codify() {
        ArrayList<String> res = new ArrayList<>();
        res.add(name);
        res.add(kenken.getClass().getName());
        res.add(user.getName());
        res.add(Integer.toString(score));
        res.add(Integer.toString(cluesUsed));
        res.add(Float.toString(time));
        res.add(Boolean.toString(rankingValid));
        res.addAll(Arrays.asList(kenken.getBoard().codify()));

        String[] retArr = new String[res.size()];
        res.toArray(retArr);
        return retArr;
    }

    public Game(User user, String name, GameMode gm, boolean rankingValid){
        this.name = name;
        this.user = user;
        this.cluesUsed = 0;
        this.time = 0.f;
        this.rankingValid = rankingValid;
        this.kenken = gm;
        this.score = 10*(this.kenken.getBoard().getSize())*(this.kenken.getBoard().getSize()); //Todas las casillas valen 10;
    }

    /**
     * Funcion que sirve para actualizar puntuacion
     * @param puntuacio nueva puntuacion de la partida
     */
    public void setScore(int puntuacio) {this.score = puntuacio;}

    public boolean isRankingValid() { return rankingValid; }

    /**
     *Funcion que sirve para devolver el nombre de la partida
     */
    public String getName(){
        return this.name;
    }
    /**
     *Funcion que sirve para devolver la puntuacion de la partida
     */

    public int getScore(){
        if (this.score < 0) {
            this.score = 0;
            return 0;
        }
        else return this.score;
    }

    /**
     *Funcion que sirve para devolver las pistas usadas de la partida
     */
    public int getCluesUsed(){
        return this.cluesUsed;
    }

    /**
     *Funcion que sirve para devolver el tiempo de la partida
     */
    public Float getTime(){
        return this.time;
    }

    public boolean getRankingValid(){return this.rankingValid;}

    public GameMode getGameMode(){return this.kenken; }

    /**
     * Funcion que sirve para terminar un juego rindiendose
     *
     * @return
     */
    public boolean giveUp() {
        this.score = 0;

        if (rankingValid) {
            this.kenken.setInteractive(false);
            this.user.modGameStarted();
        }

        return kenken.solve();
    }

    public boolean check() {
        boolean ret = kenken.check();
        if (ret && rankingValid) {
            this.user.modScore(this.score);
            this.user.modGameWon();
            this.user.modGameStarted();
            this.user.modTime(this.time);
        }
        return ret;
    }

    public boolean clue() {
        boolean ret = this.kenken.clue();
        ++this.cluesUsed;
        this.score -= 10;
        return ret;
    }

    /**
     *Funcion que sirve para parar una partida
     */
    public void pauseGame() {
    }

    /**
     *Funcion que sirve para continuar una partida
     */
    public void continueGame() {
    }

}
