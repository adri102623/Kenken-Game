package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

/**
 * Clase de ranking, en esta nos muestra diferentes opciones de ranking y aparecen todos los jugadores
 */
public class RankingView extends JPanel {
    private CtrlPresentacio CP;
    private JButton volver;
    private String rankingtype;
    private JMenuBar rankingbar;
    private JMenuItem rank_points;
    private JMenuItem rank_wins;
    private JMenuItem rank_ratio;
    private JMenuItem rank_kk_creates;
    private JPanel panel;
    private JTable rankingTable;
    private JScrollPane tableScrollPane;

    /**
     * @param user usuario actual
     * @param cp control presentacion
     * @param s tipo de ranking que queremos ver
     * Creadora de la clase ranking view
     */
    public RankingView(String user, CtrlPresentacio cp, String s) {
        this.CP = cp;
        this.rankingtype = s;
        this.presentacion();
    }

    /**
     * Se encarga de inicializar los objetos para la vista y posicionarlos correctamente, tambien aplica logica de que hacer cuando se clican
     * diferentes objetos
     */
    private void presentacion(){
        this.volver = new JButton("Return");
        this.rankingbar = new JMenuBar();
        this.rank_points = new JMenuItem("Points");
        this.rank_wins = new JMenuItem("Wins");
        this.rank_ratio = new JMenuItem("Ratio (%)");
        this.rank_kk_creates = new JMenuItem("Created Kenkens");
        this.panel = new JPanel();

        rankingbar.add(rank_points);
        rankingbar.add(rank_wins);
        rankingbar.add(rank_ratio);
        rankingbar.add(rank_kk_creates);

        this.panel.setLayout(new BorderLayout());

        JPanel titlePanel = new JPanel(new GridLayout());
        titlePanel.add(new JLabel("Position"));
        titlePanel.add(new JLabel("User"));
        titlePanel.add(new JLabel("Points"));
        panel.add(titlePanel, BorderLayout.NORTH);

        // Crear la tabla para mostrar el ranking
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("User");
        model.addColumn(rankingtype);

        rankingTable = new JTable(model){
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        rankingTable.setRowSelectionAllowed(false);
        rankingTable.setColumnSelectionAllowed(false);
        rankingTable.setCellSelectionEnabled(false);
        rankingTable.setDragEnabled(false);
        tableScrollPane = new JScrollPane(rankingTable);
        panel.add(tableScrollPane, BorderLayout.CENTER);


        this.setBackground(new Color(245, 239, 211));

        customtable(rankingTable);

        FlowLayout flowLayout = new FlowLayout();
        flowLayout.setAlignment(FlowLayout.LEFT);
        JPanel buttonPanel = new JPanel(flowLayout);
        buttonPanel.add(volver);

        buttonPanel.setBackground(new Color(245, 239, 211));

        this.panel.add(buttonPanel, BorderLayout.SOUTH);
        this.panel.add(rankingbar, BorderLayout.NORTH);

        if (!Objects.equals(rankingtype, "Select a type of ranking")) updateRanking(rankingtype);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                RankingView.this.returnbuttonclicked(actionEvent);
            }
        });


        this.add(panel);


        this.rank_wins.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                RankingView.this.updateRanking("Wins");
            }
        });

        this.rank_kk_creates.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                RankingView.this.updateRanking("Created Kenkens");
            }
        });

        this.rank_points.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                RankingView.this.updateRanking("Points");
            }
        });

        this.rank_ratio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                RankingView.this.updateRanking("Ratio");
            }
        });
    }

    private void customtable(JTable rankingTable) {
        JTableHeader header = rankingTable.getTableHeader();
        header.setFont(new Font("Montserrat", Font.PLAIN, 20));
        rankingTable.setDefaultRenderer(Object.class, new FirstRow());
    }


    private void updateRanking(String s) {
        Object[][] rankingData = CP.createrankingtable(s);
        String[] columnNames = {"Position","User", s};
        DefaultTableModel model = new DefaultTableModel(rankingData, columnNames);
        for (int i = 0; i < rankingData.length; ++i){
            model.setValueAt(i+1,i,0);
        }
        rankingTable.setModel(model);
       // rankingTable.setGridColor(Color.BLACK);
        rankingTable.setRowHeight(20);
        rankingTable.setRowHeight(0,40);
    }

    /**
     * @param actionEvent evento, boton clicado
     *  Funcion que sirve para retroceder a PantallaPrincipal
     */
    private void returnbuttonclicked(ActionEvent actionEvent) {
        MainWindow.setCurrentPanel(new MainMenu(CP));
    }

}
