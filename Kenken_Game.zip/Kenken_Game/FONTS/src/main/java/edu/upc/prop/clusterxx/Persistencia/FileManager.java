package edu.upc.prop.clusterxx.Persistencia;

import edu.upc.prop.clusterxx.Domini.Statistics;
import edu.upc.prop.clusterxx.Domini.User.User;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Clase que escribe y lee ficheros de la base de datos.
 */
class FileManager {

    private static final String basepath = "src/main/data";

    public static void crear_bd(){
        String baseDirectory = System.getProperty("user.home") + File.separator + "Base_de_Datos_kk";
        createDirectories(baseDirectory);
    }

    public static void createDirectories(String baseDirectory) {
        // Crear la carpeta base si no existe
        File baseDir = new File(baseDirectory);
        if (!baseDir.exists()) {
            baseDir.mkdirs();
        }

        String[] sizes = {"3x3", "4x4", "5x5", "6x6", "7x7", "8x8", "9x9"};
        for (String size : sizes) {
            File directory = new File(baseDirectory + File.separator + size);
            if (!directory.exists()) {
                directory.mkdirs();
            }
        }

        File userDirectory = new File(baseDirectory + File.separator + "Usuarios");
        if (!userDirectory.exists()) {
            userDirectory.mkdirs();
        }

        File userDataDirectory = new File(baseDirectory + File.separator + "Usuarios_kk");
        if (!userDataDirectory.exists()) {
            userDataDirectory.mkdirs();
        }
    }


    /**
     * Funcion que lee ficheros.
     * @param folder  Carpeta donde se ubica el fichero.
     * @param fileName Nombre del fichero que se lee.
     * @return devuelve el contenido del fichero.
     */
    public static String[] readFile(String folder, String fileName) {
        Path path = Paths.get(basepath + File.separator + folder + File.separator + fileName);

        try {
        if (Files.exists(path)) {
            List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
            return lines.toArray(new String[0]);
        } else {
            System.out.println("El archivo " + fileName + " no existe en " + folder);
            return new String[0];
        }
    } catch (IOException e) {
        e.printStackTrace();
        return new String[0];
    }
    }

    /**
     * Funcion que escribe un archivo de la base de datos.
     * Sobreescribe archivos.
     * @param lines Contenido que se escribe.
     * @param fileName Nombre del archivo que se escribe.
     * @param folder Carpeta que contiene el archivo que se escribe.
     */
    public static boolean writeFile(String[] lines, String fileName, String folder) {
        Path path = Paths.get(basepath + File.separator + folder + File.separator + fileName);
        /*if (Files.exists(path) && !Objects.equals(fileName, "users")) {
            System.err.println("Error: El archivo ya existe!");
            return false;
        }*/
        try (BufferedWriter writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            // Escribe las líneas en el archivo
            for (String line : lines) {
                writer.write(line);
                writer.newLine(); // Agrega una nueva línea después de cada línea escrita
            }
        } catch (IOException e) {
            System.err.println("Error writing to the file: " + e.getMessage());
            return false;
        }
        return true;
    }

    public static boolean deleteFile(String fileName, String folder) {
        File file = new File(basepath + File.separator + folder + File.separator + fileName);
        return file.delete();
    }
}

