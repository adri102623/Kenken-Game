package edu.upc.prop.clusterxx.Domini.Operation;

import edu.upc.prop.clusterxx.Domini.Board.Tile;
import edu.upc.prop.clusterxx.Domini.Board.Region;

import java.util.Vector;

import static java.lang.Math.sqrt;

/**
 * Subclase de Operacio, la cual es la raiz cuadrada de un numero. Siempre sera una única casilla
 */
public class OperationSquareRoot extends Operation {

    //Metodos

    /**
     *Asigna el nombre de Raiz
     */
    public OperationSquareRoot() {
        //Le asigna el nombre "Raiz"
        super("Raiz");
    }

    /**
     * Devuelve el codigo correspondiente a la operacion
     *
     * @return  6
     */
    @Override
    public int getCode() {
        return 6;
    }


    /**
     *
     *Aplica el calculo de raiz cuadrada a la region, recibe una region como parametro que es donde se aplica la operacion
     * @param reg Reg es una region
     * @return sqrt(a)
     */
    @Override
    public int applyOperation(Region reg){
        int res = 0;
        Vector<Tile> vcas = reg.getTiles();
        if (vcas.size() != 1) throw new IllegalArgumentException("La region deben ser solo una casillas");
        else {
            if(vcas.get(0).hasValue())  return (int) sqrt(vcas.get(0).getValue());
        }
        return res;
    }

    @Override
    public char getChar() {
        return 'a';
        //return '√';
    }

    @Override
    public int getTileRequired() {return 1;}

}
