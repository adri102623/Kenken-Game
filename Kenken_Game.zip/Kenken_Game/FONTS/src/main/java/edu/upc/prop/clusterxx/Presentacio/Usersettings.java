package edu.upc.prop.clusterxx.Presentacio;

import edu.upc.prop.clusterxx.Domini.User.User;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JComponent.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Usersettings extends JPanel {
    private CtrlPresentacio CP;
    private JButton volver;
    private JLabel userlabel;
    private JLabel useractual;
    private JLabel usernewlabel;
    private  JLabel passwordlabel;
    private JTextField usernewfield;
    private JPasswordField passwordFieldnew;
    private JPasswordField passwordFieldnew2;
    private JButton save;
    private JButton eliminarperfil;
    private JPanel panel;

    public  Usersettings(CtrlPresentacio CP){
        //super("User Settings");
        this.CP = CP;
        presentacion();
        /*this.pack();
        this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);*/
        this.setMinimumSize(new Dimension(1000,700));
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = this.getSize();
        this.setLocation(new Point((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2));
    }

    private void presentacion(){
        this.volver = new JButton("Return");
        this.userlabel = new JLabel("Actual Username:");
        this.useractual = new JLabel(CP.getUser());
        this.usernewlabel = new JLabel("New username:");
        this.usernewfield = new JTextField();
        this.passwordFieldnew = new JPasswordField();
        this.passwordFieldnew2 = new JPasswordField();
        this.passwordlabel = new JLabel("New password:");
        this.save = new JButton("Save");
        this.panel = new JPanel(new BorderLayout());
        this.eliminarperfil = new JButton("Delete Account");


        ImageIcon imageIcon = new ImageIcon(this.getClass().getClassLoader().getResource("Images/icons8-ajustes.gif"));
        JLabel imagen = new JLabel(imageIcon);
        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                Usersettings.this.savebuttonclicked(actionEvent);
            }
        });


        usernewfield.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        passwordFieldnew.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        passwordFieldnew2.setBorder(BorderFactory.createLineBorder(Color.BLACK));


        passwordFieldnew2.setPreferredSize(new Dimension(200,50));

        JPanel settingspanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);

        gbc.gridx = 0;
        gbc.gridy = 0;
        settingspanel.add(userlabel,gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        settingspanel.add(useractual,gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        settingspanel.add(usernewlabel,gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        usernewfield.setPreferredSize(new Dimension(200,20));
        settingspanel.add(usernewfield,gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        settingspanel.add(passwordlabel,gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        passwordFieldnew.setPreferredSize(new Dimension(200,20));
        settingspanel.add(passwordFieldnew,gbc);
        JLabel repeatpassword = new JLabel("Repeat password:");
        gbc.gridx = 0;
        gbc.gridy = 3;
       settingspanel.add(repeatpassword,gbc);
        gbc.gridx = 1;
        gbc.gridy = 3;
        passwordFieldnew2.setPreferredSize(new Dimension(200,20));
        settingspanel.add(passwordFieldnew2,gbc);


        panel.add(settingspanel, BorderLayout.CENTER);
        panel.add(imagen, BorderLayout.NORTH);

        JPanel botonespanel = new JPanel(new FlowLayout());
        botonespanel.add(save, BorderLayout.EAST);
        botonespanel.add(eliminarperfil, BorderLayout.CENTER);
        botonespanel.add(volver, BorderLayout.WEST);

        panel.add(botonespanel, BorderLayout.SOUTH);
        settingspanel.setBackground(new Color(245, 239, 211));
        this.setBackground(new Color(245, 239, 211));
        botonespanel.setBackground(new Color(245, 239, 211));
        panel.setBackground(new Color(245, 239, 211));

        this.userlabel.setFont(new Font("Montserrat", Font.PLAIN + Font.BOLD + Font.ITALIC, 20));
        this.useractual.setFont(new Font("Montserrat", Font.PLAIN + Font.BOLD + Font.ITALIC, 20));
        this.passwordlabel.setFont(new Font("Montserrat", Font.PLAIN, 20));
        this.usernewlabel.setFont(new Font("Montserrat", Font.PLAIN, 20));
        repeatpassword.setFont(new Font("Montserrat", Font.PLAIN, 20));

        this.add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                Usersettings.this.volverbuttonclicked(actionEvent);
            }
        });
        eliminarperfil.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                int option = JOptionPane.showOptionDialog(Usersettings.this, "Are you sure you want to delete the account?", "Delete Account", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null,new String[]{"Yes", "Cancel"}, "Accept");
                if (option == JOptionPane.YES_OPTION) {
                    Usersettings.this.eliminar();
                }
            }
        });
    }

    private void eliminar() {
        CP.deleteuser();
        /*PantallaIni pi = new PantallaIni(CP);
        pi.setVisible(true);
        this.dispose();*/

    }

    private void savebuttonclicked(ActionEvent actionEvent) {
        String nom = String.valueOf(usernewfield.getText());
        String contra = String.valueOf(passwordFieldnew.getPassword());
        String contra2 = String.valueOf(passwordFieldnew2.getPassword());
        if (nom.isEmpty() && contra.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nothing to do");
        } else if (!contra2.equals(contra)) {
            JOptionPane.showMessageDialog(this, "Passwords have to be the same");
        } else {
            if (!nom.isEmpty() && !contra.isEmpty()) {
                if (CP.newusername(CP.getUser(),nom)) {
                    CP.newpassword(CP.getUser(), contra);
                    JOptionPane.showMessageDialog(this, "Username and password have been changed successfully");
                    useractual.setText(nom);
                }
               else JOptionPane.showMessageDialog(this, "Username already exists");
            } else if (!nom.isEmpty() && contra.isEmpty()) {
                if (CP.newusername(CP.getUser(), nom)) {
                    JOptionPane.showMessageDialog(this, "Username has been changed successfully");
                    useractual.setText(nom);
                }
                else JOptionPane.showMessageDialog(this, "Username already exists");
            } else if (nom.isEmpty() && !contra.isEmpty()) {
                JOptionPane.showMessageDialog(this, "New password has been changed");
                CP.newpassword(CP.getUser(), contra);
            }
        }
        usernewfield.setText("");
        passwordFieldnew.setText("");
        passwordFieldnew2.setText("");
    }

    private void volverbuttonclicked(ActionEvent actionEvent) {
        MainWindow.setCurrentPanel(new MainMenu(CP));
    }
}
