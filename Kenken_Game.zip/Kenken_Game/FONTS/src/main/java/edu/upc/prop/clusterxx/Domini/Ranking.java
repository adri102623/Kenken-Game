package edu.upc.prop.clusterxx.Domini;

import edu.upc.prop.clusterxx.Domini.User.User;

import java.util.*;


/**
 * La Clase Ranking contiene 4 ArrayList que representan rankings distintos
 * El orden de los rankings depende de las Estadisticas de los usuarios
 */
public class Ranking {

    private static Map<Integer, List<User>> Rwon;
    private static Map<Integer, List<User>> RKKCreated;
    private static Map<Integer, List<User>> RScore;
    private static Map<Integer, List<User>> RRatio;


    /**
     * @return Devuelve un Mapa ordenado en función de las partidas ganadas
     */
    public static Map<Integer, List<User>> getRWon(ArrayList<User> users) {
        Rwon = new TreeMap<>(Collections.reverseOrder());
        for (User u : users) {
            int gamesWon = u.getStats().getGamesWon();
            if (!Rwon.containsKey(gamesWon)) {
                Rwon.put(gamesWon, new ArrayList<>());
            }
            Rwon.get(gamesWon).add(u);
        }
        return Rwon;
    }


    /**
     * @return Devuelve un Mapa ordenado en función de los Kenken creados
     */
    public static Map<Integer, List<User>> getRKKCreated(ArrayList<User> users) {
        RKKCreated = new TreeMap<>(Collections.reverseOrder());
        for (User u : users) {
            int kksCreated = u.getStats().getKKCreated();
            if (!RKKCreated.containsKey(kksCreated)) {
                RKKCreated.put(kksCreated, new ArrayList<>());
            }
            RKKCreated.get(kksCreated).add(u);
        }
        return RKKCreated;
    }

    /**
     * @return Devuelve un Mapa ordenado en función de la puntuación total
     */
    public static Map<Integer, List<User>> getRScore(ArrayList<User> users) {
        RScore = new TreeMap<>(Collections.reverseOrder());
        for (User u : users) {
            int score = u.getStats().getScore();
            if (!RScore.containsKey(score)) {
                RScore.put(score, new ArrayList<>());
            }
            RScore.get(score).add(u);
        }
        return RScore;
    }

    /**
     * @return Devuelve un Mapa ordenado en función del ratio de victoria
     */
    public static Map<Integer, List<User>> getRRatio(ArrayList<User> users) {
        RRatio = new TreeMap<>(Collections.reverseOrder());
        for (User u : users) {
            int victoryRatio = u.getStats().getVictoryRatio();
            if (!RRatio.containsKey(victoryRatio)) {
                RRatio.put(victoryRatio, new ArrayList<>());
            }
            RRatio.get(victoryRatio).add(u);
        }
        return RRatio;
    }

}
