package edu.upc.prop.clusterxx.Presentacio;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.net.URL;

import edu.upc.prop.clusterxx.Domini.CtrlDomini.BoardErrorCodes;

/**
 * Esta clase es un JPanel que permite al usuario diseñar un tablero especificando las regiones, sus propiedades y los valores de las casillas.
 * Tiene tres modos:
 *  Seleccionar: Permite clicar en una casilla para modificar su valor y que el inspector muestre las propiedades de la región correspondiente.
 *  Pintar: Cuando se clica y arrastra una casilla, extiende su región a las casillas que recorre el mouse.
 *  Borrar: Elimina la región de las casillas por las que se clica y arrastra el mouse.
 */
public class DesignerPresentacio extends JPanel implements ActionListener, KeyListener, MouseListener {

    private enum DesignerMode {
        SELECT,
        PAINT,
        ERASE
    }
    private CtrlPresentacio ctrlPresentacio;
    private BoardPresentation boardPresentation;
    private RegionInspector inspector;
    private DesignerMode mode = DesignerMode.SELECT;
    private TilePresentacio startPaint;
    private TilePresentacio selected;
    private boolean mousePressed = false;

    public DesignerPresentacio(CtrlPresentacio ctrlPresentacio) {
        TilePresentacio.setTileSize(ctrlPresentacio.getBoardSize() >= 7 ? 50 : 75);
        setLayout(new GridBagLayout());
        this.ctrlPresentacio = ctrlPresentacio;
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10,10,10,10);
        c.gridy = 0;

        c.gridx = 0;
        NumberSelector selector = new NumberSelector(ctrlPresentacio.getBoardSize(), this);
        add(selector, c);

        c.gridx = 1;
        add(createSelector(), c);

        c.gridx = 2;
        boardPresentation = new BoardPresentation(ctrlPresentacio, this, this);
        c.insets = new Insets(30, 10, 30, 10);
        add(boardPresentation, c);

        c.gridx = 3;
        c.insets = new Insets(10, 10, 10, 10);
        inspector = new RegionInspector(ctrlPresentacio, boardPresentation);
        add(inspector, c);

        c.gridy = 1;
        JButton saveButton = new JButton("Save board");
        saveButton.addActionListener(e -> saveBoardPressed());
        add(saveButton, c);

        c.gridy = 2;
        JButton returnButton = new JButton("Exit");
        returnButton.addActionListener(e -> MainWindow.setCurrentPanel(new MainMenu(ctrlPresentacio)));
        add(returnButton, c);

        setMinimumSize(getMinimumSize());
    }

    public void saveBoardPressed() {
        String s = (String)JOptionPane.showInputDialog(
                this,
                "Please input a name for the board:\n(It will overwrite files with the same name)\n",
                "Select name",
                JOptionPane.PLAIN_MESSAGE);

        if (s != null && !s.isEmpty()) {
            BoardErrorCodes ret = ctrlPresentacio.saveBoard(s);
            switch (ret) {
                case VALID:
                    JOptionPane.showMessageDialog(this, "Board successfully saved!");
                    MainWindow.setCurrentPanel(new MainMenu(ctrlPresentacio));
                    break;
                case NO_OPERATION_ASSIGNED:
                    JOptionPane.showMessageDialog(this, "There is a region without an operation assigned.", "Error saving", JOptionPane.ERROR_MESSAGE);
                    break;
                case OPERATION_TILE_NUMBER:
                    JOptionPane.showMessageDialog(this, "There is a region with an invalid number of tiles (-, /, ^ require 2; sqrt requires 1; * max 6 tiles ).", "Error saving", JOptionPane.ERROR_MESSAGE);
                    break;
                case NO_REGION_OR_VALUE_TILE:
                    JOptionPane.showMessageDialog(this, "There is a tile without a region or value assigned to it.", "Error saving", JOptionPane.ERROR_MESSAGE);
                    break;
                case NO_SOLUTION:
                    JOptionPane.showMessageDialog(this, "Current board has no solution.", "Error saving", JOptionPane.ERROR_MESSAGE);
                    break;
                case RWEXEPTION:
                    JOptionPane.showMessageDialog(this, "Error saving to file.", "Error saving", JOptionPane.ERROR_MESSAGE);
                    break;
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please input a valid name.", "Error saving", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void setMode(DesignerMode mode) {
        this.mode = mode;
        boardPresentation.clearSelection();
        inspector.clearRegion();
    }

    private JPanel createSelector() {
        JPanel selector = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10,10,10,10);
        c.gridx = 0;

        c.gridy = 0;
        JButton button = new JButton();
        ImageIcon icon = new ImageIcon(this.getClass().getClassLoader().getResource("Images/arrow-cursor-black.png"));
        Image newimg = icon.getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        button.setIcon(new ImageIcon(newimg));
        button.addActionListener(e -> setMode(DesignerMode.SELECT));
        button.setPreferredSize(new Dimension(50, 50));
        button.setMinimumSize(new Dimension(50, 50));
        selector.add(button, c);

        c.gridy = 1;
        button = new JButton();
        icon = new ImageIcon(this.getClass().getClassLoader().getResource("Images/paint-brush-black.png"));
        newimg = icon.getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        button.setIcon(new ImageIcon(newimg));
        button.addActionListener(e -> setMode(DesignerMode.PAINT));
        button.setPreferredSize(new Dimension(50, 50));
        button.setMinimumSize(new Dimension(50, 50));
        selector.add(button, c);

        c.gridy = 2;
        button = new JButton();
        icon = new ImageIcon(this.getClass().getClassLoader().getResource("Images/square-black.png"));
        newimg = icon.getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        button.setIcon(new ImageIcon(newimg));
        button.addActionListener(e -> setMode(DesignerMode.ERASE));
        button.setPreferredSize(new Dimension(50, 50));
        button.setMinimumSize(new Dimension(50, 50));
        selector.add(button, c);

        return selector;
    }

    void paintTile(TilePresentacio tile) {
        if (startPaint == null) {
            startPaint = tile;
            if (tile.getId() == 0) {
                int id = ctrlPresentacio.paintTile(tile.i, tile.j);
                tile.updateColor();
                boardPresentation.writeRegionText(id);
                boardPresentation.updateTileBorders(tile.i, tile.j);
            }
            inspector.setRegion(startPaint.getId());
        } else {
            int start_id = ctrlPresentacio.getTileId(startPaint.i, startPaint.j);
            if (ctrlPresentacio.paintTile(tile.i, tile.j, start_id)) {
                boardPresentation.refresh();
            }
        }
    }
    void eraseTile(TilePresentacio tile) {
        ctrlPresentacio.clearTileRegion(tile.i, tile.j);
        boardPresentation.refresh();
    }
    private void setValue(int value) {
        int[] pos = boardPresentation.getSelectedIndex();
        if (pos == null) return;
        ctrlPresentacio.setValue(pos[0], pos[1], value);
        boardPresentation.updateSelectedValue();
    }

    public void mouseClicked(MouseEvent mouseEvent) {

    }
    public void mousePressed(MouseEvent mouseEvent) {
        mousePressed = true;
        TilePresentacio tile = (TilePresentacio) mouseEvent.getComponent();

        if (mode == DesignerMode.PAINT) {
            paintTile(tile);
        } else if (mode == DesignerMode.ERASE) {
            eraseTile(tile);
        }
    }
    public void mouseReleased(MouseEvent mouseEvent) {
        if (mode == DesignerMode.SELECT) {
            int[] index = boardPresentation.getSelectedIndex();
            if (index == null) inspector.clearRegion();
            else {
                inspector.setRegion(ctrlPresentacio.getTileId(index[0], index[1]));
            }
        }
        startPaint = null;
        mousePressed = false;
    }
    public void mouseEntered(MouseEvent mouseEvent) {
        TilePresentacio tile = (TilePresentacio) mouseEvent.getComponent();

        if (mode == DesignerMode.PAINT && mousePressed) {
            paintTile(tile);
        } else if (mode == DesignerMode.ERASE && mousePressed) {
            eraseTile(tile);
        }
    }
    public void mouseExited(MouseEvent mouseEvent) {
    }

    public void actionPerformed(ActionEvent e) {
        setValue(Integer.parseInt(e.getActionCommand()));
    }
    public void keyTyped(KeyEvent e) {
    }
    public void keyPressed(KeyEvent e) {
        char c = e.getKeyChar();
        if (c >= '0' && c <= '9') {
            setValue(Integer.parseInt("" + (c - '0')));
        }
    }
    public void keyReleased(KeyEvent e) {
    }
}
