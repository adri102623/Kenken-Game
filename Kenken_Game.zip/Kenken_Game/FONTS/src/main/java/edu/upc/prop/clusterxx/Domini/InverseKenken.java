package edu.upc.prop.clusterxx.Domini;

import edu.upc.prop.clusterxx.Domini.Board.Board;
import edu.upc.prop.clusterxx.Domini.Board.Pos;
import edu.upc.prop.clusterxx.Domini.Board.Region;
import edu.upc.prop.clusterxx.Domini.Board.Tile;

import java.util.Random;
import java.util.Vector;
import java.util.Collections;
import java.util.*;

public class InverseKenken extends GameMode{
    /**
     * Constructor.
     *
     * @param board Tablero que se asignará al juego.
     */
    public InverseKenken(Board board) {
        super("InverseKenKen", board);
    }

    /**
     * Prepara el tablero para ser jugado como kenken inverso.
     */
    public void initialize() {
        //Utiliza el método de solucionado de KenKen para asignar los valores a las casillas.
        Kenken.solve(board);

        for (Region region : board.getRegions()) {
            region.setInitialPos(null);
        }
    }

    public boolean clue() {
        Board clone = board.cloneBoard();
        if (!solve(clone)) return false;

        Vector<Region> cloneRegions = clone.getRegions();
        Collections.shuffle(cloneRegions);
        for (Region cloneRegion : cloneRegions) {
            Region region = board.getRegionById(cloneRegion.getId());
            if (region.getInitialPos() == null) {
                region.setInitialPos(cloneRegion.getInitialPos());
                return true;
            }
        }

        return false;
    }

    public boolean verify() {
        return solve(board.cloneBoard());
    }

    public boolean solve() {
        return solve(board);
    }

    public boolean check() {
        for (Region region : board.getRegions()){
            if (region.getInitialPos() == null) return false;
            if (!region.operationChecks()) return false;
        }
        return true;
    }

    //Pre: todas las casillas de board tienen valor válido.
    public static boolean solve(Board board) {
        Vector<Region> regions = board.getRegions();
        return solve(board, regions, 0);
    }

    private static boolean solve(Board board, Vector<Region> regions, int index) {
        if (index == regions.size()) return true;

        Region region = regions.get(index);
        if (region.getInitialPos() != null) {
            if (!region.operationChecks()) return false;
            return solve(board, regions, index+1);
        }

        for (int i = 0; i < board.getSize(); i++) {
            for (int j = 0; j < board.getSize(); j++) {
                Pos pos = new Pos(i, j);
                if (region.canPlaceInitialPos(pos)
                && region.setInitialPos(pos)
                && region.operationChecks()) {
                    if (solve(board, regions, index + 1)) {
                        return true;
                    }
                }
                region.setInitialPos(null);
            }
        }

        return false;
    }
}
