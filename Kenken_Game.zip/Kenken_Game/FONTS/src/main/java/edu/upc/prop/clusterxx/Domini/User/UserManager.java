package edu.upc.prop.clusterxx.Domini.User;

import java.util.ArrayList;
import java.util.Objects;


/**
 * La clase GestionUsuario controla el conjunto de usuarios del programa mediante un ArrayList de usuarios.
 */
public class UserManager {
   private static ArrayList<User> users = new ArrayList<>();

    /**
     * Crear un GestionUsuario con el parametro como el conjunto de usuarios
     * @param users ArrayList de usuarios.
     */
    public static void setUsers(ArrayList<User> users) {
        UserManager.users = users;
    }

    public static User getUser(String nom) {
        for (User user : users) {
            if (Objects.equals(user.getName(), nom)) {
                return user;
            }
        }
        return null;
    }
    /**
     * Devuelve la posicion del ususario dentro de usuarios con nombre igual al parametro.
     * Devuelve -1 en caso de que no haya ningun usuario con nombre igual al parametro.
     * @param nom String que representa el nombre del usuario el cual estamos buscando
     * @return
     */
    public static int exist(String nom) {
        if (users == null) return -1;
        for (User user : users) {
            if (Objects.equals(user.getName(), nom)) {
                return users.indexOf(user);
            }
        }
        return -1;
    }

    /**
     * Comprueba que el usuario con nombre nom tenga la contresenya pwd.
     * @param nom nombre del usuario que estamos buscando
     * @param pwd contraseña que queremos comprobar
     * @return Si pwd corresponde con nom retorna true, si no corrresponde o no existe ningun usuario con nombre nom retorna false.
     */
    public static boolean pwdCorrect(String nom, String pwd) {
        boolean ret = false;
        for (User usuari : users) {
            if (Objects.equals(usuari.getName(), nom)){
                if(Objects.equals(usuari.getPassword(), pwd)) return true;
                else return false;
            }
        }
        return false;
    }

    /**
     * Añade un usuario a usarios.
     * @param nom Nombre del nuevo usuario. No puede existir ningun usuario en usarion con el mismo nombre
     * @param contra Contraseña del nuevo usuario.
     */
   public static boolean add(String nom, String contra) {
        if (exist(nom) >= 0) {
            System.out.println("Ja existeix un Usuari amb aquest nom");
            return false;
        }
        else {
            User user = new User(nom, contra);
            users.add(user);
            return true;
        }
   }

    public static ArrayList<User> getUsers(){ return users;}

    /**
     * Elimina al usuario con nombre nom de usuarios.
     * @param nom Nombre del usuario a eliminar. Debe existir un usuario con ese nombre.
     */
   public static boolean erase(String nom) {
        int index = exist(nom);
        if (index >= 0) {
            users.remove(index);
            return true;
        }
        else return false;
   }

    /**
     * Modifica el nombre del usuario con nombre nom.
     * @param nom Nombre del usuario a tratar. Debe existir un usuario con ese nombre.
     * @param nou Nuevo nombre que queremos asignar.
     */
   public static boolean modifyName(String nom, String nou) {
        int index = exist(nou);
        if (index >= 0) return false;
        else {
            int i = exist(nom);
            users.get(i).setName(nou);
            return true;
        }
   }

    /**
     * Modifica la contraseña del usuario con nombre nom.
     * @param nom Nombre del usuario a tratar. Debe existir un usuario con ese nombre.
     * @param contra Nueva contraseña que queremos asignar.
     */
    public static void modifyPwd(String nom, String contra) {
        int index = exist(nom);
        if (index >= 0) {
            users.get(index).setPassword(contra);
        } else System.out.println("No existeix un Usuari amb aquest nom");

    }

    public static String[] codifyList() {
        String [] aux = new String[users.size()];
        int i = 0;
        for (User u : users) {
            aux[i] = u.getName()+";"+u.getPassword()+";"+u.getStats().getKKCreated() +";"+u.getStats().getScore()+";"+u.getStats().getGamesStarted()+
                    ";"+u.getStats().getGamesWon() +";"+u.getStats().getTotalTime();


//            aux[i] = u.getName()+";"+u.getPassword()+";"+u.getStats().getKKCreated() +";"+u.getStats().getGamesStarted()+";"+u.getStats().getGamesWon()+
  //                  ";"+u.getStats().getScore() +";"+u.getStats().getVictoryRatio()+";"+u.getStats().getTotalTime();
            ++i;
        }
        return aux;
    }


}
