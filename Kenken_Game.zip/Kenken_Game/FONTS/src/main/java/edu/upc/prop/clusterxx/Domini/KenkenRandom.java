package edu.upc.prop.clusterxx.Domini;

import edu.upc.prop.clusterxx.Domini.Board.Tile;
import edu.upc.prop.clusterxx.Domini.Board.Board;
import edu.upc.prop.clusterxx.Domini.Board.Pos;
import edu.upc.prop.clusterxx.Domini.Board.Region;
import edu.upc.prop.clusterxx.Domini.Operation.Operation;
import java.util.*;

/**
 * La clase KenKenRandom permite generar KenKens aleatorios a partir de parámetros como el tamaño del tablero o número de regiones.
 */
public class KenkenRandom {
    private static Board K;
    private int n;
    private int dir[] = {0, 1, 0, -1, 0};


    /**
     * Creadora de KenkenRandom.
     * @param tam Tamaño del Kenken que se va a crear.
     */
    public KenkenRandom(int tam) {
        this.n = tam;
    }


    /**
     * Algoritmo que asgina aleatoriamente los valores de las casillas de un tablero.
     * @param row File desde la que empieza a asignar valores
     * @param col Columna desde la que empieza a asignar valores
     * @return True si se ha generado un tablero valido, False si no se ha podido
     */
    private boolean backtrackingGenerateNumbers(int row, int col) {
        if (row == n) {
            return true;
        } else {
            List<Integer> nums = new ArrayList<>();
            for (int num = 1; num <= n; num++) {
                nums.add(num);
            }
            Collections.shuffle(nums);

            for (int num : nums) {
                if (isValid(row, col, num)) {
                    Pos pos = new Pos(row, col);
                    if (K.getTile(pos).hasValue() == false || K.getTile(pos).getValue() == -1)
                        K.getTile(pos).setValue(num);

                    int nextRow = row;
                    int nextCol = col + 1;
                    if (nextCol == n) {
                        nextRow++;
                        nextCol = 0;
                    }

                    if (backtrackingGenerateNumbers(nextRow, nextCol)) {
                        return true;
                    }

                    K.getTile(pos).setValue(-1);
                }
            }

            return false;
        }
    }

    /**
     * Algoritmo que genera aleatoriamente las regiones de un tablero.
     */
    private void randomRegions() {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                Pos p = new Pos(i, j);
                int ii = i;
                int jj = j;
                if (K.getRegion(p) == null) { //Pos p no tiene una región asignada
                    Region r = K.newRegion();
                    r.addPosition(p);
                    double prob = 0.1;
                    while (new Random().nextDouble() > prob) {
                        int rDir = new Random().nextInt(4);
                        int auxi = ii + dir[rDir];
                        int auxj = jj + dir[rDir + 1];
                        Pos auxp = new Pos(auxi, auxj);
                        if (validPos(auxi, auxj) && K.getRegion(auxp) == null) {
                            r.addPosition(auxp);
                            ii = auxi;
                            jj = auxj;
                        }
                        prob += 0.1;
                    }

                }
            }
        }

    }

    /**
     * Algoritmo que genera aleatoriamente las regiones de un tablero.
     * @param numRegions Numero de regiones a crear.
     * @param done Posicion de las casillas que ya tienen un region asginada.
     */
    private void randomRegions_usu(int numRegions,ArrayList<Pos> done) {
        List<Pos> positions = new ArrayList<>();
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                positions.add(new Pos(i, j));
            }
        }
        positions.removeAll(done);

        Collections.shuffle(positions);
        List<Pos> aux = new ArrayList<>();
        List<Region> regions = new ArrayList<>();
        for (int i = 0; i < numRegions; ++i) {
            Pos p = positions.get(i);
            aux.add(p);
            Region r = K.newRegion();
            r.addPosition(p);
            regions.add(r);
        }
        positions.removeAll(aux);

        int[][] adyacentes = {
                {-1, 0}, {1, 0}, {0, -1}, {0, 1},
        };

        while (!positions.isEmpty()) {
            List<Pos> toRemove = new ArrayList<>();
            for (Region r : regions) {
                List<Pos> regionPositions = new ArrayList<>(r.getOffsets());
                for (Pos p : regionPositions) {
                    Pos ref = r.getInitialPos();
                    for (int[] adyacente : adyacentes) {
                        int nuevaI = ref.i + p.i + adyacente[0];
                        int nuevaJ = ref.j + p.j + adyacente[1];
                        Pos nuevaPos = new Pos(nuevaI, nuevaJ);
                        if (validPos(nuevaI, nuevaJ) && K.getRegion(nuevaPos) == null) {
                            r.addPosition(nuevaPos);
                            toRemove.add(nuevaPos);
                        }
                    }
                }
            }
            if (toRemove.isEmpty()){
                break; // Rompe el bucle si no se encontraron nuevas posiciones para agregar
            }
            positions.removeAll(toRemove);
        }
    }

    /**
     * Algoritmo que asigna aleatoriamente la operacion de cada region de un tablero.
     */
    private void assignOperation() {
        Vector<Region> regions = K.getRegions();
        Random random = new Random();
        for (Region r : regions) {
            int operationCode;
            if (r.getSize() == 1) {
                operationCode = 6;
            } else if (r.getSize() == 2) {
                operationCode = random.nextInt(5) + 1;
            } else {
                int randomCode = random.nextInt(2);
                operationCode = randomCode == 0 ? 1 : 3; // Si randomCode es 0, operationCode es 1; de lo contrario, es 3
            }
            Operation op = Operation.GetOperation(operationCode);
            r.setOperation(op);
        }
    }


    /**
     * Algoritmo que asigna aleatoriamente la operacion de cada region de un tablero.
     * @param operacion ArrayList de Integers con los codigos de las posibles operaciones a asignar.
     */
    private void assignOperation_usu(ArrayList<Integer> operacion) {
        Vector<Region> regions = K.getRegions();
        Random random = new Random();
        for (Region r : regions) {
            int operationCode;
            if (r.getSize() == 1) {
                if (operacion.contains(6)) operationCode = 6;
                else operationCode = 1;
            } else if (r.getSize() == 2) {
                if (operacion.contains(6)) {
                    operacion.remove(Integer.valueOf(6));
                }
                if (operacion.size() == 0)  {
                    operationCode = 1;
                    operacion.add(Integer.valueOf(6));
                }
                else {
                    int randomIndex = random.nextInt(operacion.size());
                    operationCode = operacion.get(randomIndex);
                    operacion.add(Integer.valueOf(6));
                }
            } else if (r.getSize() >2 && r.getSize() <=6) {
                if (operacion.contains(1) && operacion.contains(3)) {
                    int randomCode = random.nextInt(2);
                    operationCode = randomCode == 0 ? 1 : 3; // Si randomCode es 0, operationCode es 1; de lo contrario, es 3
                }
                else if (operacion.contains(1)) operationCode = 1;
                else if (operacion.contains(3)) operationCode = 3;
                else {
                    int randomCode = random.nextInt(2);
                    operationCode = randomCode == 0 ? 1 : 3;
                }
            }
            else operationCode = 1;
            Operation op = Operation.GetOperation(operationCode);
            r.setOperation(op);
        }
    }


    /**
     * Funcoion para verificar si la posicion (i,j) esta dentro del tablero.
     * @param i Fila del tablero.
     * @param j Columna del tablero.
     * @return True si se encuentra dentro del tablero, False si no.
     */
    private boolean validPos(int i, int j) {
        return (i >= 0 && i < K.getSize() && j >= 0 && j < K.getSize());
    }

    /**
     * Funcion que verifica si se puede asginar un valor a una casilla del tablero y que siga siendo valido.
     * @param row Fila de la casilla.
     * @param col Columna de la casilla.
     * @param num Valor a asginar.
     * @return True si se puede asginar el valor, False si no.
     */
    private boolean isValid(int row, int col, int num) {
        Tile tile = K.getTile(new Pos(row, col));
        return tile != null && K.checkRow(row, num) && K.checkCol(col, num);
    }


    /**
     * Funcion que crea un kenken aleatorio con unos parametros fijados por el usuario.
     * @param operacion ArrayList de Integers que representan los codigos de las operaciones que puede tener el Kenken.
     * @param regionsN Numero de regiones que va a tener el Kenken.
     * @return Retorna el Kenknen aleatorio con las limitaciones fijadas.
     */
    public Board kk_random(ArrayList<Integer> operacion, int regionsN) {
        K = new Board(n);
        boolean matriu = false;
        while (!matriu) {
            matriu = backtrackingGenerateNumbers(0, 0);
        }
        System.out.println();
        ArrayList<Pos> p = new ArrayList<>();
        randomRegions_usu(regionsN, p);
        assignOperation_usu(operacion);

        Vector<Region> regions = K.getRegions();
        for (Region r : regions) {
            Operation op = r.getOperacio();
            int res = op.applyOperation(r);
            r.setResult(res);
        }
        for (int i = 0; i < K.getSize(); i++) {
            for (int j = 0; j < K.getSize(); j++) {
                Pos cas = new Pos(i,j);
                K.getTile(cas).resetValue();
            }
        }

        return K;
    }


    /**
     * Funcion que crea regiones de una casilla en las posicions pasadas como parametro
     * @param posicions ArrayList de Pos, con las posiciones de las regiones a crear.
     */
    public void regions1c_usu(ArrayList<Pos> posicions) {
        for (Pos p : posicions) {
            Region r = K.newRegion();
            r.addPosition(p);
        }
    }

    /**
     * Funcion que crea un kenken aleatorio con unos parametros fijados por el usuario.
     * @param caselles ArrayList de Integers con el valor de las casillas asignadas por el usuario.
     * @param posicions  ArrayList de Pos con las posiciones de las casillas asginadas por el usuario.
     * @param operacion ArrayList de Integers que representan los codigos de las operaciones que puede tener el Kenken.
     * @param regions Numero de regiones que va a tener el Kenken.
     * @return  Retorna el Kenknen aleatorio con las limitaciones fijadas.
     */
    public Kenken kenken_usu(ArrayList<Integer> caselles, ArrayList<Pos> posicions, ArrayList<Integer> operacion, int regions) {
        K = new Board(n);
        for (int i = 0; i < caselles.size(); i++) {
            K.getTile(posicions.get(i)).setValue(caselles.get(i));
        }
        boolean matriu = false;
        while (!matriu) {
            matriu = backtrackingGenerateNumbers(0, 0);
        }
        regions1c_usu(posicions);
        regions = regions - posicions.size();
        randomRegions_usu(regions,posicions);
        assignOperation_usu(operacion);
        Vector<Region> reg = K.getRegions();
        for (Region r : reg) {
            Operation op = r.getOperacio();
            int res = op.applyOperation(r);
            r.setResult(res);
        }
        for (int i = 0; i < K.getSize(); i++) {
            for (int j = 0; j < K.getSize(); j++) {
                Pos cas = new Pos(i,j);
                K.getTile(cas).resetValue();
            }
        }
        Kenken kk = new Kenken(K);
        return kk;
    }

}

