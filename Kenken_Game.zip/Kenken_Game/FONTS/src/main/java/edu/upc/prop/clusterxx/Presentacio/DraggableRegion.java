package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

/**
 * Elemento arrastrable que representa una región.
 */
public class DraggableRegion extends JComponent {
    private int screenX = 0;
    private int screenY = 0;
    private int myX = 0;
    private int myY = 0;
    private int offsetX;
    private int offsetY;
    private final int id;

    public DraggableRegion(CtrlPresentacio ctrlPresentacio, InverseKenKenPresentacio inverseKenKenPresentacio, int id) {
        setLayout(null);
        this.id = id;

        int tileSize = TileInversePresentacio.getTileSize();
        int[][] offsets = ctrlPresentacio.getRegionOffsets(id);

        int[] bounds = ctrlPresentacio.getRegionBounds(id);
        offsetX = bounds[2]*tileSize;
        offsetY = bounds[0]*tileSize;
        int[] topLeft = ctrlPresentacio.getRegionTopLeftOffset(id);

        for (int[] offset : offsets) {
            JPanel tile = new JPanel();
            tile.setBackground(Palette.getColor(id));
            add(tile);
            tile.setPreferredSize(new Dimension(tileSize,tileSize));
            tile.setMinimumSize(new Dimension(tileSize, tileSize));
            tile.setBounds(tileSize*(offset[1]-bounds[2]), tileSize*(offset[0]-bounds[0]), tileSize, tileSize);

            if (offset[0] == topLeft[0] && offset[1] == topLeft[1]) {
                JLabel text = new JLabel(ctrlPresentacio.getRegionText(id));
                tile.add(text);
                text.setBounds(0, 0, tileSize, tileSize);
                text.setHorizontalAlignment(JLabel.CENTER);
                text.setVerticalAlignment(JLabel.TOP);
            }
        }

        setMinimumSize(new Dimension((bounds[3]-bounds[2] + 1)*tileSize, (bounds[1]-bounds[0] + 1)*tileSize));
        setPreferredSize(new Dimension((bounds[3]-bounds[2] + 1)*tileSize, (bounds[1]-bounds[0] + 1)*tileSize));
        setVisible(true);

        addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) { }
            @Override
            public void mousePressed(MouseEvent e) {
                screenX = e.getXOnScreen();
                screenY = e.getYOnScreen();

                myX = getX();
                myY = getY();

                inverseKenKenPresentacio.pickRegion(id, myX - bounds[2]*tileSize, myY - bounds[0]*tileSize);
            }
            @Override
            public void mouseReleased(MouseEvent e) {
                myX = getX();
                myY = getY();

                int[] ret = inverseKenKenPresentacio.dropRegion(id, myX - bounds[2]*tileSize, myY - bounds[0]*tileSize);

                //Si se ha colocado la región.
                if (ret[0] != -1) {
                    setLocation(ret[0] + bounds[2]*tileSize, ret[1] + bounds[0]*tileSize);
                }
            }
            @Override
            public void mouseEntered(MouseEvent e) { }
            @Override
            public void mouseExited(MouseEvent e) { }

        });
        addMouseMotionListener(new MouseMotionListener() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int deltaX = e.getXOnScreen() - screenX;
                int deltaY = e.getYOnScreen() - screenY;

                setLocation(myX + deltaX, myY + deltaY);
            }
            @Override
            public void mouseMoved(MouseEvent e) { }

        });
    }

    public int getID() {
        return id;
    }

    public void setLocationOfInitialPos(int[] initialPos) {
        setLocation(initialPos[0] + offsetX, initialPos[1] + offsetY);
    }
}