package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import java.awt.*;

/**
 * Contiene los botones Pista, Comprobar y Rendirse así como el juego al que están asociados.
 */
public class GamePresentation extends JPanel implements IRefreshable {
    CtrlPresentacio ctrlPresentacio;
    IRefreshable iRefreshable;
    JLabel messageLabel;
    JPanel gameModePanel;
    JPanel buttons;
    JLabel scoreText;

    public GamePresentation(CtrlPresentacio ctrlPresentacio, boolean isInverse) {
        if (isInverse) {
            InverseKenKenPresentacio inverseKenKenPresentacio = new InverseKenKenPresentacio(ctrlPresentacio);
            init(ctrlPresentacio, inverseKenKenPresentacio, inverseKenKenPresentacio);
        } else {
            KenKenPresentacio kenKenPresentacio = new KenKenPresentacio(ctrlPresentacio);
            init(ctrlPresentacio, kenKenPresentacio, kenKenPresentacio.getRefreshable());
        }
    }

    private void init(CtrlPresentacio ctrlPresentacio, JPanel gameModePanel, IRefreshable iRefreshable) {
        setLayout(new GridBagLayout());
        setVisible(true);
        this.ctrlPresentacio = ctrlPresentacio;
        this.iRefreshable = iRefreshable;
        this.gameModePanel = gameModePanel;
        GridBagConstraints c = new GridBagConstraints();

        c.gridx = 0;
        c.insets = new Insets(10, 10, 10, 20);
        add(gameModePanel, c);

        c.gridx = 1;
        buttons = new JPanel(new GridBagLayout());
        GridBagConstraints c2 = new GridBagConstraints();
        c2.gridx = 0;
        c2.insets = new Insets(10, 0, 10, 0);
        c2.fill = GridBagConstraints.BOTH;

        JButton clueButton = new JButton("Clue");
        clueButton.addActionListener(e -> cluePressed());
        buttons.add(clueButton, c2);

        c2.gridy = 1;
        JButton checkButton = new JButton("Check");
        checkButton.addActionListener(e -> checkPressed());
        buttons.add(checkButton, c2);

        c2.gridy = 2;
        //Deberá ser cambiado a give up
        JButton solveButton = new JButton("Give up");
        solveButton.addActionListener(e -> giveUpPressed());
        buttons.add(solveButton, c2);

        c2.gridy = 3;
        //Deberá ser cambiado a give up
        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(e -> savePressed());
        buttons.add(saveButton, c2);

        c2.gridy = 4;
        //Deberá ser cambiado a give up
        JButton returnButton = new JButton("Exit");
        returnButton.addActionListener(e -> MainWindow.setCurrentPanel(new MainMenu(ctrlPresentacio)));
        buttons.add(returnButton, c2);

        scoreText = new JLabel("Score: " + ctrlPresentacio.getGameScore());
        scoreText.setVisible(ctrlPresentacio.isRankingValid());
        c2.gridy = 5;
        buttons.add(scoreText, c2);

        add(buttons, c);

        c.gridy = 1;
        c.gridx = 0;
        c.anchor = GridBagConstraints.SOUTH;
        c.fill = GridBagConstraints.BOTH;
        //Debería verse más ancho.
        messageLabel = new JLabel("");
        add(messageLabel, c);

        setMinimumSize(getMinimumSize());
    }

    public void cluePressed() {
        if (ctrlPresentacio.clue()) {
            refresh();
            messageLabel.setText("");
        } else {
            messageLabel.setText("<html>"+ "Clue: Current board has no solution." + "<html>");
        }
    }

    public void giveUpPressed() {
        if (ctrlPresentacio.giveUp()) {
            refresh();
            messageLabel.setText("");
        } else {
            messageLabel.setText("<html>"+ "Give up: Current board had no solution." + "<html>");
        }
        endGame();
    }

    public void checkPressed() {
        if (ctrlPresentacio.check()) {
            endGame();
        } else {
            messageLabel.setText("<html>"+ "KenKen is not solved." + "<html>");
        }
    }

    public void savePressed() {
        ctrlPresentacio.saveGame();
        closeWindow();
    }

    void setPanelEnabled(JPanel panel, Boolean isEnabled) {
        panel.setEnabled(isEnabled);

        Component[] components = panel.getComponents();

        for (Component component : components) {
            if (component instanceof JPanel) {
                setPanelEnabled((JPanel) component, isEnabled);
            }
            component.setEnabled(isEnabled);
        }
    }

    private void closeWindow() {
        MainWindow.setCurrentPanel(new MainMenu(ctrlPresentacio));
    }

    private void endGame() {
        setPanelEnabled(gameModePanel, false);
        setPanelEnabled(buttons, false);
        JOptionPane.showMessageDialog(this, ctrlPresentacio.isRankingValid() ? "Score: " + ctrlPresentacio.getGameScore() : "Game finished", "Game finished", JOptionPane.PLAIN_MESSAGE);
        closeWindow();
    }

    public void refresh() {
        iRefreshable.refresh();
        scoreText.setText("Score: " + ctrlPresentacio.getGameScore());
    }

}
