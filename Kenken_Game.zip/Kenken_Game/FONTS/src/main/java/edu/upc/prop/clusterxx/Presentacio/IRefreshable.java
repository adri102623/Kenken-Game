package edu.upc.prop.clusterxx.Presentacio;

/**
 * Esta interfaz representa un tablero o juego que debe ser actualizado después de una llamada que pueda modificar el estado de los elementos que lo componen.
 * Por ejemplo, se usa después de que rendirse en mitad de un KenKen cambie el valor de las casillas en el tablero.
 */
public interface IRefreshable {
    /**
     * Actualiza el estado del juego para ser igual al de la capa de dominio.
     */
    public void refresh();
}
