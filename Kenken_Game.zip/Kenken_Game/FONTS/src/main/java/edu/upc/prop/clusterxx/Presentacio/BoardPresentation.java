package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Esta clase es un JPanel que contiene únicamente las casillas del tablero e implementa las operaciones para modificarlas.
 * En el constructor tiene como parámetros un KeyListener y un MouseListener que serán invocados cuando el usuario interaccione con el tablero.
 * Permite obtener y modificar una casilla concreta a partir de su posición o a partir de la posición que ha clicado el usuario.
 */
public class BoardPresentation extends JPanel implements IRefreshable {
    private TilePresentacio[][] tiles;
    private TilePresentacio selected = null;
    private CtrlPresentacio ctrl;

    public BoardPresentation(CtrlPresentacio ctrl, KeyListener keyListener, MouseListener mouseListener) {
        super(new GridBagLayout());
        this.ctrl = ctrl;
        int size = ctrl.getBoardSize();
        tiles = new TilePresentacio[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {

                //Constraints para añadir correctamente la casilla.
                GridBagConstraints c = new GridBagConstraints();
                c.gridx = j;
                c.gridy = i;
                c.gridwidth = 1;
                c.gridheight = 1;
                c.weightx = 0;
                c.weighty = 0;

                TilePresentacio tile = new TilePresentacio(i, j, ctrl, this);
                tile.setMouseListener(mouseListener);

                tiles[i][j] = tile;
                add(tile, c);
            }
        }
        refresh();
        setFocusable(true);
        addKeyListener(keyListener);
    }

    public void updateSelectedValue() {
        if(selected != null) selected.updateValue();
    }

    public int[] getSelectedIndex() {
        if (selected == null) return null;
        return new int[]{selected.i, selected.j};
    }

    public void tileSelected(TilePresentacio tile) {
        if (selected == tile) {
            tile.setSelected(false);
            selected = null;
        } else {
            if (selected != null) selected.setSelected(false);
            selected = tile;
            selected.setSelected(true);
        }
        requestFocusInWindow();
    }

    public void clearSelection() {
        if (selected != null) selected.setSelected(false);
        selected = null;
    }

    public TilePresentacio getTile(int i, int j) {
        return tiles[i][j];
    }

    public void updateTileBorders(int i, int j) {
        tiles[i][j].updateBorders();
        if (i > 0) tiles[i-1][j].updateBorders();
        if (j > 0) tiles[i][j-1].updateBorders();
        if (i < ctrl.getBoardSize()-1) tiles[i+1][j].updateBorders();
        if (j < ctrl.getBoardSize()-1) tiles[i][j+1].updateBorders();
    }

    public void writeRegionText(int id) {
        int[] pos = ctrl.getRegionTopLeftPos(id);
        if (pos == null) return;
        tiles[pos[0]][pos[1]].setText(ctrl.getRegionText(id));
    }

    public void eraseRegionText(int id) {
        int[] pos = ctrl.getRegionTopLeftPos(id);
        if (pos == null) return;
        tiles[pos[0]][pos[1]].setText("");
    }

    public void refresh() {
        for (TilePresentacio[] tileLine : tiles) {
            for (TilePresentacio tile : tileLine) {
                tile.updateValue();
                tile.updateColor();
                tile.updateBorders();
                tile.setText("");
                //Esta forma de escribir el texto de las regiones es ineficiente. En caso de consumir muchos recursos se podría mejorar.
                writeRegionText(tile.getId());
            }
        }


    }
}
