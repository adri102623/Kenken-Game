package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.ArrayList;
import java.util.Objects;

/**
 * Esta clase es la encargada de la vista de la parte de generar un kenken a través de una serie de parametros que nosotros le indiquemos,
 * los parametros son: tamaño del kenken, numero de regiones, las operaciones que queremos que aparezcan y finalmemnte se pide un nombre para kenken.
 */
public class GenerateKenken extends JPanel {
    private CtrlPresentacio CP;
    private JButton makeAndEditButton;
    private JButton makeAndPlayButton;
    private JCheckBox isInverseCheck;
    private JTextField regionsfield;
    private JButton buttonsuma;
    private JButton buttonresta;
    private JButton buttonmulti;
    private JButton buttondivi;
    private JButton buttonraiz;
    private JButton buttonelevar;
    private JButton volver;
    private JComboBox comboBox1;
    private JPanel CreatePanel;
    private JPanel select_operations;
    private JPanel select_type;
    private JLabel dificultlabel;
    private JLabel regionlabel;
    private JLabel operationlabel;
    private JPanel centerpanel;
    private Color originalColor;

    private ArrayList<Integer> selectedOperations;

    public GenerateKenken(CtrlPresentacio cp) {
        this.CP = cp;
        this.presentacion();
    }

    private void presentacion(){
        String[] options = {"--","3x3", "4x4", "5x5", "6x6", "7x7", "8x8", "9x9"};

        this.regionsfield = new JTextField();
        this.buttonsuma = new JButton("+");
        buttonsuma.setFont(new Font("Arial",Font.PLAIN, 20));
        this.buttonresta = new JButton("-");
        buttonresta.setFont(new Font("Arial",Font.PLAIN, 20));
        this.buttonmulti = new JButton("*");
        buttonmulti.setFont(new Font("Arial",Font.PLAIN, 20));
        this.buttondivi = new JButton("/");
        buttondivi.setFont(new Font("Arial",Font.PLAIN, 20));
        this.buttonraiz = new JButton("√");
        buttonraiz.setFont(new Font("Arial",Font.PLAIN, 20));
        this.buttonelevar = new JButton("^");
        buttonelevar.setFont(new Font("Arial",Font.PLAIN, 20));
        this.comboBox1 = new JComboBox<>(options);
        this.CreatePanel = new JPanel();
        this.select_operations = new JPanel();
        this.select_type = new JPanel();
        this.dificultlabel = new JLabel("Select difficulty");
        this.regionlabel = new JLabel("Number of regions  (Numbers only)");
        this.operationlabel = new JLabel("Select operations");
        this.centerpanel = new JPanel();
        this.originalColor = buttonsuma.getForeground();
        this.makeAndEditButton = new JButton("Make and Edit");
        this.isInverseCheck = new JCheckBox("Play as inverse kenken");
        selectedOperations = new ArrayList<>();
        this.makeAndPlayButton = new JButton("Make and Play");
        this.volver = new JButton("Return");

        dificultlabel.setBorder(new EmptyBorder(4,20,4,4));
        regionlabel.setBorder(new EmptyBorder(4,20,4,4));
        operationlabel.setBorder(new EmptyBorder(4,20,4,4));


        CreatePanel.setLayout(new BorderLayout());
        select_type.setLayout(new FlowLayout());
        select_operations.setLayout(new GridLayout());
        centerpanel.setLayout(new GridLayout(3,2));


        centerpanel.add(dificultlabel);
        centerpanel.add(comboBox1);
        centerpanel.add(regionlabel);
        centerpanel.add(regionsfield);
        centerpanel.add(operationlabel);
        centerpanel.add(select_operations);

        select_type.add(Box.createHorizontalGlue());
        select_type.add(Box.createHorizontalGlue());

        select_operations.add(buttonsuma);
        select_operations.add(buttonresta);
        select_operations.add(buttonmulti);
        select_operations.add(buttondivi);
        select_operations.add(buttonelevar);
        select_operations.add(buttonraiz);

        select_operations.setBackground(new Color(245, 239, 211));

        this.add(select_type,  BorderLayout.NORTH);
        this.add(CreatePanel);
        this.add(centerpanel, BorderLayout.CENTER);

        this.setBackground(new Color(245, 239, 211));
        centerpanel.setBackground(new Color(245, 239, 211));
        CreatePanel.setBackground(new Color(245, 239, 211));
        select_type.setBackground(new Color(245, 239, 211));

        JPanel volverpanel = new JPanel();
        FlowLayout layout = new FlowLayout(FlowLayout.LEFT);
        volverpanel.setLayout(layout);
        volverpanel.add(makeAndEditButton);
        volverpanel.add(makeAndPlayButton);
        volverpanel.add(isInverseCheck);
        volverpanel.add(volver);
        this.add(volverpanel, BorderLayout.SOUTH);


        volverpanel.setBackground(new Color(245, 239, 211));

        regionsfield.setText("Indicate the number of regions...");
        regionsfield.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent focusEvent) {
                pressed(focusEvent);
            }

            @Override
            public void focusLost(FocusEvent focusEvent) {

            }
        });

        buttonsuma.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                clicked(buttonsuma);
            }
        });

        buttonresta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                clicked(buttonresta);
            }
        });
        buttonmulti.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                clicked(buttonmulti);
            }
        });
        buttondivi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                clicked(buttondivi);
            }
        });
        buttonelevar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                clicked(buttonelevar);
            }
        });
        buttonraiz.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                clicked(buttonraiz);
            }
        });

        makeAndEditButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                makeAndEditPressed(actionEvent);
            }
        });

        makeAndPlayButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                makeAndPlayPressed(actionEvent);
            }
        });
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                GenerateKenken.this.returnbuttonclicked(actionEvent);
            }
        });
    }

    private void makeAndEditPressed(ActionEvent actionEvent) {
        if (generateBoard()) {
            MainWindow.setCurrentPanel(new DesignerPresentacio(CP));
        }
    }


    private void makeAndPlayPressed(ActionEvent actionEvent) {
        if (generateBoard()) {
            MainWindow.setCurrentPanel(new GamePresentation(CP, isInverseCheck.isSelected()));
        }
    }

    private boolean generateBoard() {
        String item = String.valueOf(comboBox1.getSelectedItem());
        int tamano = tam_tab(item);
        if (tamano == 0) {
            JOptionPane.showMessageDialog(this, "Incorrect size");
            return false;
        }
        String s =  regionsfield.getText();
        if (!comprobarregions(s) || s.isEmpty()){
            JOptionPane.showMessageDialog(this, "Format error in regions");
            return false;
        }
        int regions = Integer.parseInt(s);
        if (regions <= 0 || regions > tamano*tamano){
            JOptionPane.showMessageDialog(this, "Number incorrect of regions");
            return false;
        }
        if (selectedOperations.size() == 0) {
            JOptionPane.showMessageDialog(this, "Must select any type of operation");
            return false;
        }

        CP.randomkk(tamano, selectedOperations, regions, isInverseCheck.isSelected());

        return true;
    }

    private boolean comprobarregions(String s){
        for (char c : s.toCharArray()) {
            if (!Character.isDigit(c) && c != '-') {
                return false;
            }
        }
        return true;
    }

    private void clicked(JButton button) {
        if (button.getForeground().equals(originalColor)){
            button.setForeground(Color.BLUE);
            button.setFont(new Font("Arial",Font.BOLD, 20));
            int s = typeof(button.getText());
            selectedOperations.add(s);
            System.out.println(selectedOperations.size());
        }else{
            button.setForeground(originalColor);
            button.setFont(new Font("Arial",Font.PLAIN, 20));
            int s = typeof(button.getText());
            selectedOperations.remove(Integer.valueOf(s));
        }
    }

    private int typeof(String text) {
        if (text == "+") return 1;
        if (text == "-") return 2;
        if (text == "*") return 3;
        if (text == "/") return 4;
        if (text == "^") return 5;
        if (text == "√") return 6;
        return 0;
    }
    private void pressed(FocusEvent actionEvent) {
        regionsfield.setText("");
    }

    private int tam_tab(String item) {
        if (Objects.equals(item, "3x3"))  return 3;
        if (Objects.equals(item, "4x4"))  return 4;
        if (Objects.equals(item, "5x5"))  return 5;
        if (Objects.equals(item, "6x6"))  return 6;
        if (Objects.equals(item, "7x7"))  return 7;
        if (Objects.equals(item, "8x8"))  return 8;
        if (Objects.equals(item, "9x9"))  return 9;
        else return 0;
    }

    private void returnbuttonclicked(ActionEvent actionEvent) {
        MainWindow.setCurrentPanel(new MainMenu(CP));
    }


}
