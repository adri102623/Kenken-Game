package edu.upc.prop.clusterxx.Domini.Board;

//Que métodos tiene que implemetar para ser parte del set? Interfaz Comparable?

/**
 * La clase Pos representa los índices que apuntan a una posición en el tablero.
 * En las funciones de tablero, debe estar en el rango ([0, tamaño - 1], [0, tamaño - 1]).
 * Está pensada para funcionar de la misma forma que un struct.
 */
public class Pos implements Comparable<Pos>{
    //variables públicas porque Pos es como una struct.
    /**
     * Coordenada horizontal.
     */
    public int i;
    /**
     * Coordenada vertical.
     */
    public int j;

    /**
     * Constructor de Pos.
     *
     * @param i Coordenada horizontal.
     * @param j Coordenada vertical.
     */
    public Pos(int i, int j) {
        this.i = i;
        this.j = j;
    }

    /**
     * Devuelve la posición resultado de sumar dos posiciones (a + b).
     *
     * @return Una nueva posición (a + b).
     */
    public static Pos add(Pos a, Pos b) {
        return new Pos(a.i + b.i, a.j + b.j);
    }

    /**
     * Devuelve el resultado de restar dos posiciones. (a - b).
     *
     * @return Una nueva posición (a - b).
     */
    public static Pos subtract(Pos a, Pos b) { return new Pos(a.i - b.i, a.j - b.j); }

    /**
     * Devuelve si dos posiciones son iguales:
     * Mismas coordenadas i y j.
     *
     * @return Si dos posiciones son iguales.
     */
    public static boolean equals(Pos a, Pos b) {
        return (a.i == b.i && a.j == b.j);
    }

    /**
     * Devuelve la posición es igual al parámetro:
     * Mismas coordenadas i y j.
     *
     * @return Si dos posiciones son iguales.
     */
    public boolean equals(Pos b) { return equals(this, b); }

    /**
     * Implementación del método compareTo de la interfaz Comparable.
     */
    public int compareTo(Pos y) {
        //equals puesto explícitamente solo para remarcar que equals(x, y) => compare(x,y) = 0.
        if (equals(this, y)) return 0;
        else if (i < y.i) return -1;
        else if (i > y.i) return 1;
        else if (j < y.j) return -1;
        else return 1;
    }

    /**
     * Devuelve una copia de la posición parámetro.
     *
     * @param p Posición que se clonará.
     * @return Una copia de p.
     */
    public static Pos clone(Pos p) {
        return new Pos(p.i, p.j);
    }
}
