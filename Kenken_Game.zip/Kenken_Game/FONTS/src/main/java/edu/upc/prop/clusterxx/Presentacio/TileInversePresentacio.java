package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import java.awt.*;

//Se podría hacer una clase padre para las partes que tiene en común con TilePresentacio.
public class TileInversePresentacio extends JPanel {
    private CtrlPresentacio ctrlPresentacio;
    private static int tileSize = 75;
    public final int i;
    public final int j;

    //El constructor ya asigna los valores, porque no se van a modificar excepto border. (A diferencia de TilePresentacio)
    public TileInversePresentacio(int i, int j, CtrlPresentacio ctrlPresentacio) {
        this.ctrlPresentacio = ctrlPresentacio;
        setLayout(new GridBagLayout());

        this.i = i;
        this.j = j;

        setPreferredSize(new Dimension(getTileSize(), getTileSize()));
        setMinimumSize(new Dimension(getTileSize(), getTileSize()));
        setOpaque(false);
        setBackground(new Color(0,0,0,0));

        updateBorders();

        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.CENTER;

        int value = ctrlPresentacio.getTileValue(i, j);
        JLabel text = new JLabel(value != 0 ? ("" + value) : "");
        text.setHorizontalAlignment(JLabel.CENTER);
        text.setPreferredSize(new Dimension(getTileSize(), getTileSize()));
        text.setMinimumSize(new Dimension(getTileSize(), getTileSize()));

        add(text, c);
    }

    public static int getTileSize() {
        return tileSize;
    }

    public static void setTileSize(int tileSize) {
        TileInversePresentacio.tileSize = tileSize;
    }

    //Pintar bordes.
    //Si tiene una casilla adyacente de la misma región no pinta ese borde.
    //Si es un borde exterior lo pinta el doble de grueso.
    public void updateBorders() {
        int tileId = ctrlPresentacio.getTileId(i, j);
        int size = ctrlPresentacio.getBoardSize();
        setBorder(BorderFactory.createMatteBorder(
                (i > 0 && ctrlPresentacio.getTileId(i - 1, j) == tileId) ? 0 : (i == 0 ? 2 : 1),
                (j > 0 && ctrlPresentacio.getTileId(i, j - 1) == tileId) ? 0 : (j == 0 ? 2 : 1),
                (i < size-1 && ctrlPresentacio.getTileId(i + 1, j) == tileId) ? 0 : (i == size-1 ? 2 : 1),
                (j < size-1 && ctrlPresentacio.getTileId(i, j + 1) == tileId) ? 0 : (j == size-1 ? 2 : 1),
                Color.BLACK
        ));
    }
}
