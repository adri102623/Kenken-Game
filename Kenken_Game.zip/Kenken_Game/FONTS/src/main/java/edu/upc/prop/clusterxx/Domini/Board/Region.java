package edu.upc.prop.clusterxx.Domini.Board;

import edu.upc.prop.clusterxx.Domini.Operation.Operation;

import java.util.*;

/**
 * La clase región representa un conjunto de posiciones que pueden tener una operación.
 * Estas posiciones pueden ser absolutas en caso de haber asignado una posición de referéncia o relativas (offsets).
 *
 * No se recomienda usar la asignación de posiciones con addPosition mezclada con addOffset y setInitialPos.
 * En caso de hacerlo, si no hay una posición inicial asignada, la primera llamada a addPosition(p) hará p la nueva posición inicial.
 * Una vez asignada, solo se podrá modificar con setInitialPos.
 * Como internamente solo se guardan los offsets, las siguientes llamadas a addPosition(p2) guardarán el offset (p2 - p).
 *
 * ACTUALMENTE NO SE COMPRUEBA EN NINGÚN SITIO QUE LAS CASILLAS DE LA REGIÓN SEAN ADYACENTES.
 */
public class Region {

    /**
     * Identificador de la región. Es único.
     */
    private final int id;

    /**
     * Resultado de la región. Por defecto 0.
     */
    private int result = 0;

    /**
     * Posición de referéncia de la región.
     * Puede no formar parte de offsets.
     */
    private Pos initialPos;

    /**
     * Conjunto de posiciones relativas que forman la región.
     * Es una variable final para asegurarse que no se cambia el tipo sin querer (Por ejemplo igualándolo a new HashSet()).
     */
    private final Set<Pos> offsets = new TreeSet<>();

    /**
     * Dimensiones de la región.
     */
    private Bounds bounds = new Bounds(0,0,0,0);

    /**
     * Tablero del que forma parte la región.
     */
    private Board board;

    /**
     * Operación de la región.
     * Puede ser null.
     */
    private Operation operation;

    /**
     * Devuelve el id de la región.
     *
     * @return El id de la región.
     */
    public int getId() {return id;}

    /**
     * Devuelve el resultado de la región.
     *
     * @return El resultado de la región.
     */
    public int getResult() { return result; }

    /**
     * Devuelve el tablero al que pertenece la región
     *
     * @return Taublero al que pertenece la región
     */
    //Getters
    public Board getBoard() {
        return board;
    }

    /**
     * Devuelve el tamaño de la región.
     *
     * @return El tamaño de la región
     */
    public int getSize(){
        return offsets.size();
    }

    /**
     * Devuelve la posición de referencia de la región o null si no tiene una asignada.
     *
     * @return La posición de referencia de la región o null.
     */
    public Pos getInitialPos() {
        if (initialPos == null) return null;
        return Pos.clone(initialPos);
    }

    /**
     * Devuelve las casillas de la región.
     *
     * @return Las casillas de la región.
     */
    public Vector<Tile> getTiles() {
        if (initialPos == null) return new Vector<Tile>();
        int vectorSize = offsets.size();
        Vector<Tile> ret = new Vector<Tile>(vectorSize);
        for (Pos p : offsets) {
            ret.add(board.getTile(Pos.add(initialPos, p)));
        }
        return ret;
    }

    /**
     * Devuelve el tamaño de la caja contenedora de la región.
     *
     * @return Un array con cuatro elementos que corresponden al tamaño de la caja contenedora de la región: (iMin, iMax, jMin, jMax).
     */
    public int[] getBounds() {
        return new int[]{bounds.iMin, bounds.iMax, bounds.jMin, bounds.jMax};
    }

    /**
     * Devuelve los offsets de las posiciones de la región respecto a la posición de referencia.
     * Puede haber offsets sin posición de referencia en la región, por ejemplo cuando una región aún no se ha colocado en el tablero.
     *
     * @return Los offsets de las posiciones de la región respecto a la posición de referencia.
     */
    public Vector<Pos> getOffsets() {
        return new Vector<>(offsets);
    }

    /**
     * Devuelve las posiciones que ocupa la región o un vector vacío si no está en el tablero.
     *
     * @return Las posiciones que ocupa la región o un vector vacío si no está en el tablero.
     */
    public Vector<Pos> getPositions() {
        if (initialPos == null) return new Vector<Pos>();
        int vectorSize = offsets.size();
        Vector<Pos> ret = new Vector<>(vectorSize);
        for (Pos p : offsets) {
            ret.add(Pos.add(initialPos, p));
        }
        return ret;
    }

    /**
     * Devuelve la operación de la región o null si no tiene.
     *
     * @return La operación de la región o null.
     */
    public Operation getOperacio() {
        return operation;
    }

    //Setters

    /**
     * Asigna el resultado de la región.
     */
    public void setResult(int result) {
        this.result = result;
    }

    /**
     * Intenta asignar la posición de referencia del parámetro.
     * Devuelve si ha sido posible.
     *
     * @param initialPos Posición de referencia para la región.
     * @return Si se ha asignado la posición inicial.
     */
    public boolean setInitialPos(Pos initialPos) {
        if (initialPos == null) {
            removeAllOffsetsTile();
            this.initialPos = null;
            return true;
        }

        if (!insideBoard(initialPos, bounds)) return false;
        removeAllOffsetsTile();
        this.initialPos = Pos.clone(initialPos);
        addAllOffsetsTile();
        return true;
    }

    /**
     * Devuelve si se puede asignar la posición initialPos como posición de referencia.
     *
     * @param initialPos Posición de referencia para la región.
     * @return Si se puede asignar la posición.
     */
    public boolean canPlaceInitialPos(Pos initialPos) {
        if (!insideBoard(initialPos, bounds)) return false;
        for (Pos offset : offsets) {
            Region previous = board.getRegion(Pos.add(offset, initialPos));
            if (previous != null && previous != this) return false;
        }

        return true;
    }

    /**
     * Intenta asignar un set de Offsets, devuelve si ha sido posible.
     *
     * @param offsets Las posiciones de la región respecto a la posición de referéncia.
     * @return Si se han podido asignar los nuevos offsets.
     */
    public boolean setOffsets(Collection<Pos> offsets) {
        Bounds newBounds = calculateBounds(offsets);
        if (initialPos != null && !insideBoard(initialPos, newBounds)) return false;
        bounds = newBounds;
        removeAllOffsetsTile();
        this.offsets.clear();
        for (Pos p : offsets) this.offsets.add(Pos.clone(p));
        addAllOffsetsTile();
        return true;
    }

    /**
     * Asigna una operación a la región.
     *
     * @param operation Operación que se asignará.
     */
    public void setOperation(Operation operation) {
        this.operation = operation;
    }


    /**
     * Intenta añadir un offset, devuelve si ha sido posible.
     *
     * @param p Offset que se añadirá. Representa una posición respecto a la de referéncia.
     * @return Si se ha podido añadir.
     */
    //Modificadoras
    public boolean addOffset(Pos p) {
        if (initialPos != null) {
            int boardSize = board.getSize();
            if (p.i + initialPos.i < 0) return false;
            if (p.j + initialPos.j < 0) return false;
            if (p.i + initialPos.i >= boardSize) return false;
            if (p.j + initialPos.j >= boardSize) return false;
        }
        Pos copy = Pos.clone(p);
        offsets.add(copy);
        if (offsets.size() > 1) includeInBounds(copy, bounds);
        else bounds = calculateBounds(offsets);
        if (initialPos != null) board.setTileRegion(Pos.add(p, initialPos), this);
        return true;
    }

    /**
     * Intenta añadir una posición a la región, devuelve si ha sido posible.
     * Si es la primera posición (absoluta) que se añade, pasa a ser la posición de referencia.
     *
     * @param p Posición que se añadirá en la región.
     * @return Si se ha podido añadir la posición.
     */
    public boolean addPosition(Pos p) {
        if (initialPos == null) setInitialPos(Pos.clone(p));
        return addOffset(Pos.subtract(p, initialPos));
    }

    /**
     * Intenta eliminar un offset de la región, devuelve si ha sido posible.
     *
     * @param p Offset que se eliminará de la región.
     * @return Si el offset formaba parte de la región.
     */
    public boolean removeOffset(Pos p) {
        if (!offsets.remove(p)) return false;
        bounds = calculateBounds(offsets);
        if (initialPos != null) board.clearTileRegion(Pos.add(p, initialPos), this);
        return true;
    }

    /**
     * Intenta eliminar una posición de la región, devuelve si ha sido posible.
     *
     * @param p Posición que se eliminará de la región.
     * @return Si la posición formaba parte de la región.
     */
    public boolean removePosition(Pos p) {
        return removeOffset(Pos.subtract(p, initialPos));
    }

    //Consultoras
    /**
     * Devuelve si todas las casillas de la región tienen un valor asignado.
     * Si la región no tiene posición de referencia devuelve falso.
     *
     * @return Si todas las casillas de la región tienen un valor asignado.
     */
    public boolean isCompleted(){
        if (initialPos == null) return false;
        for (Pos p : offsets)
            if (!board.getTile(Pos.add(initialPos, p)).hasValue()) return false;
        return true;
    }

    /**
     * Devuelve si todas las casillas de la región están conectadas entre ellas.
     * En caso de que haya 0 casillas o la posición inicial no esté asignada devuelve cierto.
     *
     * @return Si todas las casillas de la región están conectadas entre ellas.
     */
    public boolean isConnected() {
        if (initialPos == null || offsets.size() <= 1) return true;

        Pos startPos = Pos.add(initialPos, offsets.iterator().next());
        Set<Pos> connected = new TreeSet<>();
        connected.add(startPos);
        addConnectedPositionsToSet(connected, startPos);

        return connected.size() == offsets.size();
    }

    /**
     * Añade a connected todas las posiciones de la región conectadas con pos.
     *
     * @param connected Set que contendrá todas las posiciones conectadas cuando la función acabe.
     * @param pos Posición que se mirará. En coordenadas absolutas.
     */
    void addConnectedPositionsToSet(Set<Pos> connected, Pos pos) {
        final Pos[] dirs = {new Pos(1,0), new Pos(0,1), new Pos(-1, 0), new Pos(0, -1)};
        for (Pos dir : dirs) {
            Pos newPos = Pos.add(pos, dir);
            if (board.validPos(newPos) && board.getRegion(newPos) == this && connected.add(newPos)) {
                addConnectedPositionsToSet(connected, newPos);
            }
        }
    }

    /**
     * Devuelve si la operación se cumple para la región.
     *
     * @return Si la operación se cumple para la región.
     */
    public boolean operationChecks() {
        if (operation == null) throw new RuntimeException("La región no tiene operación asignada.");
        if (!isCompleted()) throw new RuntimeException("Hay casillas sin valor asignado en la región.");
        return operation.applyOperation(this) == result;
    }

    /**
     * Devuelve la posición más arriba y a la izquierda de la región, en ese orden, o null si no está en el tablero.
     *
     * @return La posición más arriba y a la izquierda de la región, en ese orden, o null si no está en el tablero.
     */
    public Pos getTopLeftPos() {
        if (initialPos == null) return null;
        Pos ret = getTopLeftOffset();
        if (ret == null) return null;
        return Pos.add(initialPos, ret);
    }

    /**
     * Devuelve el offset más arriba y a la izquierda de la región, en ese orden, o null si no está en el tablero.
     *
     * @return El offset más arriba y a la izquierda de la región, en ese orden, o null si no está en el tablero.
     */
    public Pos getTopLeftOffset() {
        if (offsets.isEmpty()) return null;
        int i = bounds.iMin;
        int j = bounds.jMin;
        while (!offsets.contains(new Pos(i, j))) { j++; }
        return new Pos(i, j);
    }


    /**
     * Constructor.
     *
     * @param board Tablero al que se asignará la región.
     */
    //Paquete
    Region(Board board, int id) {
        this.board = board;
        board.addRegion(this);
        this.id = id;
    }

    /**
     * Elimina la región de las posiciones en tablero y desasigna tablero.
     *
     * todo: hacer que de error si se continúa usando la clase.
     */
    //Para que produzca nullPtrException si se intenta seguir utilizando una región que se ha eliminado del tablero.
    void unbindBoard() {
        removeAllOffsetsTile();
        board = null;
    }

    /**
     * Devuelve los offsets de la región sin hacer una copia.
     *
     * @return Los offsets de la región.
     */
    //Más eficiente, pero no se debe modificar
    Set<Pos> getOffsetsReference() {
        return offsets;
    }


    /**
     * Desasigna la región de todas sus posiciones en tauler.
     */
    //Privadas
    private void removeAllOffsetsTile() {
        if (initialPos == null) return;
        for (Pos pos : offsets) board.clearTileRegion(Pos.add(pos, initialPos), this);
    }

    /**
     * Asigna la región a todas sus posiciones en tauler.
     */
    private void addAllOffsetsTile() {
        if (initialPos == null) return;
        for (Pos pos : offsets) board.setTileRegion(Pos.add(pos, initialPos), this);
    }

    /**
     * Devuelve si una región con posición de referencia p y contenida en b se encuentra dentro del tablero.
     *
     * @param p Posición de referéncia.
     * @param b Dimensiones de la región.
     * @return Si p es una posición de referéncia válida para una región de dimensiones b.
     */
    private boolean insideBoard(Pos p, Bounds b) {
        int boardSize = board.getSize();
        if (p.i + b.iMin < 0) return false;
        if (p.j + b.jMin < 0) return false;
        if (p.i + b.iMax >= boardSize) return false;
        if (p.j + b.jMax >= boardSize) return false;
        return true;
    }

    /**
     * Actualiza b para contener p.
     *
     * @param p Nueva posición.
     * @param b Bounds que se actualizarán.
     */
    private void includeInBounds(Pos p, Bounds b) {
        if (p.i < b.iMin) b.iMin = p.i;
        if (p.i > b.iMax) b.iMax = p.i;
        if (p.j < b.jMin) b.jMin = p.j;
        if (p.j > b.jMax) b.jMax = p.j;
    }

    /**
     * Calcula los bounds que contienen todas las posiciones de v o null.
     *
     * @param v Conjunto de posiciones.
     * @return Bounds que contienen todas las posiciones de v o null si v está vacío.
     */
    private Bounds calculateBounds(Collection<Pos> v) {
        Bounds ret = null;
        for (Pos p : v) {
            if (ret == null) ret = new Bounds(p.i, p.i, p.j, p.j);
            includeInBounds(p, ret);
        }
        return ret;
    }
}
