package edu.upc.prop.clusterxx.Domini.Operation;
import edu.upc.prop.clusterxx.Domini.Board.Tile;
import edu.upc.prop.clusterxx.Domini.Board.Region;
import java.util.Vector;

/**
 * Subclase de Operation, la cual es la suma de los valores de las casillas que forman la región.
 */
public class OperationAddition extends Operation {

    //Metodos

    //Constructor de la clase OperacioSuma
    /**
     *Asigna el nombre de Suma
     */
    public OperationAddition() {
        //Le asigna el nombre "Suma"
        super("Suma");
    }

    /**
     * Devuelve el codigo correspondiente a la operacion
     *
     * @return  1
     */
    @Override
    public int getCode() {
        return 1;
    }


    /**
     *Aplica el calculo sumar los valores de la region, recibe una region como parametro que es donde se aplica la operacion
     *@param reg Reg es una region
     *@return a+b+c+d+...+x siendo la suma de todos sus valores
     */
    public int applyOperation(Region reg){
        int res = 0;
        Vector<Tile> v = reg.getTiles();
        for (Tile c : v) {
            if (c.hasValue())
            res += c.getValue();
        }
        return res;
    }

    @Override
    public char getChar() {
        return '+';
    }

}
