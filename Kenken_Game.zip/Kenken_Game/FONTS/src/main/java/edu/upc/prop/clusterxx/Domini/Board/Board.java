package edu.upc.prop.clusterxx.Domini.Board;

import edu.upc.prop.clusterxx.Domini.Kenken;
import edu.upc.prop.clusterxx.Domini.Operation.Operation;
import edu.upc.prop.clusterxx.Domini.CtrlDomini.BoardErrorCodes;

import java.util.Collection;
import java.util.LinkedList;
import java.util.Vector;

/**
 * La clase Board contiene las casillas y regiones que lo forman y los métodos para modificarlos.
 * Se basa en que no puede haber dos regiones en la misma casilla.
 */
public class Board {

    //Variables
    /**
     * Tamaño del tablero horizontal y verticalmente.
     * Se asigna en el constructor y no se puede modificar después.
     */
    private final int size;

    /**
     * Array que contiene todas las casillas del tablero ordenadas.
     * El primer índice corresponde a izquierda derecha.
     * El segundo índice corresponde a arriba abajo.
     * (0, 0) es la casilla superior izquierda.
     */
    private Tile[][] tiles;

    /**
     * Array que contiene la región de cada posición del tablero.
     * El primer índice corresponde a izquierda derecha.
     * El segundo índice corresponde a arriba abajo.
     * (0, 0) es la casilla superior izquierda.
     */
    private Region[][] regionMap;

    /**
     * Colección que contiene todas las regiones del tablero.
     * Esto incluye a las regiones que no tienen casillas asignadas.
     * Se utiliza la clase colección para poder cambiar de forma sencilla que estructura específica se utiliza.
     */
    private final Collection<Region> regions = new LinkedList<>();

    /**
     * Próxima id disponible para asignar a una región.
     */
    int nextId = 1;

    //Constructores
    /**
     * Construye un tablero vacío de dimensiones size x size.
     *
     * @param size El tablero será de dimensiones size x size
     */
    public Board(int size){
        if (size < 0) throw new IllegalArgumentException("Illegal size");
        this.size = size;
        initialize();
    }

    /**
     * Construye el tablero codificado en el parámetro.
     *
     * @pre El parámetro está correctamente codificado.
     * @param s Tablero codificado según el formato estándar.
     */
    public Board(String s) {
        String[] words = s.split("\\s+");
        size = Integer.parseInt(words[0]);
        initialize();
        int regions_size = Integer.parseInt(words[1]);
        int index = 2;
        for (int i = 0; i < regions_size; i++) {
            boolean isRelative = words[index].charAt(0) == '#';
            String codeString = isRelative ? words[index++].substring(1) : words[index++];
            int code = Integer.parseInt(codeString);
            int result = Integer.parseInt(words[index++]);
            int rsize = Integer.parseInt(words[index++]);

            //Si la operacion es nada no hay región
            if (code == 0) {
                for (int j = 0; j < rsize; j++) {
                    int x = Integer.parseInt(words[index++]) - 1;
                    int y = Integer.parseInt(words[index++]) - 1;
                    if (index < words.length && words[index].charAt(0) == '[') {
                        int cont = Integer.parseInt(words[index++].replaceAll("[^0-9]", ""));
                        tiles[x][y].setValue(cont);
                    }
                }
                continue;
            }

            //Code != 0
            Operation op = Operation.GetOperation(code);
            Region r = new Region(this, nextId++);
            r.setResult(result);
            r.setOperation(op);
            for (int j = 0; j < rsize; j++) {
                int x = Integer.parseInt(words[index++]) - 1;
                int y = Integer.parseInt(words[index++]) - 1;
                if (isRelative) r.addOffset(new Pos(x, y));
                else r.addPosition(new Pos(x, y));
                //No entrará si es relativo, así que no se comprueba
                if (index < words.length && words[index].charAt(0) == '[') {
                    int cont = Integer.parseInt(words[index++].replaceAll("[^0-9]", ""));
                    tiles[x][y].setValue(cont);
                }
            }
        }
    }

    //Getters
    /**
     * Devuelve la casilla en la posición especificada del tablero.
     * Se puede usar para modificar o consultar el contenido de la casilla.
     *
     * @param pos La posición de la casilla.
    * Las coordenadas están en el rango [0, tamaño - 1].
     * @return La casilla en la posición especificada.
     */
    public Tile getTile(Pos pos) {
        if (!validPos(pos)) throw new IllegalArgumentException("Pos tiene que estar en el rango [0..tamaño - 1].");
        return tiles[pos.i][pos.j];
    }

    /**
     * Devuelve la región en la posición especificada del tablero o null si no tiene.
     *
     * @param pos Una posición que forma parte de la región.
     * Las coordenadas están en el rango [0, tamaño - 1].
     * @return Región en la posición pos o null.
     */
    public Region getRegion(Pos pos){
        if (!validPos(pos)) throw new IllegalArgumentException("Pos tiene que estar en el rango [0..tamaño - 1].");
        return regionMap[pos.i][pos.j];
    }

    /**
     * Devuelve todas las regiones del tablero.
     * Se puede usar para obtener las regiones que no han estado asignadas a ninguna posición.
     *
     * @return Un Vector con todas las regiones del tablero.
     */
    public Vector<Region> getRegions(){
        return new Vector<Region>(regions);
    }

    /**
     * Devuelve el número de regiones del tablero.
     * Incluye las que no están colocadas.
     *
     * @return El número de regiones del tablero.
     */
    public int getRegionCount() {return regions.size();}

    /**
     * @return Tamaño del tablero. (El tablero es de dimensiones tamaño x tamaño).
     */
    public int getSize(){
        return size;
    }

    /**
     * Devuelve si es válido asignar la casilla a la región.
     * Falla si no tiene otras casillas de la re
     *
     * @param pos Posición que pasaría a ser de la región.
     * @param id Id de la región que se quiere pintar.
     * @return Si es válido asignar la casilla a la región.
     */
    /*public boolean isValidPaint(Pos pos, int id) {
        Region region = getRegionById(id);
        if (region == null) return false;
        if (!hasAdjacentRegion(pos, id)) return false;
        Operation operation = region.getOperacio();
        if (operation != null && operation.)
    }*/

    /**
     * Devuelve la región con id correspondiente o null.
     *
     * @param id Id de la región.
     * @return La región con id correspondiente o null.
     */
    public Region getRegionById(int id) {
        for (Region region : regions) {
            if (region.getId() == id) return region;
        }
        return null;
    }

    /**
     * Devuelve si hay alguna casilla de la región id adyacente.
     *
     * @param pos Posición de la casilla
     * @param id Id de la región que se comprobará.
     * @return Si hay alguna casilla de la región id adyacente.
     */
    public boolean hasAdjacentRegion(Pos pos, int id) {
        int i = pos.i;
        int j = pos.j;
        if (i > 0 && regionMap[i-1][j] != null && regionMap[i-1][j].getId() == id) return true;
        if (j > 0 && regionMap[i][j-1] != null && regionMap[i][j-1].getId() == id) return true;
        if (i < size - 1 && regionMap[i+1][j] != null && regionMap[i+1][j].getId() == id) return true;
        if (j < size - 1 && regionMap[i][j+1] != null && regionMap[i][j + 1].getId() == id) return true;
        return false;
    }

    //Modificadores
    /**
     * Crea una nueva región vacía y sin operación en el tablero.
     * Es la ÚNICA forma correcta de crear una región.
     *
     * @return Una nueva región que pertenece al tablero.
     */
    public Region newRegion() {
        return new Region(this, nextId++);
    }

    /**
     * Elimina del tablero la región del parámetro.
     * La región NO se puede continuar usando.
     *
     * NOTA: Para futuras versiones estaría bien implementar algún método en Regio que lance una excepción si se vuelve a utilizar la región.
     *
     * @param region La región a eliminar. Debe pertenecer al tablero.
     */
    public void deleteRegion(Region region) {
        if (region.getBoard() != this) throw new RuntimeException("Region does not belong to board");
        //Es región la que se encarga de desasignarse de las casillas.
        //Implementado de esta forma, ya que la funcionalidad se reutiliza en otros casos.
        region.unbindBoard();
        regions.remove(region);
    }

    /**
     * Elimina la región que contiene la posición del parámetro.
     *
     * @param pos Una posición que forma parte de la región.
     * Las coordenadas están en el rango [0, tamaño - 1].
     * @return Si había una región en pos y, por lo tanto, si se ha eliminado.
     */
    public boolean deleteRegion(Pos pos) {
        Region r = regionMap[pos.i][pos.j];
        if (r == null) return false;
        deleteRegion(r);
        return true;
    }

    /**
     * Convierte el tablero en una string en el formato estándar.
     *
     * @return Una array de strings en la que cada elemento es una línea de la codificación.
     */
    public String[] codify() {
        int regionsSize = regions.size();
        String[] ret = new String[2 + regionsSize];
        //La cantidad de regiones se añadirá después porque depende de si hay casillas con valor sin región.
        ret[0] = size + " ";
        int i = 1;
        for (Region r : regions) {
            Operation op = r.getOperacio();
            Collection<Pos> offsets = r.getOffsetsReference();
            Pos initialPos = r.getInitialPos();
            boolean isRelative = initialPos == null;
            ret[i] = (isRelative ? "#" : "") + op.getCode() + " " + r.getResult() + " " + offsets.size();
            for (Pos offset : offsets) {
                Pos p = isRelative ? offset : Pos.add(initialPos, offset);
                ret[i] += " " + (p.i + 1) + " " + (p.j + 1);
                if (!isRelative) {
                    Tile c = getTile(p);
                    if (c.hasValue()) ret[i] += " [" + c.getValue() + "]";
                }
            }
            i++;
        }

        //Añadir las casillas con valor pero sin región.

        //values contiene las posiciones y el valor.
        //Como no se sabe cuantas habrá no se puede añadir directamente a ret.
        String values = "";
        int amount = 0;
        for (int pos_i = 0; pos_i < size; pos_i++) {
            for (int pos_j = 0; pos_j < size; pos_j++) {
                Tile c = tiles[pos_i][pos_j];
                if (c.hasValue() && regionMap[pos_i][pos_j] == null) {
                    amount++;
                    values += " " + (pos_i + 1) + " " + (pos_j + 1) + " [" + c.getValue() + "]";
                }

            }
        }
        if (amount > 0) {
            ret[i] = "0 0 " + amount;
            ret[i] += values;
            ret[0] += (regionsSize + 1);
        } else {
            ret[i] = "";
            ret[0] += regionsSize;
        }

        return ret;
    }

    /**
     * Clona el tablero.
     *
     * @return Una copia del tablero.
     */
    public Board cloneBoard() {
        //Si hubiera un problema con la eficiencia se podría hacer de forma más correcta.
        return new Board(String.join(" ", codify()));
    }

    // Estos métodos son solo accesibles desde el paquete para evitar errores.
    // NO CAMBIAR PUBLIC

    /**
     * Añade la región al tablero.
     *
     * @param region Región que añadir al tablero.
     */
    public void addRegion(Region region) {
        if (region.getBoard() != this) throw new RuntimeException("Region does not belong to board");
        regions.add(region);
    }

    /**
     * Asigna la región correspondiente a la casilla en pos.
     *
     * @param pos Posición en la que se asignará la región.
     * @param region Región que se asignará. Not null.
     */
    void setTileRegion(Pos pos, Region region) {
        //Aunque se podría desasignar la región de esta forma, hay un método específico para ello que comprueba errores.
        if (region == null) throw new IllegalArgumentException("regio no puede ser null.");
        if (regionMap[pos.i][pos.j] == region) throw new RuntimeException("Already marked as this region");
        if (regionMap[pos.i][pos.j] != null) throw new RuntimeException("Intento de colocar una región donde ya había una.");
        regionMap[pos.i][pos.j] = region;
    }

    /**
     * Desasigna la región de la casilla en pos.
     *
     * @param pos Posición en la que se desasignará la región.
     * @param region Región actual de la casilla.
     *              Este parámetro es redundante, pero se utiliza para asegurarse que no hay errores en el código.
     */
    void clearTileRegion(Pos pos, Region region) {
        if (regionMap[pos.i][pos.j] != region) throw new RuntimeException("Casella does not belong to region");
        regionMap[pos.i][pos.j] = null;
    }

    /**
     * Devuelve si la posición es válida.
     *
     * @param pos Posición que se comprobará.
     * @return Si la posición está dentro del tablero. Rango [0, tamaño-1].
     */
    public boolean validPos(Pos pos) {
        return (pos.i >= 0 && pos.i < size && pos.j >= 0 && pos.j < size);
    }

    public boolean validValue(Pos pos, int value) {
        for (int i = 0; i < size; i++) {
            if (i != pos.j && tiles[pos.i][i].hasValue() && tiles[pos.i][i].getValue() == value) return false;
            if (i != pos.i && tiles[i][pos.j].hasValue() && tiles[i][pos.j].getValue() == value) return false;
        }
        return true;
    }

    /**
     * Devuelve 0 si el tablero es válido o un código de error si no. No hay ninguna prioridad a la hora de devolver códigos de error.
     *
     * @return El error correspondiente (puede ser VALID = no error).
     */
    public BoardErrorCodes isValid() {
        for (Region region : regions) {
            Operation operation = region.getOperacio();
            if (operation == null) return BoardErrorCodes.NO_OPERATION_ASSIGNED;
            int tilesRequired = operation.getTileRequired();
            if (tilesRequired != -1 && tilesRequired != region.getOffsetsReference().size()) return BoardErrorCodes.OPERATION_TILE_NUMBER;
            int code = operation.getCode();
            if(code == 3 && (region.getOffsetsReference().size() > 6)) return BoardErrorCodes.OPERATION_TILE_NUMBER;
        }

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (regionMap[i][j] == null && !tiles[i][j].hasValue()) return BoardErrorCodes.NO_REGION_OR_VALUE_TILE;
            }
        }

        Board clone = cloneBoard();
        //Utiliza el criterio de kenken para verificar.
        if (!Kenken.solve(clone))
            return BoardErrorCodes.NO_SOLUTION;

        return BoardErrorCodes.VALID;
    }

    /* Retorna si x és un nombre valid per la fila r */
    public boolean checkRow(int fila, int x) {
        for (int col=0; col<size; ++col) {
            Pos pos = new Pos (fila,col);
            Tile casilla = getTile(pos);
            if(casilla.hasValue()) {
                if (getTile(pos).getValue() == x) return false;
            }
        }
        return true;
    }

    /* Retorna si x és un nombre vàlid per la columna c */
    public boolean checkCol(int col, int x) {
        for (int fila = 0; fila < size; ++fila) {
            Pos pos = new Pos (fila,col);
            Tile casilla = getTile(pos);
            if(casilla.hasValue()) {
                if (getTile(pos).getValue() == x) return false;
            }
        }
        return true;
    }

    /**
     * Inicializa caselles y regioMap.
     */
    //Privados
    private void initialize() {
        tiles = new Tile[size][size];
        regionMap = new Region[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                tiles[i][j] = new Tile();
                regionMap[i][j] = null;
            }
        }
    }

}
