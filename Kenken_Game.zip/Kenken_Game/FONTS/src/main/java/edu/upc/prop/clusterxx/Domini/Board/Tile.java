package edu.upc.prop.clusterxx.Domini.Board;

/**
 * La clase Casella representa el contenido de una casilla del tablero.
 * Puede o no tener un valor asignado.
 * Una casilla no sabe su posición, región o a qué tablero pertenece.
 */
public class Tile {
    /**
     * Si la casilla tiene valor.
     */
    //Variables
    private boolean hasValue = false;
    /**
     * Valor de la casilla.
     */
    private int value; // valor > 0

    //Metodos

    /**
     * Construye una casilla sin valor.
     */
    public Tile() {}
    /**
     * Construye una casilla con valor.
     *
     * @param value Valor de la casilla. Debe ser mayor que 0.
     */
    public Tile(int value){
        if (value <= 0) {
            throw new IllegalArgumentException("Illegal value");
        }
        this.value = value;
        hasValue = true;
    }

    /**
     * Devuelve si la casilla tiene valor.
     *
     * @return Si la casilla tiene valor.
     */
    public boolean hasValue() { return hasValue; }

    /**
     * Devuelve el valor de una casilla.
     * Si la casilla no tiene valor producirá una excepción.
     *
     * @return Devuelve el valor de la casilla.
     */
    public int getValue() {
        if (!hasValue) throw new RuntimeException("Casilla doesn't have a value");
        return value;
    }

    /**
     * Asigna un valor a la casilla.
     *
     * @param valor El valor que se asignará.
     */
    public void setValue(int valor){
        this.value = valor;
        hasValue = true;
    }

    /**
     * Elimina el valor de la casilla.
     *
     * @return Si la casilla tenía un valor asignado.
     */
    public boolean removeValue() {
        boolean oldValue = hasValue;
        hasValue = false;
        return oldValue;
    }

    public void resetValue(){
        hasValue = false;
        this.value = 0;
    }
}
