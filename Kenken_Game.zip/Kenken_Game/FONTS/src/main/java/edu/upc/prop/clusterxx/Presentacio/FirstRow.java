package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Esta clase sirve para modificar como nosotros deseemos las tres primeras filas del ranking, como por ejemplo podemos poner un color diferente a cada una,
 * o modificar la letra...
 */
public class FirstRow extends DefaultTableCellRenderer {

    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column){
        JLabel label =(JLabel) super.getTableCellRendererComponent(table,value, isSelected,hasFocus,row,column);

        if (row == 0){
            label.setFont(new Font("Montserrat",Font.PLAIN,24));
            label.setBackground(new Color(255, 215, 0));
            label.setOpaque(true);
        } else if (row == 1) {
            label.setBackground(new Color(229,229,229));
        }
        else if (row == 2){
            label.setBackground(new Color(178,102,25));
        }   else {
            label.setBackground(Color.WHITE);
            label.setOpaque(true);
        }
        return label;
    }
}
