package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import java.awt.*;

public class BoardInversePresentacio extends JPanel implements IRefreshable {
    private final int size;
    private final TileInversePresentacio[][] grid;

    public BoardInversePresentacio(CtrlPresentacio ctrlPresentacio) {
        super(new GridBagLayout());
        size = ctrlPresentacio.getBoardSize();
        setOpaque(false);
        setBackground(new Color(0,0,0,0));

        GridBagConstraints c = new GridBagConstraints();
        c.gridwidth = 1;
        c.gridheight = 1;
        c.weightx = 0;
        c.weighty = 0;

        grid = new TileInversePresentacio[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                c.gridx = j;
                c.gridy = i;

                TileInversePresentacio gridElement = new TileInversePresentacio(i, j, ctrlPresentacio);
                grid[i][j] = gridElement;
                add(gridElement, c);
            }
        }

    }

    /**
     * Devuelve los índices de la casilla en la posición (x, y) de la pantalla.
     * Si no hay, devuelve (-1, -1).
     */
    public int[] getIndex(int x, int y) {
        int indexX = (x - grid[0][0].getX())/ TileInversePresentacio.getTileSize();
        int indexY = (y - grid[0][0].getY())/ TileInversePresentacio.getTileSize();
        if (indexX >= size || indexY >= size) return new int[]{-1, -1};
        return new int[]{indexX, indexY};
    }

    public void refresh() {
        for (TileInversePresentacio[] row : grid) {
            for (TileInversePresentacio tile : row) {
                tile.updateBorders();
            }
        }
    }
}
