package edu.upc.prop.clusterxx.Presentacio;

import javax.swing.*;
import java.awt.*;
import java.util.Random;
import java.util.Vector;

/**
 * Esta clase contiene el tablero del KenKen inverso y los métodos con los que el usuario modificará su estado (arrastrando regiones).
 */
public class InverseKenKenPresentacio extends JPanel implements IRefreshable {
    CtrlPresentacio ctrl;
    BoardInversePresentacio board;
    Vector<DraggableRegion> regions = new Vector<>();

    public InverseKenKenPresentacio(CtrlPresentacio ctrlPresentacio) {
        this.ctrl = ctrlPresentacio;
        TileInversePresentacio.setTileSize(ctrlPresentacio.getBoardSize() >= 7 ? 50 : 75);

        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        JLayeredPane pane = new JLayeredPane();
        pane.setLayout(null);

        int layer = 1;
        int pixelSize = ctrlPresentacio.getBoardSize()* TileInversePresentacio.getTileSize();
        int[] ids = ctrlPresentacio.getRegionIds();
        Random random = new Random();
        for (int id : ids) {
            DraggableRegion region = new DraggableRegion(ctrlPresentacio, this, id);
            regions.add(region);
            Dimension regionSize = region.getMinimumSize();
            int marginX = pixelSize-regionSize.width;
            int marginY = pixelSize-regionSize.height;
            region.setBounds(marginX > 0 ? random.nextInt(marginX) : 0, marginY > 0 ? random.nextInt(marginY) : 0, regionSize.width, regionSize.height);
            pane.add(region, Integer.valueOf(layer++));
        }
        //add(regionContainer, c);

        board = new BoardInversePresentacio(ctrlPresentacio);

        board.setBounds(board.getMinimumSize().width,0, board.getMinimumSize().width, board.getMinimumSize().height);
        pane.add(board, Integer.valueOf(layer++));
        pane.setMinimumSize(new Dimension(board.getMinimumSize().width*2, board.getMinimumSize().height));
        pane.setPreferredSize(new Dimension(board.getMinimumSize().width*2, board.getMinimumSize().height));

        add(pane, c);
        setMinimumSize(getMinimumSize());

        refresh();
    }

    public void pickRegion(int id, int initialPosX, int initialPosY) {
        int tileSize = TileInversePresentacio.getTileSize();
        int boardSize = ctrl.getBoardSize();
        int i = (initialPosY + tileSize/2 - board.getY())/tileSize;
        int j = (initialPosX + tileSize/2 - board.getX())/tileSize;
        if (i < 0 || i >= boardSize || j < 0 || j >= boardSize) return;
        ctrl.clearRegionInitialPos(id);
        refresh();
    }

    public int[] dropRegion(int id, int initialPosX, int initialPosY) {
        int tileSize = TileInversePresentacio.getTileSize();
        int boardSize = ctrl.getBoardSize();
        int i = (initialPosY + tileSize/2 - board.getY())/tileSize;
        int j = (initialPosX + tileSize/2 - board.getX())/tileSize;
        if (i < 0 || i >= boardSize || j < 0 || j >= boardSize || !ctrl.setRegionInitialPos(id, i, j))
            return new int[]{-1,-1};
        refresh();
        return new int[]{board.getX() + j*tileSize, board.getY() + i*tileSize};
    }

    public void refresh() {
        board.refresh();

        int tileSize = TileInversePresentacio.getTileSize();
        for (DraggableRegion region : regions) {
            int id = region.getID();
            int[] initialPos = ctrl.getRegionInitialPos(id);
            if (initialPos[0] != -1) {
                region.setLocationOfInitialPos(new int[]{board.getX() + initialPos[1]*tileSize, board.getY() + initialPos[0]*tileSize});
            }
        }
    }
}
